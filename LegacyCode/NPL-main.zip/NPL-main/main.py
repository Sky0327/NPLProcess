import argparse
import os
import sys
from datetime import datetime

#버전 : 2025-04-08
expiry_date = datetime(2025, 9, 30)


def check_expiry():
    current_date = datetime.now()
    if current_date > expiry_date:
        print(f"이 프로그램의 유효기간은 {expiry_date.strftime('%Y-%m-%d')}까지입니다. 실행이 종료됩니다.")
        sys.exit(1)

def run_get_registry_basic_info():
    check_expiry()
    import app_00_get_registry_basic_info  # 지연 임포트
    if getattr(sys, 'frozen', False):
        # PyInstaller로 실행된 경우
        script_dir = os.path.dirname(sys.executable)
    else:
        # 일반 스크립트 실행 시
        script_dir = os.path.dirname(os.path.abspath(__file__))

    excel_path = os.path.join(script_dir, 'Smart_NPL.xlsm')

    app_00_get_registry_basic_info.get_registry_basic_info_from_PDF(excel_path)

def run_valuemap():
    check_expiry()
    import app_00_valuemap  # 지연 임포트
    if getattr(sys, 'frozen', False):
        script_dir = os.path.dirname(sys.executable)
    else:
        script_dir = os.path.dirname(os.path.abspath(__file__))

    excel_path = os.path.join(script_dir, 'Smart_NPL.xlsm')

    app_00_valuemap.valuemap(excel_path)

def run_register_inquiry():
    check_expiry()
    import app_01_register_inquiry  # 지연 임포트
    if getattr(sys, 'frozen', False):
        script_dir = os.path.dirname(sys.executable)
    else:
        script_dir = os.path.dirname(os.path.abspath(__file__))

    excel_path = os.path.join(script_dir, 'Smart_NPL.xlsm')

    app_01_register_inquiry.run_register_inquiry(excel_path)

def run_posting_price():
    check_expiry()
    import app_02_posting_price  # 지연 임포트
    if getattr(sys, 'frozen', False):
        script_dir = os.path.dirname(sys.executable)
    else:
        script_dir = os.path.dirname(os.path.abspath(__file__))

    excel_path = os.path.join(script_dir, 'Smart_NPL.xlsm')

    app_02_posting_price.run_posting_price(excel_path)

def run_gookto_real_price():
    check_expiry()
    import app_03_gookto_real_price  # 지연 임포트
    if getattr(sys, 'frozen', False):
        script_dir = os.path.dirname(sys.executable)
    else:
        script_dir = os.path.dirname(os.path.abspath(__file__))

    excel_path = os.path.join(script_dir, 'Smart_NPL.xlsm')

    app_03_gookto_real_price.run_gookto_real_price(excel_path)

def run_gookto_calculate_distance():
    check_expiry()
    import app_04_gookto_calculate_distance  # 지연 임포트
    if getattr(sys, 'frozen', False):
        script_dir = os.path.dirname(sys.executable)
    else:
        script_dir = os.path.dirname(os.path.abspath(__file__))

    excel_path = os.path.join(script_dir, 'Smart_NPL.xlsm')

    app_04_gookto_calculate_distance.run_gookto_calculate_distance(excel_path)

def run_valuemap_calculate_distance():
    check_expiry()
    import app_05_valuemap_calculate_distance  # 지연 임포트
    if getattr(sys, 'frozen', False):
        script_dir = os.path.dirname(sys.executable)
    else:
        script_dir = os.path.dirname(os.path.abspath(__file__))

    excel_path = os.path.join(script_dir, 'Smart_NPL.xlsm')

    app_05_valuemap_calculate_distance.run_valuemap_calculate_distance(excel_path)

def run_kb_info():
    check_expiry()
    import app_06_kb_info  # 지연 임포트
    if getattr(sys, 'frozen', False):
        script_dir = os.path.dirname(sys.executable)
    else:
        script_dir = os.path.dirname(os.path.abspath(__file__))

    excel_path = os.path.join(script_dir, 'Smart_NPL.xlsm')

    app_06_kb_info.kb_info().run_app()

def run_court_auction():
    check_expiry()
    import app_07_court_auction  # 지연 임포트
    if getattr(sys, 'frozen', False):
        script_dir = os.path.dirname(sys.executable)
    else:
        script_dir = os.path.dirname(os.path.abspath(__file__))

    excel_path = os.path.join(script_dir, 'Smart_NPL.xlsm')

    app_07_court_auction.court_auction().run_app(filepath=excel_path)

def run_infocare_analysis():
    check_expiry()
    import app_08_infocare_analysis  # 지연 임포트
    if getattr(sys, 'frozen', False):
        script_dir = os.path.dirname(sys.executable)
    else:
        script_dir = os.path.dirname(os.path.abspath(__file__))

    excel_path = os.path.join(script_dir, 'Smart_NPL.xlsm')

    app_08_infocare_analysis.infocare_analysis().run_app(filepath=excel_path)

def run_infocare_integrated():
    check_expiry()
    import app_09_infocare_integrated  # 지연 임포트
    if getattr(sys, 'frozen', False):
        script_dir = os.path.dirname(sys.executable)
    else:
        script_dir = os.path.dirname(os.path.abspath(__file__))

    excel_path = os.path.join(script_dir, 'Smart_NPL.xlsm')

    app_09_infocare_integrated.inforcare_integrated().run_app(filepath=excel_path)

def run_infocare_case():
    check_expiry()
    import app_10_infocare_case  # 지연 임포트
    if getattr(sys, 'frozen', False):
        script_dir = os.path.dirname(sys.executable)
    else:
        script_dir = os.path.dirname(os.path.abspath(__file__))

    excel_path = os.path.join(script_dir, 'Smart_NPL.xlsm')

    app_10_infocare_case.infocare_case().run_app(filepath=excel_path)

if __name__ == '__main__':
    check_expiry()
    parser = argparse.ArgumentParser(description="Run specific app functions")
    parser.add_argument("app", choices=[
        "run_kb_info", 
        "run_court_auction", 
        "run_infocare_analysis", 
        "run_infocare_integrated", 
        "run_infocare_case", 
        "run_get_registry_basic_info",
        "run_valuemap",
        "run_register_inquiry",
        "run_posting_price",
        "run_gookto_real_price",
        "run_gookto_calculate_distance",
        "run_valuemap_calculate_distance"
    ], help="Choose which app function to run")
    
    args = parser.parse_args()

    if args.app == "run_kb_info":
        run_kb_info()
    elif args.app == "run_court_auction":
        run_court_auction()
    elif args.app == "run_infocare_analysis":
        run_infocare_analysis()
    elif args.app == "run_infocare_integrated":
        run_infocare_integrated()
    elif args.app == "run_infocare_case":
        run_infocare_case()
    elif args.app == "run_get_registry_basic_info":
        run_get_registry_basic_info()
    elif args.app == "run_valuemap":
        run_valuemap()
    elif args.app == "run_register_inquiry":
        run_register_inquiry()
    elif args.app == "run_posting_price":
        run_posting_price()
    elif args.app == "run_gookto_real_price":
        run_gookto_real_price()
    elif args.app == "run_gookto_calculate_distance":
        run_gookto_calculate_distance()
    elif args.app == "run_valuemap_calculate_distance":
        run_valuemap_calculate_distance()
