import os
from datetime import datetime
import pandas as pd
import requests
from math import radians, sin, cos, sqrt, atan2
import concurrent.futures
import threading
import logging  # 로깅 모듈 추가

# Kakao API 호출 함수
def call_kakao_api(address_name, kakao_api_key):
    url = "https://dapi.kakao.com/v2/local/search/address.json"
    headers = {"Authorization": f"KakaoAK {kakao_api_key}"}
    params = {"query": address_name, "size": "30"}
    try:
        response_kakao = requests.get(url, headers=headers, params=params)
        response_kakao.raise_for_status()
        data = response_kakao.json()
        return data
    except requests.exceptions.RequestException as e:
        logging.error(f"API 호출에 실패했습니다: {e}")  # print 대신 logging 사용
        return {"error": "API 호출에 실패했습니다. 입력값을 확인해주세요"}

# 1. Load API key and paths from Excel
def load_api_key_and_paths_from_excel(excel_path):
    df = pd.read_excel(excel_path, sheet_name='Source', engine='openpyxl')
    report_folder_path = df.loc[df.iloc[:, 0] == '보고서폴더경로', df.columns[1]].values[0]
    kakao_api_key = df.loc[df.iloc[:, 0] == 'kakao_apikey', df.columns[1]].values[0]
    return report_folder_path, kakao_api_key

# 2. Load input data from Excel
def load_input_data_from_excel(excel_path):
    df = pd.read_excel(excel_path, sheet_name='Output_실거래가_국토', header=5)
    df.columns = df.columns.str.strip()
    # '대상여부'가 비어있지 않은 행만 유지
    df = df[df['대상여부'].notna()]
    return df

# 3. Create '대상주소' column
def create_target_address_column(df):
    df['대상주소'] = df[['도/시', '군/구', 'umdNm', 'jibun']].astype(str).agg(' '.join, axis=1)
    return df

# Modified function to get target coordinates using unique addresses and progress updates
def get_target_coordinates_concurrent(df, kakao_api_key):
    df = df.copy()
    addresses = df['대상주소'].unique()  # Extract unique addresses
    address_to_coords = {}
    total = len(addresses)
    progress_counter = 0
    progress_lock = threading.Lock()  # Lock for progress updates

    def fetch_coordinates(address):
        nonlocal progress_counter
        try:
            data = call_kakao_api(address, kakao_api_key)
            if 'error' in data:
                coords = (None, None)
            else:
                try:
                    x = data['documents'][0]['address']['x']
                    y = data['documents'][0]['address']['y']
                    coords = (x, y)
                except (IndexError, KeyError):
                    coords = (None, None)
            # Update progress
            with progress_lock:
                progress_counter += 1
                logging.info(f"API 호출 성공! [{progress_counter} / {total}] {address}")  # logging 사용
            return (address, coords)
        except BrokenPipeError as e:
            logging.exception(f"BrokenPipeError in fetch_coordinates: {e}")
            raise
        except Exception as e:
            logging.exception(f"Error in fetch_coordinates: {e}")
            raise

    # Use ThreadPoolExecutor for concurrent API calls
    with concurrent.futures.ThreadPoolExecutor(max_workers=10) as executor:
        future_to_address = {executor.submit(fetch_coordinates, addr): addr for addr in addresses}
        for future in concurrent.futures.as_completed(future_to_address):
            try:
                address, coords = future.result()
                address_to_coords[address] = coords
            except Exception as e:
                logging.error(f"Error fetching coordinates for address: {future_to_address[future]} - {e}")

    # Map coordinates back to the original DataFrame
    df['대상_x'] = df['대상주소'].map(lambda addr: address_to_coords.get(addr, (None, None))[0])
    df['대상_y'] = df['대상주소'].map(lambda addr: address_to_coords.get(addr, (None, None))[1])
    return df

# 6. Calculate distance between (x, y) and (대상_x, 대상_y)
def haversine(lon1, lat1, lon2, lat2):
    R = 6371  # 지구의 반지름 (킬로미터)
    try:
        lon1_rad, lat1_rad, lon2_rad, lat2_rad = map(radians, [float(lon1), float(lat1), float(lon2), float(lat2)])
    except (TypeError, ValueError) as e:
        logging.error(f"좌표 변환 에러: {e}")
        return None
    dlon = lon2_rad - lon1_rad
    dlat = lat2_rad - lat1_rad
    a = sin(dlat / 2)**2 + cos(lat1_rad) * cos(lat2_rad) * sin(dlon / 2)**2
    c = 2 * atan2(sqrt(a), sqrt(1 - a))
    distance = R * c * 1000  # 미터로 변환
    return distance

# 2. Round '거리' to the nearest integer
def calculate_distance(df):
    df = df.copy()
    # Convert coordinates to numeric
    df['x'] = pd.to_numeric(df['x'], errors='coerce')
    df['y'] = pd.to_numeric(df['y'], errors='coerce')
    df['대상_x'] = pd.to_numeric(df['대상_x'], errors='coerce')
    df['대상_y'] = pd.to_numeric(df['대상_y'], errors='coerce')
    # Calculate distance
    df['거리(m)'] = df.apply(
        lambda row: haversine(row['x'], row['y'], row['대상_x'], row['대상_y'])
        if pd.notnull(row['x']) and pd.notnull(row['대상_x']) else None, axis=1)
    # Round '거리' to the nearest integer
    df['거리(m)'] = df['거리(m)'].round(0).astype('Int64')
    return df

# 7. Sort df within '등기부등본고유번호' blocks by '거리(m)'
def sort_within_blocks(df):
    df_sorted = df.groupby('등기부등본고유번호', group_keys=False).apply(lambda x: x.sort_values('거리(m)'))
    return df_sorted

# 8. Drop specified columns and rearrange the remaining columns
def rearrange_columns(df):
    columns_to_drop = ['x', 'y', '도/시', '군/구', 'umdNm', 'jibun', '대상여부', '대상_x', '대상_y', 'sggCd']
    df = df.drop(columns=columns_to_drop, errors='ignore')
    desired_column_order = [
        '등기부등본고유번호', '등기부등본구분', '등기부등본주소', '실거래가_조회기간(2)', '실거래가_구분', 'houseType', '거리(m)', '대상주소',
        '건물이름', 'aptDong', 'dealAmount', 'dealYear', 'dealMonth', 'dealDay', 'excluUseAr', 'floor',
        'buildYear', 'buyerGbn', 'dealingGbn'
    ]
    # Ensure that only existing columns are selected
    existing_columns = [col for col in desired_column_order if col in df.columns]
    df = df[existing_columns]
    return df

# 9. Export df to Excel
def export_to_excel(df, report_folder_path):
    # Get the report name from the last directory in the report_folder_path
    report_name = os.path.basename(report_folder_path.rstrip(os.sep))
    
    # Create Temp and 거리계산_국토교통부 directories
    temp_dir = os.path.join(report_folder_path, 'Temp')
    os.makedirs(temp_dir, exist_ok=True)
    target_dir = os.path.join(temp_dir, '거리계산_국토교통부')
    os.makedirs(target_dir, exist_ok=True)
    
    # Create the temporary file path
    temp_file_name = f"Temp_Output_거리계산_국토교통부_{report_name}.xlsx"
    temp_file_path = os.path.join(target_dir, temp_file_name)
    
    # Final file path after renaming
    final_file_name = f"Output_거리계산_국토교통부_{report_name}.xlsx"
    final_file_path = os.path.join(target_dir, final_file_name)
    
    # Save to Excel (as temporary file first)
    try:
        df.to_excel(temp_file_path, sheet_name='Output_거리_국토', index=False)
        logging.info(f"Temporary data has been saved to {temp_file_path}")
    except Exception as e:
        logging.error(f"Error saving temporary Excel file: {e}")
        return

    # Rename the temporary file to the final file name
    try:
        os.rename(temp_file_path, final_file_path)
        logging.info(f"File renamed to: {final_file_path}")
    except Exception as e:
        logging.error(f"Error renaming file {temp_file_path} to {final_file_path}: {e}")

# Main function
def run_gookto_calculate_distance(excel_path="Smart_NPL.xlsm"):
    # API 키 및 경로 가져오기
    report_folder_path, kakao_api_key = load_api_key_and_paths_from_excel(excel_path)
    
    # Set up logging after report_folder_path is known
    output_dir = os.path.join(report_folder_path, 'Temp', '거리계산_국토교통부')
    os.makedirs(output_dir, exist_ok=True)

    timestamp = datetime.now().strftime('%y%m%d_%H%M%S')
    log_file_path = os.path.join(output_dir, f'gookto_calculate_distance_{timestamp}.log')

    # Set up logger with FileHandler and StreamHandler
    logging.basicConfig(
        level=logging.INFO,
        format='%(asctime)s %(levelname)s:%(message)s',
        datefmt='%Y-%m-%d %H:%M:%S',
        handlers=[
            logging.FileHandler(log_file_path, encoding='utf-8'),
            logging.StreamHandler()
        ]
    )
    
    logging.info("Starting run_gookto_calculate_distance")
    logging.info("보고서폴더경로와 API 키를 불러왔습니다.")
    
    # Step 2: Load input data
    input_df = load_input_data_from_excel(excel_path)
    logging.info("입력 데이터를 불러왔습니다.")
    
    # Step 3: Create '대상주소' column
    df_with_address = create_target_address_column(input_df)
    
    # Step 4: Get '대상_x' and '대상_y' coordinates using unique addresses and multithreading
    logging.info("사례 좌표를 가져오는 중...")
    df_with_coordinates = get_target_coordinates_concurrent(df_with_address, kakao_api_key)
    logging.info("사례 좌표를 가져왔습니다.")
    
    # Step 5: df_with_coordinates already contains '대상_x' and '대상_y'
    
    # Step 6: Calculate distance and round to nearest integer
    logging.info("거리 계산 중...")
    df_with_distance = calculate_distance(df_with_coordinates)
    logging.info("거리 계산 완료")
    
    # Step 7: Sort within '등기부등본고유번호' blocks by '거리(m)'
    df_sorted = sort_within_blocks(df_with_distance)
    
    # Step 8: Rearrange columns and drop unnecessary ones
    df_final = rearrange_columns(df_sorted)
    
    # Step 9: Export to Excel
    export_to_excel(df_final, report_folder_path)
    logging.info("run_gookto_calculate_distance completed successfully.")

if __name__ == "__main__":
    excel_path = "Smart_NPL.xlsm"
    run_gookto_calculate_distance(excel_path)
