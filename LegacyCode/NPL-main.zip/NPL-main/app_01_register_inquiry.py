import os
from datetime import datetime
import pandas as pd
import requests
import re
import logging  # 로깅 모듈 임포트

# Initialize a logger
logger = logging.getLogger(__name__)

def load_api_keys_and_paths_from_excel(excel_path):
    """
    SmartNPL.xlsm 파일의 'Source' 시트에서 API 키와 보고서 폴더 경로를 불러오는 함수.
    """
    # 엑셀 파일에서 'Source' 시트를 읽어옵니다.
    df = pd.read_excel(excel_path, sheet_name='Source', engine='openpyxl')
    
    # 필요한 값들을 추출 (각 항목의 첫 번째 열과 두 번째 열을 기준으로)
    hyphen_id = df.loc[df.iloc[:, 0] == 'hyphen_id', df.columns[1]].values[0]
    hyphen_apikey = df.loc[df.iloc[:, 0] == 'hyphen_apikey', df.columns[1]].values[0]
    iros_id = df.loc[df.iloc[:, 0] == 'iros_id', df.columns[1]].values[0]
    iros_pw = df.loc[df.iloc[:, 0] == 'iros_pw', df.columns[1]].values[0]
    base_path = df.loc[df.iloc[:, 0] == '보고서폴더경로', df.columns[1]].values[0]

    return hyphen_id, hyphen_apikey, iros_id, iros_pw, base_path

def load_input_data_from_excel(excel_path):
    """
    'Input_등본조회' 시트에서 B6 셀부터 데이터를 가져오고, A열을 제외하는 함수.
    """
    # header=5를 사용해 B6셀부터 읽어오고, 'Unnamed: 0' 컬럼은 제외함
    df = pd.read_excel(excel_path, sheet_name='Input_등본조회', header=5, usecols=lambda column: column != 'Unnamed: 0')
    df.columns = df.columns.str.strip()  # 컬럼명 공백 제거
    return df  # 전체 DataFrame 반환

def call_property_details(uniq_no, hyphen_id, hyphen_apikey, iros_id, iros_pw):
    """
    API 요청을 통해 부동산등기부등본 정보를 가져오는 함수.
    """
    # API 요청 URL 설정
    url = "https://api.hyphen.im/in0004001438"
    # 헤더 설정 (엑셀에서 불러온 회원ID와 보안키 사용)
    headers = {
        # "hyphen-gustation": "Y",
        "Content-Type": "application/json",  # JSON 형식으로 데이터 전송
        "user-id": hyphen_id,
        "Hkey": hyphen_apikey,
    }
    # 요청 바디 설정 (API 요청에 필요한 여러 옵션 지정)
    body = {
        "userId": iros_id,
        "userPw": iros_pw,
        "searchDiv": "uniqNo",
        "uniqNo": uniq_no.replace('-',''),
        "summary": "Y",
        "cmortCheck": "Y",
        "tradeCheck": "Y",
        "pdfHex": "N",
        "xmlYn": "N",
        "display": "1",  # 말소사항 포함여부. 1: 미포함, 2: 포함
        "dupChk": "Y",
        "excRegYn" : "Y", # 과다등기 진행여부 (Y : 진행, N : 진행안함)
        "closingYn" : "Y", # 폐쇄등기 진행여부 (Y : 진행, N : 진행안함)
        "kindcls" : "0",  # 부동산구분 (0: 조회된 부동산구분과 상관없이 진행)
        "kindclsYn" : "N" # 부동산구분 출력여부 (Y : 포함, N : 미포함)
    }

    # API 호출 로그 출력
    logger.info(f"등기부등본 API를 호출합니다... (고유번호: {uniq_no})")
    try:
        # POST 요청 보내기
        response = requests.post(url, headers=headers, json=body)
    except requests.exceptions.RequestException as e:
        logger.error(f"API 요청 중 예외 발생 (고유번호: {uniq_no}): {e}")
        return None

    # 응답 상태 코드에 따라 처리
    if response.status_code == 200:
        logger.info("부동산등기부등본 호출 성공")
        print(response.json())
        return response.json()
    else:
        logger.error(f"Request failed with status code: {response.status_code}")
        logger.error(f"Response: {response.text}")
        return None

def json_to_dataframe(json_data):
    """
    JSON 데이터를 DataFrame으로 변환하는 함수.
    """
    def parse_json_three_columns_v2(data, prefix=''):
        # 재귀적으로 JSON 데이터를 파싱하여 3개의 컬럼(대구분, 소구분, 내용)으로 변환
        rows = []
        if isinstance(data, dict):
            for key, value in data.items():
                new_prefix = f"{prefix} {key}".strip()
                rows.extend(parse_json_three_columns_v2(value, new_prefix))
        elif isinstance(data, list):
            for item in data:
                rows.extend(parse_json_three_columns_v2(item, prefix))
        else:
            # prefix를 기준으로 대구분과 소구분으로 나누어 저장
            prefix_parts = prefix.split(maxsplit=1)
            if len(prefix_parts) == 1:
                rows.append([prefix_parts[0], '', data])
            else:
                rows.append([prefix_parts[0], prefix_parts[1], data])
        return rows

    # 'data' 및 'outList' 키가 존재하는지 확인 후 파싱
    try:
        if 'data' in json_data and 'outList' in json_data['data']:
            parsed_data = parse_json_three_columns_v2(json_data['data']['outList'])
        else:
            logger.error("JSON 데이터에 'data' 또는 'outList' 키가 없습니다.")
            return pd.DataFrame()
    except KeyError as e:
        logger.error(f"JSON 데이터 파싱 중 KeyError 발생: {e}")
        return pd.DataFrame()

    # 파싱된 데이터를 DataFrame으로 변환
    df = pd.DataFrame(parsed_data, columns=['대구분', '소구분', '내용'])

    # 대구분과 소구분 컬럼의 누락된 값들을 채움
    df['대구분'] = df['대구분'].ffill()
    df['소구분'] = df['소구분'].ffill()

    # 추가적으로 고유번호와 주소 정보를 DataFrame에 삽입
    try:
        if isinstance(json_data['data']['outList'], dict):
            고유번호 = json_data['data']['outList'].get('고유번호', '')
            주소 = json_data['data']['outList'].get('지번_및_번호', '')
        else:
            고유번호 = ''
            주소 = ''
    except KeyError as e:
        logger.error(f"JSON 데이터에서 '고유번호' 또는 '지번_및_번호' 키를 찾을 수 없습니다: {e}")
        고유번호 = ''
        주소 = ''

    df['고유번호'] = 고유번호
    df['주소'] = 주소

    # 최종 컬럼 순서 지정
    df = df[['고유번호', '주소', '대구분', '소구분', '내용']]

    return df

def extract_value_from_columns(df, d_col_val, s_col_val=None, default_value='N/A'):
    """
    두 개의 column ('대구분' 및 '소구분')을 탐색하여 조건을 만족하는 '내용' 값을 반환하는 함수.
    값을 찾지 못하면 default_value('N/A')를 반환.
    """
    if s_col_val is not None:
        filtered = df[(df['대구분'] == d_col_val) & (df['소구분'] == s_col_val)]
    else:
        filtered = df[df['대구분'] == d_col_val]

    if not filtered.empty:
        return filtered['내용'].values[0]
    return default_value  # 조건에 맞는 값이 없으면 N/A 반환

def extract_numbers_from_text(text):
    """
    텍스트에서 숫자를 추출하여 리스트로 반환하는 함수.
    """
    return list(map(float, re.findall(r'\d+\.?\d*', str(text))))

def calculate_ratio_from_text(text):
    """
    '분의' 텍스트를 기준으로 앞뒤 숫자를 나누어 비율을 계산하는 함수.
    예: "1분의2" -> 2/1 계산.
    """
    # 줄바꿈 및 불필요한 공백 제거
    text = text.replace('\n', '').replace('\r', '').replace(' ', '')
    # '분의' 패턴을 찾아 앞뒤 숫자 추출
    match = re.search(r'(\d+\.?\d*)\s*분의\s*(\d+\.?\d*)', text)
    if match:
        denominator = float(match.group(1))
        numerator = float(match.group(2))
        if denominator != 0:
            return numerator / denominator
    return None

def format_unique_number(unique_no):
    """
    등기부등본고유번호를 xxxx-xxxx-xxxxxx 형식으로 포맷팅하는 함수.
    """
    unique_no_str = str(unique_no)
    return f"{unique_no_str[:4]}-{unique_no_str[4:8]}-{unique_no_str[8:]}"

def convert_date_format(date_str):
    """
    날짜 문자열을 "YYYY-MM-DD" 형식으로 변환하는 함수.
    예: "2025년3월27일" -> "2025-03-27"
    """
    match = re.match(r"(\d{4})년(\d{1,2})월(\d{1,2})일", date_str)
    if match:
        year, month, day = match.groups()
        return f"{year}-{month.zfill(2)}-{day.zfill(2)}"
    else:
        return 'N/A'

def create_final_sheet(df, input_df, uniq_no, error_msg=None):
    """
    'final' 시트를 생성하여 데이터를 정리하는 함수.
    - 정상적인 경우: 여러 계산된 값을 이용하여 각 항목을 구성함.
    - 에러 발생 시: error_msg가 제공되면 '토지_면적' 칼럼에 "Error : " 접두어와 함께 에러 메시지를 입력하고, 나머지 칼럼은 빈 문자열로 처리.
    """
    # input_df에서 현재 고유번호(uniq_no)에 해당하는 데이터를 선택
    row = input_df[input_df['등기부등본고유번호'] == uniq_no].iloc[0]
    usage = row['등기부등본구분']
    address = row['등기부등본주소']
    
    # 에러 발생 시, 에러 메시지를 포함한 결과 반환
    if error_msg is not None:
        final_data = [{
            '등기부등본고유번호': uniq_no,
            '등기부등본구분': usage,
            '등기부등본주소': address,
            '토지_면적': "Error : " + error_msg,  # 에러 메시지 앞에 "Error : " 접두어 추가
            '토지_대지권비율': '',
            '건물구조': '',
            '건물내역': '',
            '대지권_토지_면적': '',
            '대지권_비율': '',
            '대지권_대상_면적': '',
            '경매정보': '',
            '건물_접수일': '',
            '공유지분 여부': ''
        }]
        return pd.DataFrame(final_data)
    
    # 에러가 없을 경우, 기존 데이터 처리 로직 수행
    df = clean_special_characters(df)
    final_data = []

    # 토지 면적 처리: 값 추출 후 숫자 합산 
    land_area_raw = extract_value_from_columns(df, '면적', default_value='N/A')
    if land_area_raw != 'N/A':
        land_area = sum(extract_numbers_from_text(land_area_raw))
    else:
        land_area = 'N/A'
        
    # 대지권 비율 값 추출
    land_ratio = extract_value_from_columns(df, '대지권비율', default_value='N/A')
    
    # 건물 구조 정보 처리 (두 항목 결합)
    building_structure_raw = extract_value_from_columns(df, '표제부_1동의_건물의_표시', '건물내역', default_value='N/A')
    if building_structure_raw != 'N/A':
        building_structure = re.split('지붕', building_structure_raw)[0] + '지붕'
    else:
        building_structure = 'N/A'
    building_structure_raw_individual = extract_value_from_columns(df, '표제부_건물의_표시', '건물내역', default_value='N/A')
    if building_structure_raw_individual != 'N/A':
        building_structure_individual = re.split('지붕', building_structure_raw_individual)[0] + '지붕'
    else:
        building_structure_individual = 'N/A'
    building_structure = building_structure if building_structure != 'N/A' else ''
    building_structure_individual = building_structure_individual if building_structure_individual != 'N/A' else ''
    building_structure = (building_structure + building_structure_individual).strip() if (building_structure + building_structure_individual).strip() else 'N/A'

    # 건물 내역 처리 (전유부분과 개별 건물 내역 결합)
    building_detail_values = extract_value_from_columns(df, '표제부_전유부분_건물의_표시', '건물내역', default_value='N/A')
    if building_detail_values != 'N/A':
        building_detail = sum(extract_numbers_from_text(building_detail_values))
    else:
        building_detail = 'N/A'
    building_detail_values_individual = extract_value_from_columns(df, '표제부_건물의_표시', '건물내역', default_value='N/A')
    if building_detail_values_individual != 'N/A':
        building_detail_individual = sum(extract_numbers_from_text(building_detail_values_individual))
    else:
        building_detail_individual = 'N/A'
    building_detail = str(building_detail) if building_detail != 'N/A' else ''
    building_detail_individual = str(building_detail_individual) if building_detail_individual != 'N/A' else ''
    building_detail = (building_detail + building_detail_individual).strip() if (building_detail + building_detail_individual).strip() else 'N/A'

    # 건물 접수일 처리: 두 날짜 정보 결합
    building_detail_resigtry = extract_value_from_columns(df, '표제부_전유부분_건물의_표시', '접수', default_value='N/A')
    if building_detail_resigtry != 'N/A':
        building_resigtry = convert_date_format(building_detail_resigtry)
    else:
        building_resigtry = 'N/A'
    building_detail_registry_2 = extract_value_from_columns(df, '표제부_건물의_표시', '접수', default_value='N/A')
    if building_detail_registry_2 != 'N/A':
        building_registry_2 = convert_date_format(building_detail_registry_2)
    else:
        building_registry_2 = 'N/A'
    building_resigtry = str(building_resigtry) if building_resigtry != 'N/A' else ''
    building_registry_2 = str(building_registry_2) if building_registry_2 != 'N/A' else ''
    building_resigtry = (building_resigtry + building_registry_2).strip() if (building_resigtry + building_registry_2).strip() else 'N/A'

    # 대지권 토지 면적 처리
    land_right_area_values = extract_value_from_columns(df, '표제부_대지권의_목적인_토지의_표시', '면적', default_value='N/A')
    if land_right_area_values != 'N/A':
        land_right_area = sum(extract_numbers_from_text(land_right_area_values))
    else:
        land_right_area = 'N/A'
    land_right_ratio_raw = extract_value_from_columns(df, '표제부_대지권의_표시', '대지권비율', default_value='N/A')
    land_right_ratio = calculate_ratio_from_text(land_right_ratio_raw) if land_right_ratio_raw != 'N/A' else 'N/A'
    if land_right_area != 'N/A' and land_right_ratio != 'N/A':
        land_target_area = land_right_area * land_right_ratio
    else:
        land_target_area = 'N/A'
        
    # 경매정보 처리: '내용' 열에서 정규표현식을 통해 값 추출
    auction_info_pattern = r'\d{4}\s*타경\s*\d{1,6}'
    auction_info_rows = df[df['내용'].str.contains(auction_info_pattern, na=False)]
    if not auction_info_rows.empty:
        auction_info = " ".join(auction_info_rows['내용'].values)
        auction_info = auction_info.replace('\n', '').replace('\r', '')
    else:
        auction_info = 'N/A'

    # 공유지분 여부 처리: '내용' 열에 "공유자" 단어가 존재하면 'Y', 아니면 'N'
    share_info_rows = df[df['내용'].str.contains('공유자', na=False)]
    share_info = 'Y' if not share_info_rows.empty else 'N'

    # 최종 데이터를 리스트에 추가
    final_data.append({
        '등기부등본고유번호': uniq_no,
        '등기부등본구분': usage,
        '등기부등본주소': address,
        '토지_면적': land_area,
        '토지_대지권비율': land_ratio,
        '건물구조': building_structure,
        '건물내역': building_detail,
        '대지권_토지_면적': land_right_area,
        '대지권_비율': land_right_ratio,
        '대지권_대상_면적': land_target_area,
        '경매정보': auction_info,
        '건물_접수일': building_resigtry,
        '공유지분 여부': share_info
    })

    final_df = pd.DataFrame(final_data)
    return final_df

def clean_special_characters(df):
    """
    데이터프레임에서 '_x005F_x000D_'와 같은 특수 문자를 제거하고,
    개행 문자는 줄바꿈으로 유지하는 함수.
    """
    # 정규표현식을 사용하여 특수 문자를 제거
    df = df.replace(to_replace=r'_x[0-9A-F]{4}_', value='', regex=True)
    # 문자열 컬럼에 대해 개행 문자는 유지하면서, 불필요한 문자를 제거
    df = df.apply(lambda x: x.str.replace('\r', '').str.replace('\n', '\n') if x.dtype == "object" else x)
    return df

def save_dataframe_to_excel(df, unique_id, base_path, input_df, error_msg=None):
    """
    DataFrame을 지정된 경로에 중간 산출물과 함께 'final' 시트를 추가하여 저장하는 함수.
    - error_msg가 제공되면, create_final_sheet 함수에 전달하여 에러 내용을 표시합니다.
    """
    save_dir = os.path.join(base_path, 'Temp', '등기부등본')
    os.makedirs(save_dir, exist_ok=True)
    file_name = f"{unique_id}_등본조회.xlsx"
    file_path = os.path.join(save_dir, file_name)

    # df의 각 셀에서 불필요한 문자 제거 (숫자+^ 패턴)
    for col_num, col in enumerate(df.columns):
        for row_num, value in enumerate(df[col]):
            if isinstance(value, str):
                clean_value = re.sub(r'\d+\^', '', value)
                df.at[row_num, col] = clean_value

    # 모든 데이터를 문자열로 변환하여 엑셀에서 날짜 자동 변환 방지
    df = df.astype(str)

    with pd.ExcelWriter(file_path, engine='xlsxwriter') as writer:
        # 'Sheet1'에 전체 데이터 저장
        df.to_excel(writer, index=False, sheet_name='Sheet1')

        workbook = writer.book
        worksheet = writer.sheets['Sheet1']

        # 취소선 형식 정의 (특정 조건에 따른 포맷 적용)
        strike_format = workbook.add_format({'font_strikeout': True})

        # 각 셀에 대해 '&' 포함시 취소선 적용 후 쓰기
        for col_num, col in enumerate(df.columns):
            for row_num, value in enumerate(df[col], start=1):
                if isinstance(value, str):
                    if '&' in value:
                        clean_value = value.replace('&', '')
                        worksheet.write(row_num, col_num, clean_value, strike_format)
                    else:
                        worksheet.write(row_num, col_num, value)
                else:
                    worksheet.write(row_num, col_num, value)

        # final 시트 생성 (에러 메시지 존재 시 error_msg 인수를 전달)
        final_df = create_final_sheet(df, input_df, unique_id, error_msg)
        final_df.to_excel(writer, index=False, sheet_name='final')

    logger.info(f"File saved at: {file_path}")

def merge_and_cleanup_final_sheets(output_dir):
    """
    중간산출물 파일들을 병합하여 최종 산출물로 저장하고,
    병합 대상 파일들을 삭제하는 함수.
    'Data' 시트에는 각 중간 산출물의 'Sheet1' 데이터가,
    'final' 시트에는 각 중간 산출물의 'final' 데이터가 병합됨.
    """
    # 지정된 폴더 내의 엑셀 파일 목록 추출 (Output 파일은 제외)
    excel_files = [f for f in os.listdir(output_dir) if f.endswith(".xlsx") and not f.startswith("Output")]
    
    if not excel_files:
        logger.info("병합할 파일이 없습니다.")
        return
    
    merged_data = []
    merged_final = []

    for file in excel_files:
        file_path = os.path.join(output_dir, file)

        try:
            # 'Sheet1' 시트 데이터 읽기
            df_data = pd.read_excel(file_path, sheet_name='Sheet1', engine='openpyxl', header=0)
            # 컬럼명을 문자열로 변환 후, Unnamed 컬럼 제거
            df_data.columns = df_data.columns.astype(str)
            df_data = clean_special_characters(df_data)
            df_data = df_data.loc[:, ~df_data.columns.str.contains('^Unnamed')]
            merged_data.append(df_data)
        except ValueError as e:
            logger.error(f"Error reading 'Sheet1' from {file}: {e}")
            continue

        try:
            # 'final' 시트 데이터 읽기
            df_final = pd.read_excel(file_path, sheet_name='final', engine='openpyxl', header=0)
            df_final.columns = df_final.columns.astype(str)
            df_final = clean_special_characters(df_final)
            merged_final.append(df_final)
        except ValueError as e:
            logger.error(f"Error reading 'final' from {file}: {e}")
            continue

    # 병합된 DataFrame 생성
    if merged_data:
        final_merged_data_df = pd.concat(merged_data, ignore_index=True)
        if '고유번호' in final_merged_data_df.columns:
            final_merged_data_df.rename(columns={'고유번호': '등기부등본고유번호'}, inplace=True)
            final_merged_data_df['등기부등본고유번호'] = final_merged_data_df['등기부등본고유번호'].apply(format_unique_number)
    else:
        final_merged_data_df = pd.DataFrame()
        logger.warning("병합된 'Data' 시트 데이터가 없습니다.")

    if merged_final:
        final_merged_final_df = pd.concat(merged_final, ignore_index=True)
    else:
        final_merged_final_df = pd.DataFrame()
        logger.warning("병합된 'final' 시트 데이터가 없습니다.")

    # 병합 후, 개별 파일 삭제
    for file in excel_files:
        file_path = os.path.join(output_dir, file)
        try:
            os.remove(file_path)
            logger.info(f"파일 삭제됨: {file_path}")
        except OSError as e:
            logger.error(f"Error deleting file {file_path}: {e}")

    # 상위 디렉토리 이름을 추출하여 보고서명으로 사용
    report_name = os.path.basename(os.path.dirname(os.path.dirname(output_dir)))
    temp_merged_file_path = os.path.join(output_dir, f"Temp_Output_등본조회_{report_name}.xlsx")
    final_merged_file_path = os.path.join(output_dir, f"Output_등본조회_{report_name}.xlsx")

    # 병합된 DataFrame을 임시 파일로 저장
    with pd.ExcelWriter(temp_merged_file_path, engine='xlsxwriter') as writer:
        final_merged_data_df.to_excel(writer, index=False, sheet_name='Output_등본조회(전체)')
        final_merged_final_df.to_excel(writer, index=False, sheet_name='Output_등본조회')

    logger.info(f"Temporary merged file saved at: {temp_merged_file_path}")

    # 임시 파일을 최종 파일로 이름 변경
    try:
        os.rename(temp_merged_file_path, final_merged_file_path)
        logger.info(f"File renamed to: {final_merged_file_path}")
    except OSError as e:
        logger.error(f"Error renaming file {temp_merged_file_path} to {final_merged_file_path}: {e}")

def run_register_inquiry(excel_path):
    """
    전체 프로세스를 실행하는 함수.
    1. API 키 및 경로 정보를 엑셀에서 불러옴.
    2. 입력 데이터(등본조회)를 읽어옴.
    3. 각 고유번호에 대해 API 호출 후 중간 산출물(엑셀 파일) 생성.
    4. 모든 중간 산출물을 병합하여 최종 산출물 생성.
    """
    hyphen_id, hyphen_apikey, iros_id, iros_pw, base_path = load_api_keys_and_paths_from_excel(excel_path)
    
    output_dir = os.path.join(base_path, 'Temp', '등기부등본')
    os.makedirs(output_dir, exist_ok=True)

    # 로그 파일 경로 및 포맷 설정
    timestamp = datetime.now().strftime('%y%m%d_%H%M%S')
    log_file_path = os.path.join(output_dir, f'register_inquiry_{timestamp}.log')

    logging.basicConfig(
        level=logging.INFO,
        format='%(asctime)s %(levelname)s:%(message)s',
        datefmt='%Y-%m-%d %H:%M:%S',
        handlers=[
            logging.FileHandler(log_file_path, encoding='utf-8'),
            logging.StreamHandler()
        ]
    )

    # 입력 데이터 읽기 (등본조회 시트)
    input_df = load_input_data_from_excel(excel_path)

    # 각 행(고유번호)에 대해 API 호출 및 중간 산출물 생성
    for _, row in input_df.iterrows():
        uniq_no = row['등기부등본고유번호']
        
        if pd.isna(uniq_no):
            logger.warning(f"유효하지 않은 고유번호: {uniq_no}. API 호출을 건너뜁니다.")
            continue

        save_dir = os.path.join(base_path, 'Temp', '등기부등본')
        file_name = f"{uniq_no}_등본조회.xlsx"
        file_path = os.path.join(save_dir, file_name)

        # 이미 중간 산출물이 존재하는 경우 API 호출 건너뜀
        if os.path.exists(file_path):
            logger.info(f"중간산출물 파일이 이미 존재합니다. (고유번호: {uniq_no}) API 호출을 건너뜁니다.")
            continue

        # API 호출
        property_details_response = call_property_details(uniq_no, hyphen_id, hyphen_apikey, iros_id, iros_pw)
        
        if property_details_response:
            try:
                # API 응답에 에러가 있는지 체크 (errYn 값으로 판단)
                if property_details_response.get("common", {}).get("errYn") == "Y":
                    error_msg = property_details_response.get("common", {}).get("errMsg", "Unknown error")
                    logger.error(f"API 에러 발생 (고유번호: {uniq_no}): {error_msg}")
                    # 에러 발생 시, 빈 DataFrame과 error_msg를 전달하여 중간 산출물 생성
                    property_details_df = pd.DataFrame()
                    save_dataframe_to_excel(property_details_df, uniq_no, base_path, input_df, error_msg=error_msg)
                else:
                    # 정상 응답인 경우 JSON을 DataFrame으로 변환하여 저장
                    property_details_df = json_to_dataframe(property_details_response)
                    if not property_details_df.empty:
                        save_dataframe_to_excel(property_details_df, uniq_no, base_path, input_df)
                    else:
                        logger.error(f"Empty DataFrame for uniq_no {uniq_no}. API response might be invalid.")
                        logger.error(f"API response content: {property_details_response}")
            except Exception as e:
                logger.error(f"Error processing response for uniq_no {uniq_no}: {e}")
                logger.error(f"API response content: {property_details_response}")
                continue
        else:
            logger.error(f"No valid response for uniq_no {uniq_no}")
            continue

    # 모든 중간 산출물 생성 후 최종 산출물 병합
    merge_and_cleanup_final_sheets(output_dir)

if __name__ == "__main__":
    excel_path = 'Smart_NPL.xlsm'
    run_register_inquiry(excel_path)
