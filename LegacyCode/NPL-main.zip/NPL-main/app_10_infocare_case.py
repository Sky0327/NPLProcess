from selenium import webdriver
from selenium.webdriver.chrome.options import Options
from selenium.webdriver.common.by import By
from selenium.webdriver.support.ui import WebDriverWait
from selenium.webdriver.support import expected_conditions as EC
import re
from logger import Logger
import time
from openpyxl import load_workbook
import tools as tools
import pandas as pd
import os
import glob
import sys
import openpyxl

class infocare_case():
    def __init__(self) -> None:
        # 실행 파일의 위치 설정
        if getattr(sys, 'frozen', False):
            # PyInstaller로 빌드된 실행 파일인 경우
            exe_dir = os.path.dirname(sys.executable)
        else:
            # 스크립트로 실행되는 경우
            exe_dir = os.path.dirname(os.path.abspath(__file__))

        # 엑셀 파일의 위치
        self.npl_file_path = os.path.join(exe_dir, 'Smart_NPL.xlsm')

        # report_name 선언
        self.report_name = self.get_report_name(self.npl_file_path)

        # 엑셀 파일에서 B3 셀의 경로를 가져옴
        source_path = self.get_excel_path(self.npl_file_path, 'Source', 'B4')

        # 폴더 경로 설정
        self.save_path = os.path.join(source_path, 'Temp', '인포사례상세')
        self.logger = Logger(save_path=self.save_path, function_name='인포사례상세').get_logger()

        self.logger.debug(f'파일 저장 폴더 : {self.save_path}')
        self.logger.debug(f'Smart_NPL file_path : {self.npl_file_path}')      
        self.logger.debug(f'report name : {self.report_name}')  

        #폴더가 없는 경우 폴더 생성
        if not os.path.exists(self.save_path):
            self.logger.debug('파일 저장 경로 폴더 생성')
            os.makedirs(self.save_path)
        else:
            self.logger.debug('파일 저장 경로 존재')

            # 폴더 내 파일 삭제
            for filename in os.listdir(self.save_path):
                file_path = os.path.join(self.save_path, filename)
                try:
                    if os.path.isfile(file_path):  # 파일인지 확인
                        os.remove(file_path)
                        self.logger.debug(f'파일 삭제: {file_path}')
                except Exception as e:
                    self.logger.error(f'파일 삭제 중 오류 발생: {file_path}, {e}')
                    
        self.id, self.pw = self.get_id_pw(self.npl_file_path)
        self.logger.debug(f'id : {self.id}, pw : {self.pw}')

    def get_excel_path(self, file_path, sheet_name, cell):
        """엑셀 파일에서 지정한 시트와 셀의 값을 가져옴"""
        try:
            # 엑셀 파일을 불러오기
            workbook = load_workbook(file_path, data_only=True)
            sheet = workbook[sheet_name]
            
            # 셀의 값을 읽어옴
            path_value = sheet[cell].value
            
            return path_value
        except Exception as e:
            return None


    def get_id_pw(self, file_path):
        # 엑셀 파일 열기
        workbook = openpyxl.load_workbook(file_path)

        # source 시트 선택
        sheet = workbook['Source']
        
        # 'A'열을 순회하면서 '보고서명'을 찾고 해당 행의 'B'열 값을 가져옴
        for row in sheet.iter_rows(min_row=1, max_col=2):  # 'A'열과 'B'열만 확인
            if row[0].value == 'infocare_id':  # 'A'열 값이 '보고서명'이면
                id_str = row[1].value  # 'B'열 값 가져오기

        for row in sheet.iter_rows(min_row=1, max_col=2):  # 'A'열과 'B'열만 확인
            if row[0].value == 'infocare_pw':  # 'A'열 값이 '보고서명'이면
                pw_str = row[1].value  # 'B'열 값 가져오기     

        return id_str, pw_str

    def get_report_name(self, file_path):
        # 엑셀 파일 열기
        workbook = openpyxl.load_workbook(file_path)

        # source 시트 선택
        sheet = workbook['Source']
        
        # 'A'열을 순회하면서 '보고서명'을 찾고 해당 행의 'B'열 값을 가져옴
        for row in sheet.iter_rows(min_row=1, max_col=2):  # 'A'열과 'B'열만 확인
            if row[0].value == '보고서명':  # 'A'열 값이 '보고서명'이면
                b_value = row[1].value  # 'B'열 값 가져오기
                return b_value

        return None  # '보고서명'을 찾지 못했을 때 None 반환

    def get_path(self, file_path):
        # 엑셀 파일 열기
        workbook = openpyxl.load_workbook(file_path)

        # source 시트 선택
        sheet = workbook['Source']
        
        # 'A'열을 순회하면서 '보고서명'을 찾고 해당 행의 'B'열 값을 가져옴
        for row in sheet.iter_rows(min_row=1, max_col=2):  # 'A'열과 'B'열만 확인
            if row[0].value == '보고서폴더경로':  # 'A'열 값이 '보고서명'이면
                b_value = row[1].value  # 'B'열 값 가져오기
                return b_value

        return None  # '보고서명'을 찾지 못했을 때 None 반환

    def merge_excel(self, report_name):

        self.logger.debug('파일병합 시도')

        file_pattern = os.path.join(self.save_path, f'*사례조회_{report_name}.xlsx')
        files = glob.glob(file_pattern)

        # 각 파일의 데이터를 읽어들이고 데이터프레임으로 통합합니다.
        dataframes = []
        for file in files:
            df = pd.read_excel(file)
            dataframes.append(df)

        # 모든 데이터프레임을 하나로 통합
        combined_df = pd.concat(dataframes, ignore_index=True)

        self.logger.debug(combined_df)

        for file in files:
            try:
                os.remove(file)
                print(f"Deleted: {file}")
            except OSError as e:
                print(f"Error deleting {file}: {e}")

        excel_path = os.path.join(self.save_path, f'인포케어_사례조회_{report_name}.xlsx')
        
        combined_df.to_excel(excel_path, sheet_name="Output_인포사례상세", index=False)
        self.logger.debug('파일병합 완료.')
        final_path = os.path.join(self.save_path, f'Output_인포사례상세_{report_name}.xlsx')
        os.rename(excel_path, final_path)
        self.logger.critical('산출물 작성을 완료하였습니다.')

    # def extract_numbers(self, input_string):
    #     """
    #     문자열에서 숫자(소수점 포함)만 추출합니다.

    #     Args:
    #         input_string (str): 입력 문자열
    #     Returns:
    #         str: 숫자와 소수점만 포함된 문자열
    #     """

    #     # 정규식을 사용하여 숫자와 소수점만 남김
    #     result = re.sub(r'[^0-9.]', '', input_string)
        
    #     # 소수점이 여러 개 있을 경우 첫 번째 소수점만 유지
    #     if result.count('.') > 1:
    #         parts = result.split('.')
    #         result = parts[0] + '.' + ''.join(parts[1:])

    #     return result

    # # def extract_land_size_fixed(self, text):
    #     # 첫 번째 패턴: 괄호 안에 대지 면적이 두 가지 형식으로 표시된 경우
    #     match = re.search(r'대지\s*·\s*[\d,]+(\.\d+)?\s*\((\d+(\.\d+)?)/[\d,]+(\.\d+)?\)\s*m²', text, re.DOTALL)
    #     if match:
    #         return float(match.group(2))
        
    #     # 두 번째 패턴: 대지 면적이 괄호 없이 바로 표시된 경우
    #     match = re.search(r'대지\s*·\s*(\d+(\.\d+)?)m²', text, re.DOTALL)
    #     if match:
    #         return float(match.group(1))
        
    #     return None

    # def extract_building_area_sum_final(self, text):
    #     # '건물내역' 이후 텍스트를 추출
    #     building_info = re.search(r'건물내역(.*?)(제시외|$)', text, re.DOTALL)
        
    #     if building_info:
    #         # 모든 m² 앞의 숫자를 추출
    #         areas = re.findall(r'(\d+(\.\d+)?)m²', building_info.group(1), re.DOTALL)
    #         # 면적의 합을 구함
    #         return sum(float(area[0]) for area in areas)
        
    #     return None

    def extract_sizes_all(self, text):
        if '총토지' not in text:
            return False, False  # 조건 2

        # land_size는 무조건 존재하는 조건이므로 총토지~ 숫자까지 뽑음
        land_match = re.search(r'총토지면적\s*:\s*([\d,\.]+)m²', text)
        land_size = float(land_match.group(1).replace(',', '')) if land_match else 0

        # 총건물면적이 있는 경우만 building_size 추출
        building_match = re.search(r'총건물면적\s*:\s*([\d,\.]+)m²', text)
        if building_match:
            building_size = float(building_match.group(1).replace(',', ''))
        else:
            building_size = 0  # 조건 1-2

        return land_size, building_size

    def extract_sizes(self, text):
        land_size = 0
        building_size = 0
        
        lines = text.split('\n')
        building_index = next((i for i, line in enumerate(lines) if '건물' in line), -1)
        
        # Land size extraction
        if building_index != -1:
            land_text = '\n'.join(lines[:building_index])
        else:
            land_text = text
        
        land_matches = re.findall(r'(\d+(?:,\d+)*(?:\.\d+)?)\s*(?:\((\d+(?:,\d+)*(?:\.\d+)?)/(\d+(?:,\d+)*(?:\.\d+)?)\))?\s*m²', land_text)
        if land_matches:
            if land_matches[0][1] and land_matches[0][2]:  # 분수 형태
                land_size = float(land_matches[0][1].replace(',', ''))
            else:  # 단일 숫자
                land_size = float(land_matches[0][0].replace(',', ''))
        
        # Building size extraction
        if building_index != -1:
            building_text = '\n'.join(lines[building_index:])
            exclude_index = building_text.find('제시외')
            if exclude_index != -1:
                building_text = building_text[:exclude_index]
            
            building_matches = re.findall(r'(\d+(?:,\d+)*(?:\.\d+)?)m²', building_text)
            building_size = sum(float(match.replace(',', '')) for match in building_matches)
        
        return land_size, building_size

    def extract_sizes(self, text):
        land_size = 0
        building_size = 0
        
        lines = text.split('\n')
        building_index = next((i for i, line in enumerate(lines) if '건물' in line), -1)
        
        # Land size extraction
        if building_index != -1:
            land_text = '\n'.join(lines[:building_index])
        else:
            land_text = text
        
        land_matches = re.findall(r'(\d+(?:,\d+)*(?:\.\d+)?)\s*(?:\((\d+(?:,\d+)*(?:\.\d+)?)/(\d+(?:,\d+)*(?:\.\d+)?)\))?\s*m²', land_text)
        if land_matches:
            if land_matches[0][1] and land_matches[0][2]:  # 분수 형태
                land_size = float(land_matches[0][1].replace(',', ''))
            else:  # 단일 숫자
                land_size = float(land_matches[0][0].replace(',', ''))
        
        # Building size extraction
        if building_index != -1:
            building_text = '\n'.join(lines[building_index:])
            exclude_index = building_text.find('제시외')
            if exclude_index != -1:
                building_text = building_text[:exclude_index]
            
            building_matches = re.findall(r'(\d+(?:,\d+)*(?:\.\d+)?)m²', building_text)
            building_size = sum(float(match.replace(',', '')) for match in building_matches)
        
        return land_size, building_size

    def extract_individual_land_value(self, text):
        # 개별공시지가가 있는 경우 추출
        match = re.search(r'개별공시지가\s*:\s*₩([\d,]+)', text)
        if match:
            # 숫자에 포함된 쉼표 제거 후 정수로 변환
            return int(match.group(1).replace(',', ''))
        return None

    def extract_bidder_count(self, text):
        # 응찰수 추출하는 정규 표현식
        match = re.search(r'응찰수\s*:\s*(\d+)명', text)
        if match:
            return int(match.group(1))
        return None

    def extract_auction_date(self, text):
        # 낙찰일을 추출하는 정규 표현식
        match = re.search(r'낙찰\s*(\d{4}\.\d{2}\.\d{2})', text)
        if match:
            return match.group(1)  # 추출한 낙찰일 반환
        return None  # 낙찰일이 없을 경우 None 반환

    def extract_auction_price(self, text):
        # 모든 '낙찰가'를 찾고 리스트로 반환
        matches = re.findall(r'낙찰가\s*:\s*([\d,]+)원', text)
        if matches:
            # 마지막 '낙찰가' 매칭 값을 가져와 쉼표를 제거하고 정수로 변환하여 반환
            return int(matches[-1].replace(',', ''))
        return None  # '낙찰가'가 없을 경우 None 반환

    def extract_preservation_date(self, text):
        # 보존등기일을 추출하는 정규 표현식
        match = re.search(r'보존등기일\s*:\s*(\d{4}\.\d{2}\.\d{2})', text)
        if match:
            return match.group(1)  # 추출한 날짜 반환
        return None  # 보존등기일이 없을 경우 None 반환

    def check_xpath(self, driver):
        # XPath가 존재하는지 확인
        xpath = '/html/body/section/div[1]/div[3]/div[1]/div[3]/div/table/tbody/tr[3]/td'
        try:
            element = tools.wait_and_read(driver=driver, index=xpath)
            self.logger.info(element)
            if element:
                return "복수"
            else:
                return "단일"
        except Exception as e:
            self.logger.error(f"복수여부 체크 에러('단일' 반환): {e}")
            return "단일"

    def main(self, report_name, df_input):

        self.logger.debug('option setting')
        chrome_options = Options()
        chrome_options.add_experimental_option("detach", True)
        # chrome_options.add_argument("headless")
        driver = webdriver.Chrome(options=chrome_options)
        driver.implicitly_wait(5)
        self.logger.debug('Option setting 완료')

        self.logger.debug(f'검색할 데이터(전체) : {df_input}')
        for i, row in df_input.iterrows():
            status = True
            
            # 각 변수에 행의 값을 할당
            index_number = row['등기부등본고유번호']
            index_class = row['등기부등본구분']
            index_address = row['등기부등본주소']
            court = row['법원']
            year = row['사건연도']
            # row['사건번호']가 '12345(2)'와 같은 형식일 수 있으므로 이를 처리
            full_number = row['사건번호']

            # 괄호로 숫자가 포함되어 있는지 확인
            match = re.match(r"(\d+)(\(\d+\))?", full_number)

            if match:
                number = match.group(1)  # 괄호 앞의 숫자
                count = match.group(2) if match.group(2) else ""  # 괄호와 숫자가 있으면 괄호 포함해서 할당, 없으면 빈 문자열
            else:
                number = full_number  # 매칭 실패 시 전체 값을 그대로 할당
                count = ""  # 괄호 내 숫자가 없으므로 빈 문자열
            search_keyword = f'{court} {year}_{number}{count}'
            self.logger.debug(f'검색대상 사건번호 : {search_keyword}')

            self.logger.debug('페이지 열기')
            self.logger.debug(f'status : {status}')
            if status:
                try:
                    driver.get(url='https://www.infocare.co.kr/')
                    driver.execute_script("window.location.reload();")
                    driver.maximize_window()
                    self.logger.debug('페이지 열기 성공')
                except :
                    status = False
                    self.logger.debug(f'페이지 열기 실패.')

            
            self.logger.debug('프레임 조정')
            self.logger.debug(f'status : {status}')
            if status:
                try:
                    frames = driver.find_elements(By.TAG_NAME, "frame")
                    for index, frame in enumerate(frames):
                        name = frame.get_attribute("name")
                        frame_id = frame.get_attribute("id")
                        self.logger.debug(f"Frame {index}: Name = {name}, ID = {frame_id}")
                    driver.switch_to.frame(driver.find_element(By.NAME, 'info_main'))
                    self.logger.debug('프레임 전환 성공')
                except :
                    status = False
                    self.logger.info(f'프레임 전환 실패.')

            #로그인
            self.logger.debug('로그인 시도')
            self.logger.debug(f'status : {status}')

            if status:  
                try:  
                    tools.wait_and_click(driver=driver, index='/html/body/header/div/div[1]/div/ul/li[2]/a/span[1]')
                    tools.wait_and_write(driver=driver, index='/html/body/div[5]/div/div[2]/div[2]/div/div/div/form/div[1]/input', text=self.id)
                    tools.wait_and_write(driver=driver, index='/html/body/div[5]/div/div[2]/div[2]/div/div/div/form/div[2]/input[1]', text=self.pw)
                    tools.wait_and_click(driver=driver, index='/html/body/div[5]/div/div[2]/div[2]/div/div/button[1]')
                    try:
                        #로그인 시도 -> '기존 사용자 접속 해제' alert에 대하여 '확인'
                        time.sleep(3)
                        alert = driver.switch_to.alert
                        alert.accept()
                    except:
                        pass
                    self.logger.debug('로그인 성공')
                    
                except Exception as e:
                    self.logger.info(f'로그인 실패. 기존에 로그인이 되어있는 경우 이후 코드가 정상적으로 작동됩니다. {e}') 

            self.logger.debug('사건번호 검색')
            self.logger.debug(f'status : {status}')

            if status:
                try:
                    time.sleep(3)
                    tools.wait_and_select(driver=driver, index='/html/body/div[1]/ul/li[1]/div/div[1]/select', selection=year)
                    tools.wait_and_write(driver=driver, index='/html/body/div[1]/ul/li[1]/div/div[1]/input', text=number)
                    tools.wait_and_click(driver=driver, index='/html/body/div[1]/ul/li[1]/div/div[1]/button/img')

                    wait = WebDriverWait(driver, 5)
                    tools.wait_and_select(driver=driver, index='/html/body/section/div/div[3]/div[1]/div[2]/select', selection='50개')
                    try:
                        wait.until(EC.element_to_be_clickable((By.XPATH, '/html/body/section/div/div[3]/div[2]/table/tbody/tr[1]/td[2]/p')))   
                    except:
                        pass
                    
                    time.sleep(2)

                    if count == "":  # count가 빈 문자열인 경우
                        self.logger.debug('사건번호가 단순히 숫자로 구성됨')

                        # tr 태그들을 모두 가져온 후 순환
                        rows = driver.find_elements(By.XPATH, "/html/body/section/div/div[3]/div[2]/table/tbody/tr")
                        
                        for row in rows:
                            # 각 tr에서 해당 td 요소를 찾음 (2번째 td가 court를 포함하는지 확인)
                            td_element = row.find_element(By.XPATH, "./td[2]/p")
                            
                            if court in td_element.text:
                                td_element.click()  # 해당 td가 텍스트를 포함하고 있으면 클릭
                                break
                        else:
                            self.logger.error(f"'{court}' 텍스트가 포함된 항목을 찾을 수 없습니다.")
                            status = False

                    else:  # count가 빈 문자열이 아닌 경우
                        self.logger.debug('사건번호에 (2)와 같은 텍스트가 포함됨')

                        rows = driver.find_elements(By.XPATH, "/html/body/section/div/div[3]/div[2]/table/tbody/tr")
                        
                        for row in rows:
                            # 각 tr에서 해당 td 요소를 찾음 (2번째 td가 court와 count를 모두 포함하는지 확인)
                            td_element = row.find_element(By.XPATH, "./td[2]/p")
                            
                            if court in td_element.text and count in td_element.text:
                                td_element.click()  # 해당 td가 텍스트를 포함하고 있으면 클릭
                                break
                        else:
                            self.logger.error(f"'{court}' 및 '{count}' 텍스트가 포함된 항목을 찾을 수 없습니다.")
                            status = False
                                      
                except:
                    status = False
                    self.logger.info(f'사건번호 검색 실패.') 

            self.logger.debug('데이터 추출')
            self.logger.debug(f'status : {status}')

            if status:
                try:
                    index_number = index_number
                    index_address = index_address
                    price = tools.wait_and_read(driver=driver, index='/html/body/section/div[1]/div[3]/div[1]/div[2]/div[1]/table/tbody/tr[2]/td[2]')        
                    address = tools.wait_and_read(driver=driver, index='/html/body/section/div[1]/div[3]/div[1]/div[3]/div/table/tbody/tr[1]/td')
                    type = tools.wait_and_read(driver=driver, index='/html/body/section/div[1]/div[3]/div[1]/div[3]/div/table/tbody/tr[2]/td[1]/p[1]')
                    try:
                        land = tools.wait_and_read(driver=driver, index='/html/body/section/div[1]/div[3]/div[1]/div[12]/div[2]/table/tbody[1]/tr[2]/td[1]/span')
                    except:
                        pass
                    try:
                        building = tools.wait_and_read(driver=driver, index='/html/body/section/div[1]/div[3]/div[1]/div[12]/div[2]/table/tbody[1]/tr[2]/td[2]/span')
                    except:
                        pass

                    area = tools.wait_and_read(driver=driver, index='/html/body/section/div[1]/div[3]/div[1]/div[3]/div/table/tbody/tr[2]/td[2]')
                    price_2 = tools.wait_and_read(driver=driver, index='/html/body/section/div[1]/div[3]/div[1]/div[3]/div/table/tbody/tr[2]/td[3]')

                    land_size, building_size = self.extract_sizes_all(price_2)
                    land_size_calculated, building_size_calculated = self.extract_sizes(area)

                    if land_size:
                        land_area = land_size
                    else:
                        land_area = land_size_calculated

                    if building_size:
                        building_area = building_size
                    else:
                        building_area = building_size_calculated


                    
                    individual_land_value = self.extract_individual_land_value(price_2)
                    preservation_date = self.extract_preservation_date(price_2)
                    progress = tools.wait_and_read(driver=driver, index='/html/body/section/div[1]/div[3]/div[1]/div[4]/div/table/tbody/tr/td[1]')
                    bidder_count = self.extract_bidder_count(progress)  
                    auction_date = self.extract_auction_date(progress)
                    auction_price = self.extract_auction_price(progress)
                    try:    
                        second_progress = self.check_xpath(driver=driver)
                    except:
                        second_progress = '확인필요'
                except:
                    status = False
                    self.logger.info(f'데이터 추출 실패.') 

            self.logger.debug('데이터 가공')
            self.logger.debug(f'status : {status}')

            if status:
                try:
                    df = pd.DataFrame(columns=['등기부등본고유번호','등기부등본구분', '등기부등본주소','사건번호', '감정가', '주소', '지역', '면적', '토지면적', '건물면적', '가격정보', '개별공시지가', '보존등기일', '경매정보', '응찰자수', '낙찰일', '낙찰가', '복수소재지'])
                    df.loc[0] = [index_number, index_class, index_address, f'{court} {year}-{number}{count}', price, address, type, area, land_area, building_area, price_2, individual_land_value, preservation_date, progress, bidder_count, auction_date, auction_price, second_progress]
                    self.logger.debug(df)
                except:
                    status = False
                    self.logger.info(f'데이터 가공 실패.')     

            self.logger.debug('복수 물건 데이터 추출 및 가공')
            self.logger.debug(f'status : {status}')

            if status:
                if df.loc[0, '복수소재지'] == '복수':
                    try:
                        rows = driver.find_elements(By.XPATH, '/html/body/section/div[1]/div[3]/div[1]/div[3]/div/table/tbody/tr')

                        # DataFrame을 위한 리스트 초기화
                        data = []

                        # 각 tr 요소 순회
                        for row in rows:
                            # 각 tr 내의 텍스트를 리스트로 가져옴 (td로 세분화)
                            cols = row.find_elements(By.TAG_NAME, "td")
                            row_data = [col.text for col in cols]
                            
                            # DataFrame에 추가할 데이터를 리스트에 저장
                            data.append(row_data)

                        flattened_data = [item for sublist in data for item in sublist]
                        num_columns = len(flattened_data)
                        df_add = pd.DataFrame([flattened_data], columns=[f"Column {i+1}" for i in range(num_columns)])

                        for col in df_add.columns:
                            df[col] = df_add[col]

                    except:
                        status=False
                        self.logger.info('복수물건 데이터 추출 및 가공 실패')

            self.logger.debug('데이터 저장')
            self.logger.debug(f'status : {status}')

            if status:
                try:
                    excel_path = os.path.join(self.save_path, f'{court}_{year}-{number}{count}_사례조회_{report_name}.xlsx')
                    df.to_excel(excel_path, sheet_name="Output_인포사례상세", index=False)
                except:
                    columns = ['등기부등본고유번호', '등기부등본구분', '등기부등본주소', '사건번호', '감정가', '주소', '지역', '면적', '토지면적', '건물면적', '가격정보','개별공시지가', '보존등기일', '경매정보', '응찰자수', '낙찰일', '낙찰가', '복수소재지']
                    df = pd.DataFrame([[''] * len(columns)], columns=columns)
                    df.loc[0, '등기부등본고유번호'] = index_number
                    df.loc[0, '등기부등본구분'] = index_class
                    df.loc[0, '등기부등본주소'] = index_address
                    df.loc[0, '사건번호'] = f'{court}_{year}-{number}{count}'
                    df.loc[0, '감정가'] = '조회 내역 없음'

                    df.to_excel(f'{report_name}\Temp\인포사례상세\{court}_{year}-{number}{count}_사례조회_{report_name}.xlsx', sheet_name="Output_인포사례상세", index=False)
                finally:
                    self.logger.critical('데이터 저장 완료')
            else:
                columns = ['등기부등본고유번호', '등기부등본구분', '등기부등본주소', '사건번호', '감정가', '주소', '지역', '면적', '토지면적', '건물면적', '가격정보','개별공시지가', '보존등기일', '경매정보', '응찰자수', '낙찰일', '낙찰가', '복수소재지']
                df = pd.DataFrame([[''] * len(columns)], columns=columns)
                df.loc[0, '등기부등본고유번호'] = index_number
                df.loc[0, '등기부등본구분'] = index_class
                df.loc[0, '등기부등본주소'] = index_address
                df.loc[0, '사건번호'] = f'{court}_{year}-{number}{count}'
                df.loc[0, '감정가'] = '조회 내역 없음'

                excel_path = os.path.join(self.save_path, f'{court}_{year}-{number}{count}_사례조회_{report_name}.xlsx')
                df.to_excel(excel_path, sheet_name="Output_인포사례상세", index=False)   
                self.logger.critical('데이터 저장 완료')

        tools.wait_and_click(driver=driver, index='/html/body/header/div/div[1]/div/ul/li[2]/a/span[2]')
        driver.minimize_window()
        time.sleep(5)
        driver.quit()


    def run_app(self, filepath):
        df = pd.read_excel(filepath, sheet_name='Input_인포사례상세', engine='openpyxl', header=5)
        df = df.iloc[:, 1:]
        report_name = self.get_report_name(filepath)

        df = df[['등기부등본고유번호','등기부등본구분','등기부등본주소','사건번호', '조회여부("V")']]
        df = df[df['조회여부("V")'] == 'V']

        # '사건번호'를 기준으로 새로운 열 생성
        df[['법원', '사건연도번호']] = df['사건번호'].str.split('계', n=1, expand=True)
        df[['사건연도', '사건번호']] = df['사건연도번호'].str.split('-', n=1, expand=True)

        # 불필요한 '사건연도번호' 열 삭제
        df = df.drop(columns=['사건연도번호', '조회여부("V")'])
        df = df.reindex(columns=['등기부등본고유번호', '등기부등본구분', '등기부등본주소', '법원', '사건연도', '사건번호'])

        self.main(report_name, df)

        self.merge_excel(report_name)

        self.logger.critical('선택된 모든 사례에 대한 모든 작업 완료.')

if __name__ == '__main__':
    # data = {
    # '등기부등본고유번호' : ['1111','2222','3333','4444','5555'],
    # '등기부등본주소' : ['주소1', '주소2', '주소3', '주소4', '주소5'],
    # '사건번호': ['중앙 4계2022-273', '중앙 4계2022-945', '중앙 7계2020-4431', '포항 5계2022-945', '뚱땡보'],
    # '선택': ['', 'V', 'V', 'V','V']
    # }
    # # data = {
    # # '사건번호': ['포항 5계2022-945', '뚱땡보'],
    # # '선택': ['V', '']
    # # }
    # df = pd.DataFrame(data)
    # run_app(df)

    filepath = r'Smart_NPL.xlsm'
    infocare_case().run_app(filepath)    