from selenium import webdriver
from selenium.webdriver.chrome.options import Options
from selenium.webdriver.common.by import By
from selenium.webdriver.common.keys import Keys
from logger import Logger
import tools as tools
import time
import pandas as pd
import re
from openpyxl import load_workbook
import os
import sys

class kb_info():
    def __init__(self):
        """
        1. 최초 Smart_NPL 파일 경로 설정
        """
        # 실행 파일의 위치 설정
        if getattr(sys, 'frozen', False):
            # PyInstaller로 빌드된 실행 파일인 경우
            exe_dir = os.path.dirname(sys.executable)
        else:
            # 스크립트로 실행되는 경우
            exe_dir = os.path.dirname(os.path.abspath(__file__))

        self.npl_file_path = os.path.join(exe_dir, 'Smart_NPL.xlsm')

        """
        2. 보고서명 및 저장경로 Source 시트 내 cell에서 값 가져오기
        """
        self.excel_control = ExcelHandler(self.npl_file_path)
        self.report_name = self.excel_control.get_value(sheet_name='Source', cell='B2')
        source_path = self.excel_control.get_value(sheet_name='Source', cell='B4')

        """
        3. 폴더 경로 설정
        """
        self.save_path = os.path.join(source_path, 'Temp', 'KB시세')
        self.logger = Logger(save_path=self.save_path, function_name='KB시세').get_logger()

        self.logger.debug(f'파일 저장 폴더 : {self.save_path}')
        self.logger.debug(f'Smart_NPL file_path : {self.npl_file_path}')
        self.logger.debug(f'report name : {self.report_name}')

        """
        4. 폴더 생성 및 기존에 있는 파일 삭제
        """
        file_manager = FileManager(self.save_path)
        # 폴더 경로 탐색 및 생성
        file_manager.read_or_create_folder()

        # 저장 폴더 내 파일 삭제
        file_manager.remove_excel_files()

    # 셀레니움 가동
    def initiate_driver(self):
        try:
            self.logger.debug('초기설정')
            chrome_options = Options()
            chrome_options.add_experimental_option("detach", True)
            driver = webdriver.Chrome(options=chrome_options)
            return driver
        except Exception as e:
            raise Exception(f'initiate_driver 함수에서 예외 발생: {e}')

    # 변수 초기화 및 할당
    def initiate_variables(self, row):
        self.index_number = row['등기부등본고유번호']
        self.index_class = row['등기부등본구분']
        self.index_address = row['등기부등본주소']
        self.input_address = row['검색할 주소']
        self.net_area = row['전용면적']

    # KB시세조회 페이지 열기
    def kb_page_open(self):
        try:
            self.logger.debug('kb_page_open')
            self.driver.get(url='https://kbland.kr/map')
            self.driver.execute_script("window.location.reload();")
            try:
                self.driver.maximize_window()
            except:
                pass
        except Exception as e:
            raise Exception(f'kb_page_open 함수에서 예외 발생: {e}')
    # 팝업 광고 제거
        try:
            self.logger.debug('close ad')
            tools.wait_and_click(driver=self.driver, index='/html/body/div[2]/div/div[3]/div/div/div/div[1]/div[3]/div[2]/div/div[2]/button[1]')
        except:
            pass

    # 주소 검색
    def search_address(self):
        self.logger.debug(f'주소 검색 : {self.input_address}')
        try:
            # 주소입력창 클릭
            print('step 1')
            try :
                tools.wait_and_click(driver=self.driver, index='/html/body/div[2]/div/div[5]/button')
            except:
                pass

            try:
                tools.wait_and_click(driver=self.driver, index='/html/body/div[2]/div/div[3]/div/div/div/div[1]/div[3]/section/div[1]')
            except:
                pass
            # 주소 입력
            print('step 2')
            tools.wait_and_write(driver=self.driver, index='/html/body/div[2]/div/div[3]/div/div/div/div[1]/section/div[1]/div/input', text=self.input_address)
            self.driver.save_screenshot(os.path.join(self.save_path, f'search_address_{self.input_address}.png'))
            # 엔터
            print('step 3')
            tools.wait_and_write(driver=self.driver, index='/html/body/div[2]/div/div[3]/div/div/div/div[1]/section/div[1]/div/input', text=Keys.ENTER)
        except Exception as e:
            self.driver.execute_script("window.location.reload();")
            raise Exception(f'search_address 함수에서 예외 발생: {e}')


    # 최상단의 주소 클릭.
    def click_first_result(self):
        self.logger.debug('최상단의 주소를 검색합니다.')
        if tools.wait_and_read(driver=self.driver, index='/html/body/div[2]/div/div[3]/div/div/div/div[1]/section/section'):
            try:
                tools.wait_and_click(driver=self.driver, index='/html/body/div[2]/div/div[3]/div/div/div/div[1]/section/section/div[2]/div[1]/div/div[1]/div/span')
            except:
                try:
                    tools.wait_and_click(driver=self.driver, index='/html/body/div[2]/div/div[3]/div/div/div/div[1]/section/section/div[2]/div/div/div[1]/div/span/span[2]/span')
                except Exception as e:
                    self.driver.execute_script("window.location.reload();")
                    self.search_address()
                    raise Exception(f'click_first_result 함수에서 예외 발생: {e}')
        else:
            pass

    # 팝업된 물건 클릭.
    def click_popup_page(self):
        if tools.wait_and_read(driver=self.driver, index='/html/body/div[2]/div/div[3]/div/div/div/div[1]/div[3]/div/div[4]/h2'):
            try:
                tools.wait_and_click(driver=self.driver, index='/html/body/div[2]/div/div[8]/div/div/div[1]')
            
            except Exception as e:
                self.driver.execute_script("window.location.reload();")
                raise Exception(f'click_popup_page 함수에서 예외 발생: {e}')
        else: pass

    # KB시세 주소를 파싱. 현재 xPath가 3가지 경우의 수로 나뉨.
    def get_kb_address(self):
        time.sleep(3)
        try:
            try:
                output_address = tools.wait_and_read(driver=self.driver, index='/html/body/div[2]/div/div[3]/div/div/div/div[1]/div[3]/div/div[6]/div[3]/span')
                self.logger.debug(f'output address : {output_address}')
            except:
                pass
            try:
                output_address = tools.wait_and_read(driver=self.driver, index='/html/body/div[2]/div/div[3]/div/div/div/div[1]/div[3]/div/div[5]/div[3]/span')
                self.logger.debug(f'output address : {output_address}')
            except:
                pass
            try:
                output_address = tools.wait_and_read(driver=self.driver, index='/html/body/div[2]/div/div[3]/div/div/div/div[1]/div[3]/div/div[4]/div[3]/span')
                self.logger.debug(f'output address : {output_address}')
            except:
                pass
            self.output_address = output_address
            self.driver.save_screenshot(os.path.join(self.save_path, f'get_kb_address_{self.input_address}.png'))
        except Exception as e:
            self.driver.execute_script("window.location.reload();")
            raise Exception(f'get_kb_address 함수에서 예외 발생: {e}')

    # 검색창 우측상단의 면적정보 클릭. 현재 xPath가 2가지 경우의 수로 나뉨.
    def click_detail_info(self):
        try:
            try:
                tools.wait_and_click(driver=self.driver, index='/html/body/div[2]/div/div[3]/div/div/div/div[1]/div[3]/div/div[8]/div[2]/span')
                self.driver.save_screenshot(os.path.join(self.save_path, f'click_detail_info_{self.input_address}.png'))
            except:
                pass
            try:
                tools.wait_and_click(driver=self.driver, index='/html/body/div[2]/div/div[3]/div/div/div/div[1]/div[3]/div/div[7]/div[2]/span')
                time.sleep(1)
                self.driver.save_screenshot(os.path.join(self.save_path, f'click_detail_info_{self.input_address}.png'))
            except:
                pass
            try:
                tools.wait_and_click(driver=self.driver, index='/html/body/div[2]/div/div[3]/div/div/div/div[1]/div[3]/div/div[6]/div[2]/span')
                time.sleep(1)
                self.driver.save_screenshot(os.path.join(self.save_path, f'click_detail_info_{self.input_address}.png'))
            except:
                pass

        except Exception as e:
            self.driver.execute_script("window.location.reload();")
            raise Exception(f'click_detail_info 함수에서 예외 발생: {e}')

    # 해당 물건에 대한 정보가 "평형 선택"인지 "동호수 선택"인지 확인
    def check_data_type(self):
        try:
            try:
                try:
                    data_type = tools.wait_and_read(driver=self.driver, index='/html/body/div[2]/div/div[3]/div/div/div/div[1]/div[3]/div/div[26]/div[2]/div/div/div[1]/strong')
                except:
                    try:
                        data_type = tools.wait_and_read(driver=self.driver, index='/html/body/div[2]/div/div[3]/div/div/div/div[1]/div[3]/div/div[25]/div[2]/div/div/div[1]/strong')
                    except:
                        data_type = tools.wait_and_read(driver=self.driver, index='/html/body/div[2]/div/div[3]/div/div/div/div[1]/div[3]/div/div[24]/div[2]/div/div/div[1]/strong')
            except:
                data_type = tools.wait_and_read(driver=self.driver, index='//*[@id="leftScroll"]/div/div[1]/div[3]/div/div[19]/div[2]/div/div/div[1]/strong')

            self.data_type = data_type
        except Exception as e:
            self.data_type = "평형 선택"

    # 세부정보를 data로 가져오기
    def get_detail_info(self):
        try:
            data = []
            rows = self.driver.find_elements(By.CLASS_NAME, 'tbody-tr')  # 평형별정보 표 값을 rows에 할당

            for row in rows:
                # 'tdbox' 클래스를 가진 하위 요소들 찾기
                cells = row.find_elements(By.CLASS_NAME, 'tdbox')
                # 각 'tdbox'의 텍스트를 리스트로 저장
                row_data = [cell.text for cell in cells]
                # 데이터를 추가
                data.append(row_data)

            self.data = data
        except Exception as e:
            raise Exception(f'get_detail_info 함수에서 예외 발생: {e}')

    # 평형 선택 : 데이터프레임 생성 및 편집 (평형 선택의 경우)
    def case1_edit_data(self):
        try:
            df_info = pd.DataFrame(self.data, columns=['부동산정보', '시세', '거래량'])
            df_info = df_info.iloc[1:].reset_index(drop=True)

            try:
                df_info[['공급면적', '전용면적', '세대수']] = df_info['부동산정보'].apply(
                    lambda x: self._case1_edit_data(x) if self._case1_edit_data(x) is not None else (None, None, None)
                ).apply(pd.Series)
            except Exception as e:
                self.logger.error(f"데이터 변환 중 오류 발생: {e}")

            # 시세 및 거래량 처리 시 예외 처리 추가
            df_info['시세'] = df_info['시세'].apply(lambda x: x.split('\n')[0] if isinstance(x, str) and '\n' in x else x)
            df_info['거래량'] = df_info['거래량'].apply(lambda x: x.split('\n')[0] if isinstance(x, str) and '\n' in x else x)

            # 주소 정보 할당
            df_info['등기부등본고유번호'] = self.index_number
            df_info['등기부등본구분'] = self.index_class
            df_info['등기부등본주소'] = self.index_address
            df_info['input주소'] = self.input_address
            df_info['KB시세조회 주소'] = self.output_address

            self.logger.debug(f'download df : {df_info}')

            # 전용면적이 가장 유사한 row 선택
            if not df_info['전용면적'].isnull().all():
                closest_value_index = (df_info['전용면적'] - self.net_area).abs().idxmin()

                # 전용면적이 가장 유사한 행을 1행으로 올림
                df_info = pd.concat([df_info.iloc[[closest_value_index]], df_info.drop(closest_value_index)], ignore_index=True)
                self.logger.debug(f'전용면적이 가장 유사한 행을 1행으로 올린 데이터프레임 : {df_info}')
            else:
                self.logger.error("전용면적 데이터가 비어 있습니다.")

            self.df_output = df_info
        except Exception as e:
            raise Exception(f'case1_edit_data 함수에서 예외 발생: {e}')

    # 평형 선택 : 데이터프레임 편집
    def _case1_edit_data(self, data):
        try:
            lines = data.split('\n')
            print(f'lines : {lines}')
            
            # 첫 번째 줄에서 공급 면적 정보 추출
            supply_size_info = lines[0]
            # 두 번째 줄에서 전용 면적 정보 추출
            exclusive_size_info = lines[1]
            # 세 번째 줄에서 세대수 정보 추출
            units_info = lines[2]

            # 첫 번째 줄에서 숫자 추출 (공급 면적)
            supply_size_values = re.findall(r'\d+\.?\d*', supply_size_info)
            # 두 번째 줄에서 숫자 추출 (전용 면적)
            exclusive_size_values = re.findall(r'\d+\.?\d*', exclusive_size_info)

            print(f'supply_size_values : {supply_size_values}')  # 디버깅용 출력
            print(f'exclusive_size_values : {exclusive_size_values}')  # 디버깅용 출력

            if supply_size_values and exclusive_size_values:
                supply_size = supply_size_values[0]  # 첫 번째 값이 공급 면적
                exclusive_size = exclusive_size_values[0]  # 첫 번째 값이 전용 면적
            else:
                print("면적 정보가 충분하지 않음")  # 문제 원인 출력
                return None

            # 세대수 정보에서 숫자만 추출
            units_match = re.findall(r'\d+', units_info)
            if units_match:
                units = units_match[0]
            else:
                print("세대수 정보가 없는 경우")  # 문제 원인 출력
                return None

            # 반환할 값을 튜플로 리턴
            return float(supply_size), float(exclusive_size), int(units)

        except Exception as e:
            raise Exception(f'_case1_edit_data 함수에서 예외 발생: {e}')
        
    # 평형 선택 : df_output에 일반가, 상위평균가, 하위평균가, 기준일자를 초기화하고, 전용면적이 가장 유사한 건(최상단 행의 '전용면적'과 일치하는 건) 클릭
    def case1_click_close_area(self):
        try:
            self.df_output['일반가'] = pd.NA
            self.df_output['상위평균가'] = pd.NA
            self.df_output['하위평균가'] = pd.NA
            self.df_output['기준일자'] = pd.NA

            # 1행(전용면적 유사치)의 전용면적 열을 값으로 추출
            df_first_value = self.df_output.loc[0, '전용면적']

            # 각 요소에서 텍스트를 확인하고, df_first_value(최상단의 전용면적)와 일치하는 경우 클릭
            tdbox_elements = self.driver.find_elements(By.CLASS_NAME, "tdbox")
            for element in tdbox_elements:
                if str(df_first_value) in element.text:  # 값이 포함된 경우
                    element.click()  # 해당 요소 클릭
                    time.sleep(1)
                    self.driver.save_screenshot(os.path.join(self.save_path, f'case1_click_close_area_{self.input_address}.png'))
                    break  # 원하는 값을 찾으면 종료
        except Exception as e:
            raise Exception(f'case1_click_close_area 함수에서 예외 발생: {e}')

    # 평형 선택 : 상위평균가, 일반가, 하위평균가, 기준일자를 조회 후 df_output에 입력
    def case1_search_close_area(self):
        try:
            try:
                normal_price = tools.wait_and_read(driver=self.driver, index='/html/body/div[2]/div/div[3]/div/div/div/div[1]/div[3]/div/div[9]/div/div[1]/div[2]/div/div[1]/div[2]/div[1]/strong')
            except:
                try:
                    normal_price = tools.wait_and_read(driver=self.driver, index='/html/body/div[2]/div/div[3]/div/div/div/div[1]/div[3]/div/div[8]/div/div[1]/div[2]/div/div[1]/div[2]/div[1]/strong')
                except:
                    try:                                                              
                        normal_price = tools.wait_and_read(driver=self.driver, index='/html/body/div[2]/div/div[3]/div/div/div/div[1]/div[3]/div/div[7]/div/div[1]/div[2]/div/div[1]/div[2]/div[1]/strong')
                    except:
                        normal_price = "조회 내역 없음"
            self.logger.debug(f'normal_price : {normal_price}')

            try:
                high_price = tools.wait_and_read(driver=self.driver, index='    /html/body/div[2]/div/div[3]/div/div/div/div[1]/div[3]/div/div[9]/div/div[1]/div[2]/div/div[1]/div[2]/div[1]/div/span[1]')
            except:
                try:
                    high_price = tools.wait_and_read(driver=self.driver, index='/html/body/div[2]/div/div[3]/div/div/div/div[1]/div[3]/div/div[8]/div/div[1]/div[2]/div/div[1]/div[2]/div[1]/div/span[1]')
                except:
                    try:
                        high_price = tools.wait_and_read(driver=self.driver, index='/html/body/div[2]/div/div[3]/div/div/div/div[1]/div[3]/div/div[7]/div/div[1]/div[2]/div/div[1]/div[2]/div[1]/div/span[1]')
                    except:
                        high_price = "조회 내역 없음"
            self.logger.debug(f'high : {high_price}')

            try:
                low_price = tools.wait_and_read(driver=self.driver, index='/html/body/div[2]/div/div[3]/div/div/div/div[1]/div[3]/div/div[9]/div/div[1]/div[2]/div/div[1]/div[2]/div[1]/div/span[2]')
            except:
                try:
                    low_price = tools.wait_and_read(driver=self.driver, index='/html/body/div[2]/div/div[3]/div/div/div/div[1]/div[3]/div/div[8]/div/div[1]/div[2]/div/div[1]/div[2]/div[1]/div/span[2]')
                except:
                    try:
                        low_price = tools.wait_and_read(driver=self.driver, index='/html/body/div[2]/div/div[3]/div/div/div/div[1]/div[3]/div/div[7]/div/div[1]/div[2]/div/div[1]/div[2]/div[1]/div/span[2]')
                    except:
                        low_price = "조회 내역 없음"
            self.logger.debug(f'low : {low_price}')
            try:
                cost_date = tools.wait_and_read(driver=self.driver, index='/html/body/div[2]/div/div[3]/div/div/div/div[1]/div[3]/div/div[9]/div/div[1]/div[2]/div/div[1]/div[2]/div[1]/span[2]')
            except:
                try:
                    cost_date = tools.wait_and_read(driver=self.driver, index='/html/body/div[2]/div/div[3]/div/div/div/div[1]/div[3]/div/div[8]/div/div[1]/div[2]/div/div[1]/div[2]/div[1]/span[2]')
                except:
                    try:
                        cost_date = tools.wait_and_read(driver=self.driver, index='/html/body/div[2]/div/div[3]/div/div/div/div[1]/div[3]/div/div[7]/div/div[1]/div[2]/div/div[1]/div[2]/div[1]/span[2]')
                    except:
                        cost_date = "조회 내역 없음"

            self.df_output.at[0, '일반가'] = normal_price
            self.df_output.at[0, '상위평균가'] = high_price
            self.df_output.at[0, '하위평균가'] = low_price
            self.df_output.at[0, '기준일자'] = cost_date

            for col in ['일반가', '상위평균가', '하위평균가']:
                # 1행의 값을 가져오기
                value = self.df_output.loc[0, col]

                # 숫자 부분만 추출
                numeric_value = int(re.sub(r'[^\d]', '', value))

                # 마지막 문자가 '억'인지 확인
                if value.strip().endswith('억'):
                    # '억'으로 끝날 경우 100,000,000 곱하기
                    self.df_output.loc[0, col] = numeric_value * 100000000
                else:
                    # 그렇지 않으면 10,000 곱하기
                    self.df_output.loc[0, col] = numeric_value * 10000
        except Exception as e:
            raise Exception(f'case1_search_close_area 함수에서 예외 발생: {e}')

    # 동호수 섵택 : 모든 물건에 대한 상위평균가/일반가/하위평균가가 있으므로 데이터를 이에 맞게 편집 + 기준일자 조회 후 입력
    def case2_search_and_edit_data(self):
            df_info = pd.DataFrame(self.data, columns=['동호수(빌라 등)', '부동산정보', '가격'])
            # 가격 열을 상한가, 일반가, 하한가로 분리
            df_info[['상위평균가', '일반가', '하위평균가']] = df_info['가격'].str.split('\n', expand=True)

            # 각 열의 앞부분(상한가, 일반가, 하한가) 제거 및 숫자만 남기기
            df_info['상위평균가'] = df_info['상위평균가'].str.replace('상한가', '')
            df_info['일반가'] = df_info['일반가'].str.replace('일반가', '')
            df_info['하위평균가'] = df_info['하위평균가'].str.replace('하한가', '')
                                        
            # 가격 열 삭제
            df_info = df_info.drop(columns=['가격'])

            # 공급면적, 전용면적 구분
            df_info[['공급면적', '전용면적']] = df_info['부동산정보'].str.split(' / ', expand=True)

            # 공급면적과 전용면적에서 'm²' 제거
            df_info['공급면적'] = df_info['공급면적'].str.replace('m²', '')
            df_info['전용면적'] = df_info['전용면적'].str.replace('m²', '')

            # 부동산정보 열 삭제
            df_info = df_info.drop(columns=['부동산정보'])

            # 가격 단위 조정
            for col in ['일반가', '상위평균가', '하위평균가']:
                for i in range(len(df_info)):
                    # 해당 행의 값을 가져오기
                    value = df_info.loc[i, col]

                    # 값이 문자열인 경우에만 정규 표현식 적용
                    if isinstance(value, str):
                        # 숫자 부분만 추출
                        numeric_value = int(re.sub(r'[^\d]', '', value))

                        # 마지막 문자가 '억'인지 확인
                        if value.strip().endswith('억'):
                            # '억'으로 끝날 경우 100,000,000 곱하기
                            df_info.loc[i, col] = numeric_value * 100000000
                        else:
                            # 그렇지 않으면 10,000 곱하기
                            df_info.loc[i, col] = numeric_value * 10000
                    else:
                        # 이미 숫자로 변환된 경우에는 그대로 유지
                        df_info.loc[i, col] = value * 10000

            df['시세'] = pd.NA
            df['거래량'] = pd.NA

            columns_to_copy = ['동호수(빌라 등)', '상위평균가', '일반가', '하위평균가', '공급면적', '전용면적']

            # 이미 존재하는 열은 강제로 값을 덮어쓰기
            for col in columns_to_copy:
                df[col] = df_info[col]

            df['등기부등본고유번호'] = df['등기부등본고유번호'].apply(lambda x: self.index_number)
            df['등기부등본구분'] = df['등기부등본구분'].apply(lambda x: self.index_class)
            df['등기부등본주소'] = df['등기부등본주소'].apply(lambda x: self.index_address)
            df['input주소'] = df['input주소'].apply(lambda x: self.input_address)
            df['KB시세조회 주소'] = df['KB시세조회 주소'].apply(lambda x: self.output_address)
            
            try:
                cost_date = tools.wait_and_read(driver=self.driver, index='/html/body/div[2]/div/div[3]/div/div/div/div[1]/div[3]/div/div[9]/div/div[1]/div[2]/div/div[1]/div[2]/div[1]/span[2]')
            except:
                cost_date = '조회 내역 없음'
            df['기준일자'] = df['기준일자'].apply(lambda x: cost_date)
            df = df.drop(columns=['부동산정보'])

            self.df_output = df        
            
    # 모든 저장된 엑셀 파일을 병합하는 함수
    def merge_and_save_output_files(self):
        output_files = [f for f in os.listdir(self.save_path) if f.endswith(f'_kb시세조회_상세_{self.report_name}.xlsx')]
        merged_df = pd.DataFrame()

        # 각 파일을 읽고 병합
        for file in output_files:
            file_path = os.path.join(self.save_path, file)
            df = pd.read_excel(file_path)
            merged_df = pd.concat([merged_df, df], ignore_index=True)

        # 최종 병합 파일 저장
        final_output_path = os.path.join(self.save_path, f'Output_KB시세_{self.report_name}.xlsx')
        merged_df.to_excel(final_output_path, sheet_name='Output_KB시세', index=False)
        self.logger.info(f'Merged output saved to {final_output_path}')

    # 메인 실행 함수
    def run_app(self):
        df = pd.read_excel(self.npl_file_path, sheet_name='Input_KB시세', engine='openpyxl', header=5)
        df = df.iloc[:, 1:]
            
        self.driver = self.initiate_driver()

        for i, row in df.iterrows():
            # df_input 초기화
            self.df_output = pd.DataFrame(columns=['등기부등본고유번호', '등기부등본구분', '등기부등본주소', 'input주소', 'KB시세조회 주소', '부동산정보', '시세', '거래량', '일반가', '상위평균가', '하위평균가', '기준일자', '공급면적', '전용면적', '세대수'])

            # 변수 초기화 시도
            status = retry_handler(lambda: self.initiate_variables(row), logger=self.logger, error_message='initiate_variables에서 에러 발생')

            # KB 페이지 열기 시도
            if status:
                status = retry_handler(self.kb_page_open, logger=self.logger, error_message='kb_page_open 에러 발생')

            # 주소 검색 시도
            if status:
                status = retry_handler(self.search_address, logger=self.logger, error_message='search_address 에러 발생')

            # 최상단 결과 클릭 시도
            if status:
                status = retry_handler(self.click_first_result, logger=self.logger, error_message='click_first_result 에러 발생'); status = True

            # 팝업 페이지 클릭 후 새로고침 시도
            if status:
                status = retry_handler(self.click_popup_page, logger=self.logger, error_message='click_popup_page 에러 발생'); status = True

            # KB 주소 파싱 시도
            if status:
                status = retry_handler(self.get_kb_address, logger=self.logger, error_message='get_kb_address 에러 발생')

            # 상세 정보 클릭 시도
            if status:
                status = retry_handler(self.click_detail_info, logger=self.logger, error_message='click_detail_info 에러 발생'); status = True

            # 데이터 타입 확인 시도
            if status:
                status = retry_handler(self.check_data_type, logger=self.logger, error_message='check_data_type 에러 발생')

            # 상세 정보 가져오기 시도
            if status:
                status = retry_handler(self.get_detail_info, logger=self.logger, error_message='get_detail_info 에러 발생')

            # 평형 선택인 경우 데이터 처리
            if status and self.data_type == "평형 선택":
                status = retry_handler(self.case1_edit_data, logger=self.logger, error_message='case1_edit_data 에러 발생'); status = True

            # 평형 선택 후 가장 유사한 면적 클릭
            if status and self.data_type == "평형 선택":
                status = retry_handler(self.case1_click_close_area, logger=self.logger, error_message='case1_click_close_area 에러 발생'); status = True

            # 평형 선택 후 가격 정보 검색
            if status and self.data_type == "평형 선택":
                status = retry_handler(self.case1_search_close_area, logger=self.logger, error_message='case1_search_close_area 에러 발생'); status = True

            # 동호수 선택인 경우 기준일자 가져오기
            if status and self.data_type == "동호수 선택":
                status = retry_handler(self.case2_search_and_edit_data, logger=self.logger, error_message='case2_search_and_edit_data 에러 발생'); status = True

            # 최종 데이터프레임 로깅 및 저장
            self.logger.info(f'final dataframe : \n{self.df_output}')

            self.excel_control.save_dataframe(df=self.df_output, path=self.save_path, filename=f'{self.index_number}_kb시세조회_상세_{self.report_name}')

        self.merge_and_save_output_files()
        
        self.driver.quit()



# 재시도 처리 함수
def retry_handler(action, max_attempts=3, logger=None, error_message=""):
    attempt = 0
    while attempt < max_attempts:
        try:
            action()  # 제공된 작업 실행
            return True  # 성공하면 True 반환
        except Exception as e:
            attempt += 1
            if logger:
                logger.warning(f'{error_message} 재시도 {attempt}/{max_attempts}: {e}')
            if attempt >= max_attempts:
                if logger:
                    logger.error(f'{error_message} 최종 실패: {e}')
                return False  # 모든 시도가 실패하면 False 반환
            # 재시도 전에 짧은 지연 (옵션)
            time.sleep(1)

class ExcelHandler:
    def __init__(self, file_path):
        self.file_path = file_path
        self.workbook = load_workbook(file_path, data_only=True)

    def get_value(self, sheet_name, cell):
        """특정 셀의 값을 반환"""
        try:
            return self.workbook[sheet_name][cell].value
        except KeyError:
            return None

    def save_dataframe(self, df, path, filename):
        output_excel_path = os.path.join(path, f'{filename}.xlsx')
        df.to_excel(output_excel_path, index=False)

class FileManager:
    def __init__(self, save_path):
        self.save_path = save_path

    def read_or_create_folder(self):
        """폴더가 없는 경우 폴더 생성"""
        if not os.path.exists(self.save_path):
            os.makedirs(self.save_path)

    def remove_excel_files(self):
        """경로 내의 모든 파일을 삭제"""
        for filename in os.listdir(self.save_path):
            file_path = os.path.join(self.save_path, filename)

            if os.path.isfile(file_path):
                if not filename.endswith('.txt'):
                    os.remove(file_path)

if __name__ == '__main__':
    kb = kb_info()
    kb.run_app()
