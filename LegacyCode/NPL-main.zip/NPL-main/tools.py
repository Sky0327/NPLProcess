from selenium import webdriver
from selenium.webdriver.support.ui import WebDriverWait
from selenium.webdriver.chrome.options import Options
from selenium.webdriver.common.by import By
from selenium.webdriver.common.keys import Keys
from selenium.webdriver.support import expected_conditions as EC
from selenium.webdriver.support.ui import Select
from logger import Logger
from selenium.webdriver.common.action_chains import ActionChains
import pandas as pd
import requests

timeout = 5

def wait_and_write(driver, index, text):
    wait = WebDriverWait(driver, timeout)
    wait.until(EC.element_to_be_clickable((By.XPATH, index)))
    driver.find_element(By.XPATH, index).send_keys(text)

def wait_and_click(driver, index:str):
    wait = WebDriverWait(driver, timeout)
    wait.until(EC.element_to_be_clickable((By.XPATH, index)))
    driver.find_element(By.XPATH, index).click()

def wait_and_select(driver, index:str, selection:str):
    wait = WebDriverWait(driver, timeout)
    wait.until(EC.element_to_be_clickable((By.XPATH, index)))
    dropdown_element = driver.find_element(By.XPATH, index)
    select = Select(dropdown_element)
    select.select_by_visible_text(selection)

def wait_and_read(driver, index):
    wait = WebDriverWait(driver, timeout)
    wait.until(EC.element_to_be_clickable((By.XPATH, index)))
    text = driver.find_element(By.XPATH, index).text
    return text

def wait_and_scroll(driver, index):
    wait = WebDriverWait(driver, timeout)
    wait.until(EC.element_to_be_clickable((By.XPATH, index)))
    element = driver.find_element(By.XPATH, index)
    actions = ActionChains(driver)
    actions.move_to_element(element).perform()

def wait_and_get_table(driver, index):
    wait = WebDriverWait(driver, timeout)
    wait.until(EC.element_to_be_clickable((By.XPATH, index)))
    try:
        # 테이블 요소를 찾음
        table_element = driver.find_element(By.XPATH, index)
        
        # 테이블에서 모든 행(row)을 찾음
        rows = table_element.find_elements(By.TAG_NAME, "tr")
        
        # 데이터 저장을 위한 리스트 초기화
        table_data = []

        for row in rows:
            cols = row.find_elements(By.TAG_NAME, "td")
            row_data = [col.text for col in cols]
            table_data.append(row_data)

        for row in table_data:
            print(row)

        df = pd.DataFrame(table_data)
        return df
    except Exception as e:
        print(f"An error occurred: {e}")
        return None

def wait_and_download_image(driver, index, save_path):
    wait = WebDriverWait(driver, timeout)
    wait.until(EC.element_to_be_clickable((By.XPATH, index)))
    try:
        # XPath로 이미지 요소 찾기
        img_element = driver.find_element(By.XPATH, index)
        
        # src 속성에서 이미지 URL 추출
        img_url = img_element.get_attribute("src")
        
        # 이미지 다운로드
        img_data = requests.get(img_url).content
        
        # 파일로 저장
        with open(save_path, 'wb') as handler:
            handler.write(img_data)
        
        print(f"이미지가 성공적으로 저장되었습니다: {save_path}")
        
    except Exception as e:
        print(f"오류 발생: {e}")

if __name__=='__main__':
    pass