from selenium import webdriver
from selenium.webdriver.chrome.options import Options
from selenium.webdriver.common.by import By
from logger import Logger
import time
import tools as tools
import pandas as pd
import os
import glob
import sys
from openpyxl import load_workbook
import openpyxl
from PIL import Image

class infocare_analysis():
    def __init__(self) -> None:
        # 실행 파일의 위치 설정
        if getattr(sys, 'frozen', False):
            # PyInstaller로 빌드된 실행 파일인 경우
            exe_dir = os.path.dirname(sys.executable)
        else:
            # 스크립트로 실행되는 경우
            exe_dir = os.path.dirname(os.path.abspath(__file__))

        # 엑셀 파일의 위치
        self.npl_file_path = os.path.join(exe_dir, 'Smart_NPL.xlsm')

        # report_name 선언
        self.report_name = self.get_report_name(self.npl_file_path)

        # 엑셀 파일에서 B3 셀의 경로를 가져옴
        source_path = self.get_excel_path(self.npl_file_path, 'Source', 'B4')

        # 폴더 경로 설정
        self.save_path = os.path.join(source_path, 'Temp', '인포통계')
        self.logger = Logger(save_path=self.save_path, function_name='인포통계').get_logger()

        self.logger.debug(f'파일 저장 폴더 : {self.save_path}')
        self.logger.debug(f'Smart_NPL file_path : {self.npl_file_path}')      
        self.logger.debug(f'report name : {self.report_name}')  



        #폴더가 없는 경우 폴더 생성
        if not os.path.exists(self.save_path):
            self.logger.debug('파일 저장 경로 폴더 생성')
            os.makedirs(self.save_path)
        else:
            self.logger.debug('파일 저장 경로 존재')

            # 폴더 내 파일 삭제
            for filename in os.listdir(self.save_path):
                file_path = os.path.join(self.save_path, filename)
                try:
                    if os.path.isfile(file_path):  # 파일인지 확인
                        os.remove(file_path)
                        self.logger.debug(f'파일 삭제: {file_path}')
                except Exception as e:
                    self.logger.error(f'파일 삭제 중 오류 발생: {file_path}, {e}')
                    
        self.id, self.pw = self.get_id_pw(self.npl_file_path)
        self.logger.debug(f'id : {self.id}, pw : {self.pw}')

    def get_excel_path(self, file_path, sheet_name, cell):
        """엑셀 파일에서 지정한 시트와 셀의 값을 가져옴"""
        try:
            # 엑셀 파일을 불러오기
            workbook = load_workbook(file_path, data_only=True)
            sheet = workbook[sheet_name]
            
            # 셀의 값을 읽어옴
            path_value = sheet[cell].value
            
            return path_value
        except Exception as e:
            return None

    def get_id_pw(self, file_path):
        # 엑셀 파일 열기
        workbook = openpyxl.load_workbook(file_path)

        # source 시트 선택
        sheet = workbook['Source']
        
        # 'A'열을 순회하면서 '보고서명'을 찾고 해당 행의 'B'열 값을 가져옴
        for row in sheet.iter_rows(min_row=1, max_col=2):  # 'A'열과 'B'열만 확인
            if row[0].value == 'infocare_id':  # 'A'열 값이 '보고서명'이면
                id_str = row[1].value  # 'B'열 값 가져오기

        for row in sheet.iter_rows(min_row=1, max_col=2):  # 'A'열과 'B'열만 확인
            if row[0].value == 'infocare_pw':  # 'A'열 값이 '보고서명'이면
                pw_str = row[1].value  # 'B'열 값 가져오기                

        return id_str, pw_str

    def get_report_name(self, file_path):
        # 엑셀 파일 열기
        workbook = openpyxl.load_workbook(file_path)

        # source 시트 선택
        sheet = workbook['Source']
        
        # 'A'열을 순회하면서 '보고서명'을 찾고 해당 행의 'B'열 값을 가져옴
        for row in sheet.iter_rows(min_row=1, max_col=2):  # 'A'열과 'B'열만 확인
            if row[0].value == '보고서명':  # 'A'열 값이 '보고서명'이면
                b_value = row[1].value  # 'B'열 값 가져오기
                return b_value

        return None  # '보고서명'을 찾지 못했을 때 None 반환

    def get_path(self, file_path):
        # 엑셀 파일 열기
        workbook = openpyxl.load_workbook(file_path)

        # source 시트 선택
        sheet = workbook['Source']
        
        # 'A'열을 순회하면서 '보고서명'을 찾고 해당 행의 'B'열 값을 가져옴
        for row in sheet.iter_rows(min_row=1, max_col=2):  # 'A'열과 'B'열만 확인
            if row[0].value == '보고서폴더경로':  # 'A'열 값이 '보고서명'이면
                b_value = row[1].value  # 'B'열 값 가져오기
                return b_value

        return None  # '보고서명'을 찾지 못했을 때 None 반환

    def merge_excel(self, report_name):

        self.logger.debug('파일병합을 시도합니다.')

        directory = self.save_path

        file_pattern = os.path.join(directory, f'*인포케어_통계조회_{report_name}.xlsx')
        files = glob.glob(file_pattern)

        # 각 파일의 데이터를 읽어들이고 데이터프레임으로 통합합니다.
        dataframes = []
        for file in files:
            df = pd.read_excel(file)
            dataframes.append(df)

        # 모든 데이터프레임을 하나로 통합
        combined_df = pd.concat(dataframes, ignore_index=True)

        self.logger.debug(combined_df)

        for file in files:
            try:
                os.remove(file)
                print(f"Deleted: {file}")
            except OSError as e:
                print(f"Error deleting {file}: {e}")

        output_file = os.path.join(self.save_path, f'인포케어_통계조회_{report_name}.xlsx')
        combined_df.to_excel(output_file, sheet_name='Output_인포통계',index=False)
        self.logger.debug('파일 병합이 완료되어습니다.')

        final_path = os.path.join(self.save_path, f'Output_인포통계_{report_name}.xlsx')
        os.rename(output_file, final_path)
        self.logger.critical('산출물 작성을 완료하였습니다.')

    def crop_image(self, source_path, x, y, width, height):
        # 캡처한 이미지 불러오기
        screenshot = Image.open(source_path)

        # 자를 영역 계산
        left = x
        top = y
        right = x + width
        bottom = y + height

        # 영역 자르기
        cropped_image = screenshot.crop((left, top, right, bottom))

        # 잘라낸 이미지를 동일 경로에 저장 (덮어쓰기)
        cropped_image.save(source_path)
        print(f"이미지가 잘라내어 저장되었습니다: {source_path}")
        
    def main(self, report_name, df_input):

       
        #옵션세팅
        chrome_options = Options()
        chrome_options.add_experimental_option("detach", True)
        chrome_options.add_argument("--force-device-scale-factor=1")
        # chrome_options.add_argument("headless")
        driver = webdriver.Chrome(options=chrome_options)
        driver.implicitly_wait(5)
        self.logger.debug('Option setting 완료')

        self.logger.debug(f'검색할 데이터(전체) : {df_input}')
        for i, row in df_input.iterrows():
            status = True  

            # 각 변수에 행의 값을 할당
            index_number = row['등기부등본고유번호']
            index_class = row['등기부등본구분']
            index_address = row['등기부등본주소']
            sido = row['시/도']
            sigungu = row['군/구']
            eubmyundong = row['동/읍']
            yongdo_big = row['용도(대분류)']
            yongdo_small = row['용도(소분류)']

            search_keyword = f'{sido}_{sigungu}_{eubmyundong}_{yongdo_big}_{yongdo_small}'
            self.logger.debug(f'검색대상 : {search_keyword}')


            self.logger.debug('페이지 열기')
            self.logger.debug(f'status : {status}')
            if status:
                try:
                    driver.get(url='https://www.infocare.co.kr/')
                    driver.execute_script("window.location.reload();")
                    try:
                        driver.maximize_window()
                    except:
                        pass
                    self.logger.debug('페이지 열기 성공')
                except Exception as e:
                    status = False
                    self.logger.debug(f'페이지 열기 실패. {e}')

            
            self.logger.debug('프레임 조정')
            self.logger.debug(f'status : {status}')
            if status:
                try:
                    frames = driver.find_elements(By.TAG_NAME, "frame")
                    for index, frame in enumerate(frames):
                        name = frame.get_attribute("name")
                        frame_id = frame.get_attribute("id")
                        self.logger.debug(f"Frame {index}: Name = {name}, ID = {frame_id}")
                    driver.switch_to.frame(driver.find_element(By.NAME, 'info_main'))
                    self.logger.debug('프레임 전환 성공')
                except Exception as e :
                    status = False
                    self.logger.info(f'프레임 전환 실패. {e}')

            #로그인
            self.logger.debug('로그인 시도')
            self.logger.debug(f'status : {status}')

            if status:  
                try:  
                    tools.wait_and_click(driver=driver, index='/html/body/header/div/div[1]/div/ul/li[2]/a/span[1]')
                    tools.wait_and_write(driver=driver, index='/html/body/div[5]/div/div[2]/div[2]/div/div/div/form/div[1]/input', text=self.id)
                    tools.wait_and_write(driver=driver, index='/html/body/div[5]/div/div[2]/div[2]/div/div/div/form/div[2]/input[1]', text=self.pw)
                    tools.wait_and_click(driver=driver, index='/html/body/div[5]/div/div[2]/div[2]/div/div/button[1]')
                    try:
                        #로그인 시도 -> '기존 사용자 접속 해제' alert에 대하여 '확인'
                        time.sleep(3)
                        alert = driver.switch_to.alert
                        alert.accept()
                    except:
                        pass
                    self.logger.debug('로그인 성공')
                except Exception as e:
                    self.logger.info(f'로그인 실패. 기존에 로그인이 되어있는 경우 이후 코드가 정상적으로 작동됩니다. {e}')

            
            self.logger.debug('페이지 탐색')
            self.logger.debug(f'status : {status}')

            if status:
                time.sleep(1)
                try:
                    tools.wait_and_click(driver=driver, index='/html/body/header/div/div[3]/div[2]/ul/li[2]')
                    tools.wait_and_click(driver=driver, index='/html/body/div[1]/div/div[2]/ul[1]/li[2]/ul/li[2]/a')
                    time.sleep(0.2)
                    tools.wait_and_select(driver=driver, index='/html/body/section/div/div[3]/div/div/select[1]',selection=sido)
                    time.sleep(0.2)
                    tools.wait_and_select(driver=driver, index='/html/body/section/div/div[3]/div/div/select[2]',selection=sigungu)
                    time.sleep(0.2)
                    tools.wait_and_select(driver=driver, index='/html/body/section/div/div[3]/div/div/select[3]',selection=eubmyundong)
                    time.sleep(0.2)
                    tools.wait_and_select(driver=driver, index='/html/body/section/div/div[3]/div/div/select[4]',selection=yongdo_big)
                    time.sleep(0.2)
                    try:
                        tools.wait_and_select(driver=driver, index='/html/body/section/div/div[3]/div/div/select[5]',selection=yongdo_small)
                    except:
                        pass
                    time.sleep(0.2)
                    tools.wait_and_click(driver=driver, index='/html/body/section/div/div[3]/div/div/button')
                    self.logger.debug('페이지 탐색 성공')
                except Exception as e:
                    status = False
                    self.logger.info(f'페이지 탐색 실패. {e}')

            
            self.logger.debug('화면을 스크롤')
            self.logger.debug(f'status : {status}')
            if status:
                try:
                    try:
                        tools.wait_and_click(driver=driver, index='/html/body/div[1]/ul/li[1]/div/img')
                    except:
                        pass
                    tools.wait_and_scroll(driver=driver, index='/html/body/section/div/div[4]/div[3]/div[1]/p')
                    self.logger.debug('화면 스크롤 성공')
                except Exception as e:
                    status = False
                    self.logger.info(f'스크롤 실패. {e}')

            
            self.logger.debug('스크린샷을 시도')
            self.logger.debug(f'status : {status}')
            if status:
                try:
                    img_path = os.path.join(self.save_path, f'{search_keyword}_screenshot.png')
                    driver.save_screenshot(img_path)
                    
                    #이미지 자르기
                    element = driver.find_element(By.XPATH, '/html/body/section/div/div[2]/h3' )
                    x = element.location['x']
                    y = element.location['y']
                    width = 1200  # 요소의 너비
                    height = 770  # 요소의 높이
                    self.crop_image(img_path, x, y, width, height)

                    self.logger.debug('스크린샷 파일 저장 완료')
                except:
                    status = False
                    self.logger.info(f'스크린샷 실패. {e}')
                    
            
            
            self.logger.debug('지역/기간별 통계 테이블 데이터를 크롤링')
            self.logger.debug(f'status : {status}')
            if status:
                try:
                    df = tools.wait_and_get_table(driver=driver, index='/html/body/section/div/div[4]/div[2]/div[2]/table/tbody')

                except Exception as e:
                    status = False
                    self.logger.info(f'테이블 데이터 크롤링 실패. {e}')


            self.logger.debug('테이블 데이터 가공 및 저장')
            if status:
                try:
                    df['지역평균'] = ["1년간 평균", "6개월간 평균", "3개월간 평균"]
                    df = df[['지역평균'] + list(df.columns[:-1])]

                    # 변수 a, b, c에 할당된 텍스트로 헤더를 변경
                    a = [sido, sido, sido]
                    b = [sigungu, sigungu, sigungu]
                    c = [eubmyundong, eubmyundong, eubmyundong]

                    df.columns = ["지역평균"] + a + b + c
                    new_row = ['기간', '낙찰가율', '낙찰률 평균', '낙찰건수', '낙찰가율', '낙찰률 평균', '낙찰건수', '낙찰가율', '낙찰률 평균', '낙찰건수']
                    df.loc[-1] = new_row
                    df.index = df.index + 1  # 인덱스를 1씩 증가시킴
                    df = df.sort_index()  # 인덱스를 기준으로 데이터프레임을 정렬

                    
                    df.insert(0, search_keyword, search_keyword)
                    df.insert(0, index_address, index_address)
                    df.insert(0, index_class, index_class)
                    df.insert(0, index_number, index_number)

                    # 기존 헤더를 첫 번째 행으로 내리기
                    df.loc[-1] = df.columns  # 기존 헤더를 새로운 행으로 추가
                    df.index = df.index + 1  # 인덱스 값 조정
                    df = df.sort_index()     # 인덱스 순서대로 정렬

                    # 새로운 헤더 설정
                    new_header = ['등기부등본고유번호', '등기부등본구분', '등기부등본주소', '필터', '구분', '지역', '지역', '지역', '지역', '지역', '지역', '지역', '지역', '지역']
                    df.columns = new_header

                    self.logger.debug('Dataframe 정제 완료')

                    self.logger.debug(df)
                    output_path = os.path.join(self.save_path, f'{search_keyword}_인포케어_통계조회_{report_name}.xlsx')
                    df.to_excel(output_path, index=False)
                    self.logger.debug('Excel 저장 완료')
                except Exception as e:
                    status = False
                    self.logger.info(f'데이터 가공 및 저장 실패. {e}')
            if status:
                pass
            else:
                columns = ['등기부등본고유번호', '등기부등본구분', '등기부등본주소', '필터', '구분', '지역', '지역', '지역', '지역', '지역', '지역', '지역', '지역', '지역']
                data_with_vars = [[index_number, index_class, index_address, search_keyword, '조회 내역 없음'] + [None] * (len(columns) - 5)]
                df = pd.DataFrame(data_with_vars, columns=columns)
                output_path = os.path.join(self.save_path, f'{search_keyword}_인포케어_통계조회_{report_name}.xlsx')
                df.to_excel(output_path, index=False)
                self.logger.debug('dataframe 저장이 완료되었습니다.')
        
        
        tools.wait_and_click(driver=driver, index='/html/body/header/div/div[1]/div/ul/li[2]/a/span[2]')
        driver.minimize_window()
        time.sleep(5)
        driver.quit()
        
        # #낙찰사례 크롤링
        # self.logger.debug('낙찰사례 테이블 데이터를 크롤링합니다.')
        # df2 = tools.wait_and_get_table(driver=driver, index='/html/body/section/div/div[4]/div[3]/div[2]/div[1]/table')
        # self.logger.debug('테이블 데이터를 Dataframe으로 가져왔습니다.')

        # self.logger.debug(df2)


        # df2.to_excel('infocare3.xlsx', index=False)
        # self.logger.debug('낙찰사례 Dataframe 저장이 완료되었습니다.')
        # self.logger.critical('모든 작업이 완료되었습니다.')

    def fill_repeating_values(self, row):
        # 각 셀의 값이 None이 아니면 그 값을 세 번 반복
        filled_row = []
        last_value = None
        for val in row:
            if pd.notna(val):
                last_value = val
            filled_row.extend([last_value] * 3 if last_value is not None else [None])
        return filled_row[:len(row)]  # 원래 길이를 유지하기 위해 자름

    def run_app(self, filepath):
        #B6부터 시작하는 표를 dataframe으로 import

        df = pd.read_excel(filepath, sheet_name='Input_인포통계', engine='openpyxl', header=5)
        df = df.iloc[:, 1:]
        report_name = self.get_report_name(filepath)

        #각 행을 순환하며 main() 실행
        self.main(report_name, df)

        self.merge_excel(report_name)
        self.logger.critical('모든 작업이 완료되었습니다.')

if __name__ == '__main__':

    # sido='서울'
    # sigungu='강남구'
    # eubmyundong='개포동'
    # yongdo_big='집합건물'
    # yongdo_small='아파트'

    # main(sido, sigungu, eubmyundong, yongdo_big, yongdo_small)

    # data = {
    # 'index_number' : ['111', '222', '333'],
    # 'index_address' : ['주소1', '주소2', '주소3'],
    # 'sido': ['뚱땡보', '서울', '서울'],
    # 'sigungu': ['강남구', '강남구', '강남구'],
    # 'eubmyundong': ['논현동', '대치동', '개포동'],
    # 'yongdo_big': ['집합건물', '집합건물', '집합건물'],
    # 'yongdo_small': ['아파트', '아파트', '아파트']
    # }
    # df = pd.DataFrame(data)
    # run_app(df)

    filepath = r'Smart_NPL.xlsm'
    infocare_analysis().run_app(filepath)