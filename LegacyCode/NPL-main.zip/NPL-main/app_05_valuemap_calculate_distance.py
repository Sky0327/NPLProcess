import os
from datetime import datetime
import sys
import pandas as pd
import requests
from math import radians, sin, cos, sqrt, atan2
import concurrent.futures
import threading
import logging

# 리소스 파일 접근 함수
def resource_path(relative_path):
    """ PyInstaller로 패키징된 실행 파일에서 리소스 파일에 접근하는 함수 """
    try:
        # PyInstaller의 --onefile 모드에서는 _MEIPASS를 사용
        base_path = sys._MEIPASS
    except AttributeError:
        base_path = os.path.abspath(".")
    return os.path.join(base_path, relative_path)

# Kakao API 호출 함수
def call_kakao_api(address_name, kakao_api_key):
    url = "https://dapi.kakao.com/v2/local/search/address.json"
    headers = {"Authorization": f"KakaoAK {kakao_api_key}"}
    params = {"query": address_name, "size": "1"}
    try:
        response = requests.get(url, headers=headers, params=params)
        response.raise_for_status()
        data = response.json()
        if data['documents']:
            x = data['documents'][0]['address']['x']
            y = data['documents'][0]['address']['y']
            return x, y
        else:
            logging.warning(f"API 응답에 주소 정보가 없습니다: {address_name}")
            return None, None
    except requests.exceptions.RequestException as e:
        logging.error(f"API 호출에 실패했습니다: {e}")
        return None, None

# 1. Load API key and paths from Excel
def load_api_key_and_paths_from_excel(excel_path):
    excel_full_path = resource_path(excel_path)
    df = pd.read_excel(excel_full_path, sheet_name='Source', engine='openpyxl')
    report_folder_path = df.loc[df.iloc[:, 0] == '보고서폴더경로', df.columns[1]].values[0]
    kakao_api_key = df.loc[df.iloc[:, 0] == 'kakao_apikey', df.columns[1]].values[0]
    return report_folder_path, kakao_api_key

# 2. Load input data from Excel
def load_input_data_from_excel(excel_path):
    excel_full_path = resource_path(excel_path)
    df_input = pd.read_excel(excel_full_path, sheet_name='Output_실거래가_밸류맵', header=5, engine='openpyxl')
    df_input.columns = df_input.columns.str.strip()
    df_input = df_input[df_input['대상여부'].notna()].reset_index(drop=True)
    return df_input

# 3. Create '대상주소' column
def create_target_address_column(df):
    df['대상주소'] = df[['도/시', '군/구', 'umdNm', 'jibun']].astype(str).agg(' '.join, axis=1)
    return df

# 4. Get coordinates using multithreading and progress updates
def get_unique_address_coordinates(df, address_column, x_column_name, y_column_name, kakao_api_key):
    unique_addresses = df[address_column].unique()
    address_coords = {}
    total = len(unique_addresses)
    progress_counter = 0
    progress_lock = threading.Lock()

    def fetch_coordinates(address):
        nonlocal progress_counter
        if pd.isna(address):
            return (address, (None, None))
        x, y = call_kakao_api(address, kakao_api_key)
        # 진행 상황 업데이트
        with progress_lock:
            progress_counter += 1
            logging.info(f"API 호출 성공! [{progress_counter} / {total}] {address}")
        return (address, (x, y))

    with concurrent.futures.ThreadPoolExecutor(max_workers=10) as executor:
        future_to_address = {executor.submit(fetch_coordinates, address): address for address in unique_addresses}
        for future in concurrent.futures.as_completed(future_to_address):
            try:
                address, coords = future.result()
                address_coords[address] = coords
            except Exception as e:
                logging.error(f"Error fetching coordinates for address: {future_to_address[future]} - {e}")

    df[x_column_name] = df[address_column].map(lambda addr: address_coords.get(addr, (None, None))[0])
    df[y_column_name] = df[address_column].map(lambda addr: address_coords.get(addr, (None, None))[1])
    return df

# 5. Calculate distance between two points
def haversine(lon1, lat1, lon2, lat2):
    R = 6371  # 지구의 반지름 (킬로미터)
    try:
        lon1_rad, lat1_rad, lon2_rad, lat2_rad = map(radians, [float(lon1), float(lat1), float(lon2), float(lat2)])
    except (ValueError, TypeError) as e:
        logging.error(f"좌표 변환 오류: {e} (lon1={lon1}, lat1={lat1}, lon2={lon2}, lat2={lat2})")
        return None
    dlon = lon2_rad - lon1_rad
    dlat = lat2_rad - lat1_rad
    a = sin(dlat / 2) ** 2 + cos(lat1_rad) * cos(lat2_rad) * sin(dlon / 2) ** 2
    c = 2 * atan2(sqrt(a), sqrt(1 - a))
    distance = R * c * 1000  # 미터로 변환
    return distance

# 6. Merge data and calculate distances
def calculate_distances(df):
    df['물건_x'] = pd.to_numeric(df['물건_x'], errors='coerce')
    df['물건_y'] = pd.to_numeric(df['물건_y'], errors='coerce')
    df['사례_x'] = pd.to_numeric(df['사례_x'], errors='coerce')
    df['사례_y'] = pd.to_numeric(df['사례_y'], errors='coerce')

    def compute_distance(row):
        if pd.notnull(row['물건_x']) and pd.notnull(row['사례_x']):
            return haversine(row['물건_x'], row['물건_y'], row['사례_x'], row['사례_y'])
        else:
            return None

    df['거리(m)'] = df.apply(compute_distance, axis=1)
    df['거리(m)'] = df['거리(m)'].round(0).astype('Int64')
    # Drop unnecessary columns
    df = df.drop(columns=['물건_x', '물건_y', '사례_x', '사례_y', '대상여부', 'Unnamed: 0'], errors='ignore')
    return df

# 7. Sort within '등기부등본주소' blocks by '거리(m)'
def sort_within_blocks(df):
    df_sorted = df.sort_values(['등기부등본주소', '거리(m)'])
    # Reorder columns to place '거리(m)' after '등기부등본주소'
    cols = df_sorted.columns.tolist()
    if '거리(m)' in cols and '등기부등본주소' in cols:
        distance_col = cols.pop(cols.index('거리(m)'))
        address_col_index = cols.index('등기부등본주소') + 1
        cols.insert(address_col_index, distance_col)
        df_sorted = df_sorted[cols]
    return df_sorted

# 8. Save the DataFrame to Excel
def save_to_excel(df, report_folder_path):
    # Get the report name from the last directory in the report_folder_path
    report_name = os.path.basename(report_folder_path.rstrip('/\\'))
    
    # Create Temp and 거리계산_밸류맵 directories
    temp_folder = os.path.join(report_folder_path, 'Temp', '거리계산_밸류맵')
    os.makedirs(temp_folder, exist_ok=True)
    
    # Create the temporary file path
    temp_output_file = os.path.join(temp_folder, f"Temp_Output_거리계산_밸류맵_{report_name}.xlsx")
    
    # Final file path after renaming
    final_output_file = os.path.join(temp_folder, f"Output_거리계산_밸류맵_{report_name}.xlsx")
    
    # Save to Excel (as temporary file first)
    try:
        df.to_excel(temp_output_file, sheet_name='Output_거리_밸류맵', index=False)
        logging.info(f"Temporary data has been saved to {temp_output_file}")
    except Exception as e:
        logging.error(f"Error saving temporary Excel file: {e}")
        return

    # Rename the temporary file to the final file name
    try:
        os.rename(temp_output_file, final_output_file)
        logging.info(f"File renamed to: {final_output_file}")
    except Exception as e:
        logging.error(f"Error renaming file {temp_output_file} to {final_output_file}: {e}")


# Main function
def run_valuemap_calculate_distance(excel_path):
    # Step 1
    report_folder_path, kakao_api_key = load_api_key_and_paths_from_excel(excel_path)
    
    # Set up logging after report_folder_path is known
    temp_folder = os.path.join(report_folder_path, 'Temp', '거리계산_밸류맵')
    os.makedirs(temp_folder, exist_ok=True)
    timestamp = datetime.now().strftime('%y%m%d_%H%M%S')
    log_file = os.path.join(temp_folder, f'valuemap_calculate_distance_{timestamp}.log')
    
    logging.basicConfig(
        filename=log_file,
        level=logging.INFO,
        format='%(asctime)s %(levelname)s:%(message)s',
        datefmt='%Y-%m-%d %H:%M:%S'
    )
    
    # Optional: Add console handler if needed (won't display due to --noconsole)
    # If you want to keep logs only in the file, you can skip adding StreamHandler
    console = logging.StreamHandler()
    console.setLevel(logging.INFO)
    formatter = logging.Formatter('%(asctime)s %(levelname)s:%(message)s')
    console.setFormatter(formatter)
    logging.getLogger('').addHandler(console)
    
    logging.info("Starting run_valuemap_calculate_distance")
    logging.info("보고서폴더경로와 API 키를 불러왔습니다.")

    # Step 2
    df_input = load_input_data_from_excel(excel_path)
    logging.info("입력 데이터를 불러왔습니다.")

    # Step 3
    logging.info("물건 좌표를 가져오는 중...")
    df_input = get_unique_address_coordinates(df_input, '등기부등본주소', '물건_x', '물건_y', kakao_api_key)
    logging.info("물건 좌표를 가져왔습니다.")

    # Step 4
    logging.info("사례 좌표를 가져오는 중...")
    df_input = get_unique_address_coordinates(df_input, '주소', '사례_x', '사례_y', kakao_api_key)
    logging.info("사례 좌표를 가져왔습니다.")

    # Step 5 and 6
    logging.info("거리를 계산하는 중...")
    df_with_distances = calculate_distances(df_input)
    logging.info("거리를 계산했습니다.")

    # Step 7
    df_sorted = sort_within_blocks(df_with_distances)

    # Step 8
    save_to_excel(df_sorted, report_folder_path)
    logging.info("run_valuemap_calculate_distance completed successfully.")

if __name__ == "__main__":
    excel_path = "Smart_NPL.xlsm"
    run_valuemap_calculate_distance(excel_path)
