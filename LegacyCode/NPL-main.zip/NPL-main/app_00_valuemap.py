import pandas as pd
import time
import os
import tools as tools
from selenium import webdriver
from selenium.webdriver.common.by import By
from selenium.webdriver.chrome.options import Options
from selenium.webdriver.support.ui import WebDriverWait
from selenium.webdriver.support import expected_conditions as EC
from selenium.common.exceptions import NoSuchElementException, TimeoutException, ElementClickInterceptedException

# 버전 : 2025-04-02

class FileManager:
    def __init__(self, base_path):
        self.base_path = base_path
        
    def read_or_create_folder(self):
        """폴더가 없는 경우 폴더 생성"""
        if not os.path.exists(self.base_path):
            os.makedirs(self.base_path)
            
    def remove_download_folder(self):
        """다운로드 폴더와 그 내용을 모두 삭제"""
        import shutil
        download_path = os.path.join(self.base_path, 'download')
        try:
            if os.path.exists(download_path):
                shutil.rmtree(download_path)
                print("다운로드 폴더가 성공적으로 삭제되었습니다.")
        except Exception as e:
            print(f"다운로드 폴더 삭제 중 오류 발생: {str(e)}")

def valuemap(excel_path):
    
    # 엑셀 파일에서 "Source" 시트의 데이터 불러오기
    df_source = pd.read_excel(excel_path, sheet_name='Source')

    # 입력 변수 설정
    base_path = df_source.loc[df_source.iloc[:, 0] == '보고서폴더경로', df_source.columns[1]].values[0]
    report_name = df_source.loc[df_source.iloc[:, 0] == "보고서명", df_source.columns[1]].values[0]
    output_folder_path = os.path.join(base_path, 'Temp', '실거래가조회_밸류맵')
    output_download_path = os.path.join(output_folder_path, "download")
    
    login_ID = df_source.loc[df_source.iloc[:, 0] == "value_map_id", df_source.columns[1]].values[0]
    login_PW = df_source.loc[df_source.iloc[:, 0] == "value_map_pw", df_source.columns[1]].values[0]

    output_file_name = f"Output_밸류맵_실거래가조회_{report_name}.xlsx"
    input_sheet_name = "Input_실거래가"
    output_sheet_name = "Output_실거래가_밸류맵"

    # 고정 변수
    url = 'https://www.valueupmap.com/search'

    # ChromeDriver 설정
    options = Options()
    prefs = {
        "download.default_directory": output_download_path ,  # 다운로드 폴더 경로 설정
        "download.prompt_for_download": False,  # 다운로드 시 팝업 없이 자동 저장
        "safebrowsing.enabled": True  # 안전하지 않은 파일을 다운로드 할 때 경고를 비활성화
    }
    options.add_experimental_option("prefs", prefs)
    options.add_experimental_option("detach", True)  # 화면이 꺼지지 않고 유지
    options.add_experimental_option("excludeSwitches", ["enable-logging"])
    driver = webdriver.Chrome(options=options)
    driver.maximize_window()
    wait = WebDriverWait(driver, 15)

    # 웹 페이지 open
    driver.get(url)
    tools.wait_and_click(driver=driver, index='/html/body/main/div[1]/div[2]/div/div[3]/button')

    # ID, PW 입력 및 로그인 버튼 클릭
    tools.wait_and_write(driver=driver, index='/html/body/div[1]/div[1]/section/form[1]/div/article[1]/div[1]/input', text=login_ID)
    tools.wait_and_write(driver=driver, index='/html/body/div[1]/div[1]/section/form[1]/div/article[1]/div[2]/input', text=login_PW)
    tools.wait_and_click(driver=driver, index='/html/body/div[1]/div[1]/section/form[1]/div/article[1]/a')

    # 지역 추가 버튼 클릭
    tools.wait_and_click(driver=driver, index='/html/body/main/div[1]/div[2]/div/div[1]/div[1]/div[2]/div/button')

    def save_to_excel(df, output_folder_path, output_file_name, output_sheet_name):

        # 임시 파일 경로 설정
        temp_output_file = os.path.join(output_folder_path, f"Temp_{output_file_name}")
        # 최종 파일 경로 설정
        final_output_file = os.path.join(output_folder_path, output_file_name)

        # 임시 파일에 저장
        with pd.ExcelWriter(temp_output_file, engine='xlsxwriter') as writer:
            df.to_excel(writer, index=False, sheet_name=output_sheet_name)

        # 파일 이름 변경
        os.rename(temp_output_file, final_output_file)

    # 각 위치의 div 요소를 찾음
    def click_button_by_text(target_buttons):
        # 버튼 1 클릭 및 검증
        time.sleep(0.3)
        buttons1 = driver.find_element(By.XPATH, '/html/body/div[1]/div/div/div/div[4]/div[1]').find_elements(By.TAG_NAME, "button")
        for button in buttons1:
            if button.text == target_buttons[0]:
                for attempt_click in range(3):
                    try:
                        button.click()  # 클릭 시도
                        break  # 클릭 성공하면 break
                    except (ElementClickInterceptedException, NoSuchElementException):
                        scrollable_div = driver.find_element(By.XPATH, '/html/body/div[1]/div/div/div/div[4]/div[1]')
                        driver.execute_script("arguments[0].scrollBy(0, 300);", scrollable_div)
                        time.sleep(0.3)  # 약간의 대기 후 재시도

                for attempt in range(10):  # 최대 10번 확인
                    try:
                        span_text = driver.find_element(By.XPATH, "/html/body/div[1]/div/div/div/div[3]/span[1]").text
                        if span_text == button.text:
                            break  # 일치하면 다음 버튼으로 넘어감
                    except NoSuchElementException:
                        pass
                    time.sleep(0.3)  # 0.3초 대기
                break

        # 버튼 2 클릭 및 검증
        buttons2 = driver.find_element(By.XPATH, '/html/body/div[1]/div/div/div/div[4]/div[2]').find_elements(By.TAG_NAME, "button")
        for button in buttons2:
            if button.text == target_buttons[1]:
                for attempt_click in range(3):
                    try:
                        button.click()  # 클릭 시도
                        break  # 클릭 성공하면 break
                    except (ElementClickInterceptedException, NoSuchElementException):
                        scrollable_div = driver.find_element(By.XPATH, '/html/body/div[1]/div/div/div/div[4]/div[2]')
                        driver.execute_script("arguments[0].scrollBy(0, 300);", scrollable_div)
                        time.sleep(0.3)  # 약간의 대기 후 재시도

                for attempt in range(10):  # 최대 10번 확인
                    try:
                        span_text = driver.find_element(By.XPATH, "/html/body/div[1]/div/div/div/div[3]/span[2]").text
                        if span_text == button.text:
                            break  # 일치하면 다음 버튼으로 넘어감
                    except NoSuchElementException:
                        pass
                    time.sleep(0.3)  # 0.3초 대기
                break

        # 버튼 3 클릭 및 검증
        buttons3 = driver.find_element(By.XPATH, '/html/body/div[1]/div/div/div/div[4]/div[3]').find_elements(By.TAG_NAME, "button")
        for button in buttons3:
            if button.text == target_buttons[2]:
                for attempt_click in range(3):
                    try:
                        button.click()  # 클릭 시도
                        time.sleep(0.5)
                        return True  # 클릭 성공하면 True 반환
                    except (ElementClickInterceptedException, NoSuchElementException):
                        scrollable_div = driver.find_element(By.XPATH, '/html/body/div[1]/div/div/div/div[4]/div[3]')
                        driver.execute_script("arguments[0].scrollBy(0, 300);", scrollable_div)
                        time.sleep(0.3)  # 약간의 대기 후 재시도
                return False
        return False

    def click_based_on_type(driver, type_for_valuemap):
        xpath_dict = {
            "토지": '/html/body/main/div[1]/div[2]/div/div[1]/div[2]/div[2]/div[1]/div[1]/label',
            "단독/다가구": '/html/body/main/div[1]/div[2]/div/div[1]/div[2]/div[2]/div[1]/div[2]/label',
            "상업업무": '/html/body/main/div[1]/div[2]/div/div[1]/div[2]/div[2]/div[1]/div[3]/label',
            "공장/창고": '/html/body/main/div[1]/div[2]/div/div[1]/div[2]/div[2]/div[1]/div[4]/label',
            "상가": '/html/body/main/div[1]/div[2]/div/div[1]/div[2]/div[2]/div[1]/div[5]/label'
        }
        
        if type_for_valuemap in xpath_dict:
            xpath = xpath_dict[type_for_valuemap]
            tools.wait_and_click(driver=driver, index=xpath)

    def process_button_sets_from_row(row_data):
        row_num = row_data.name + 1
        
        # 각 행별 output_download_key와 output_download_path 설정
        output_download_key = str(row_data.iloc[1])  # 3번째 열의 값
        output_download_path = os.path.join(output_folder_path, 'download', output_download_key)

        # 다운로드 경로를 다시 설정
        prefs["download.default_directory"] = output_download_path
        driver.execute_cdp_cmd('Page.setDownloadBehavior', {'behavior': 'allow', 'downloadPath': output_download_path})
        
        # 필요한 폴더가 없으면 생성
        if not os.path.exists(output_download_path):
            os.makedirs(output_download_path)
        
        driver.get(url)
        tools.wait_and_click(driver=driver, index='/html/body/main/div[1]/div[2]/div/div[1]/div[1]/div[2]/div/button')
        
        for attempt3 in range(10):
            try:
                WebDriverWait(driver, 10).until(EC.text_to_be_present_in_element((By.XPATH, '/html/body/div[1]/div/div/div/div[4]/div[1]/button[1]'), "강원특별자치도"))
                break
            except TimeoutException:
                pass

        try:
            time.sleep(0.3)
            type_for_valuemap = row_data.iloc[5]  # F열 (6번째 열)
            target_buttons_set1 = row_data.iloc[[7, 8, 9]].tolist()
            button_sets = []

            if not any(pd.isna(button) for button in target_buttons_set1):
                button_sets.append(target_buttons_set1)

            column_start = 15  # P열부터 시작
            for i in range(9):  # 2번째 세트부터 최대 10번째 세트까지 (9개 추가)
                button_set = row_data.iloc[column_start + (i * 3):column_start + (i * 3) + 3].tolist()
                if not any(pd.isna(button) for button in button_set):
                    button_sets.append(button_set)

            for i, target_buttons in enumerate(button_sets, 1):
                if not click_button_by_text(target_buttons):
                    raise ValueError(f"Button set {i} processing failed.")
            
        except Exception as e:
            pass

        tools.wait_and_click(driver=driver, index='/html/body/div[1]/div/div/div/div[5]/div[2]/button')
        tools.wait_and_click(driver=driver, index='/html/body/main/div[1]/div[2]/div/div[1]/div[2]/div[2]/div[1]/label')

        click_based_on_type(driver, type_for_valuemap)

        tools.wait_and_click(driver=driver, index='/html/body/main/div[1]/div[2]/div/div[1]/div[5]/div[2]/div[1]/label[5]')
        tools.wait_and_click(driver=driver, index='/html/body/main/div[1]/div[2]/div/div[2]/button[3]')
        tools.wait_and_click(driver=driver, index='/html/body/main/div[1]/div[2]/div[2]/div[1]/div/div[1]/div[2]/button') #제곱미터로 전환
                
        try:
            WebDriverWait(driver, 10).until(EC.text_to_be_present_in_element((By.XPATH, '/html/body/main/div[1]/div[2]/div[2]/div[1]/div/div[1]/div[2]/div[3]/button'), "엑셀 다운로드"))
        except TimeoutException:
            pass

        tools.wait_and_click(driver=driver, index='/html/body/main/div[1]/div[2]/div[2]/div[1]/div/div[1]/div[2]/div[3]/button')
        tools.wait_and_click(driver=driver, index='/html/body/div[1]/div/div/div/div/button[2]')
        tools.wait_and_click(driver=driver, index='/html/body/div[1]/div/div/div/div/button')
        tools.wait_and_click(driver=driver, index='/html/body/main/div[5]/main/div[2]/div[1]/button')        
        
        time.sleep(1)

    def merge_xlsx_files(output_folder_path, output_file_name, output_sheet_name):
        base_download_path = os.path.join(output_folder_path, 'download')
        xlsx_files = []
        
        # 다운로드 폴더 하위에 있는 모든 엑셀 파일들 가져오기
        for root, dirs, files in os.walk(base_download_path):
            for file in files:
                if file.endswith('.xlsx'):
                    xlsx_files.append(os.path.join(root, file))
        
        print(f"총 {len(xlsx_files)}개의 파일이 발견되었습니다.")
        
        if not xlsx_files:
            print("엑셀 파일이 발견되지 않았습니다.")
            return

        merged_df = pd.DataFrame()

        for idx, file_path in enumerate(xlsx_files):
            folder_name = os.path.basename(os.path.dirname(file_path))
            print(f"{idx + 1}. {file_path} 파일을 병합 중입니다. 폴더 이름: {folder_name}")
            
            df = pd.read_excel(file_path)
            df.insert(0, '등기부등본주소', folder_name)
            merged_df = pd.concat([merged_df, df], ignore_index=True)
        
        if merged_df.empty:
            print("병합할 데이터가 없습니다.")
            return
        
        print("모든 파일이 성공적으로 병합되었습니다.")
        
        if not os.path.exists(output_folder_path):
            os.makedirs(output_folder_path)
            print(f"'{output_folder_path}' 경로가 존재하지 않아 새로 생성했습니다.")
        
        # 엑셀 파일 저장
        save_to_excel(merged_df, output_folder_path, output_file_name, output_sheet_name)

    # FileManager 인스턴스 생성
    file_manager = FileManager(output_folder_path)
    
    df_full = pd.read_excel(excel_path, sheet_name=input_sheet_name, header=None)
    last_row = df_full.iloc[:, 1].last_valid_index() + 1

    df_input = pd.read_excel(excel_path, sheet_name=input_sheet_name, skiprows=5, usecols='A:AS', nrows=last_row - 5)
    df_input2 = df_input.loc[(df_input.iloc[:, 10] == "밸류맵") & (df_input.iloc[:, 11] == "V")]

    for idx, row_data in df_input2.iterrows():
        process_button_sets_from_row(row_data)

    time.sleep(4)
    driver.minimize_window()
    #driver.quit()
    merge_xlsx_files(output_folder_path, output_file_name, output_sheet_name)
    
    # 다운로드 폴더 삭제
    file_manager.remove_download_folder()

# main.py에서 import하여 실행할 수 있도록 함수만 남김
if __name__ == "__main__":
    excel_path = "Smart_NPL.xlsm"
    valuemap(excel_path)
