from selenium import webdriver
from selenium.webdriver.chrome.options import Options
from selenium.webdriver.common.by import By
from selenium.webdriver.common.keys import Keys
from logger import Logger
import time
import tools as tools
from bs4 import BeautifulSoup
from selenium.webdriver.support import expected_conditions as EC
import pandas as pd
import os
import glob
import sys
import openpyxl
import re
from openpyxl import load_workbook


class inforcare_integrated():
    def __init__(self):
        # 실행 파일의 위치 설정
        if getattr(sys, 'frozen', False):
            # PyInstaller로 빌드된 실행 파일인 경우
            exe_dir = os.path.dirname(sys.executable)
        else:
            # 스크립트로 실행되는 경우
            exe_dir = os.path.dirname(os.path.abspath(__file__))

        # 엑셀 파일의 위치
        self.npl_file_path = os.path.join(exe_dir, 'Smart_NPL.xlsm')

        # report_name 선언
        self.report_name = self.get_report_name(self.npl_file_path)

        # 엑셀 파일에서 B3 셀의 경로를 가져옴
        source_path = self.get_excel_path(self.npl_file_path, 'Source', 'B4')

        # 폴더 경로 설정
        self.save_path = os.path.join(source_path, 'Temp', '인포통합')
        self.logger = Logger(save_path=self.save_path, function_name='인포통합').get_logger()

        self.logger.debug(f'파일 저장 폴더 : {self.save_path}')
        self.logger.debug(f'Smart_NPL file_path : {self.npl_file_path}')      
        self.logger.debug(f'report name : {self.report_name}')  

        #폴더가 없는 경우 폴더 생성
        if not os.path.exists(self.save_path):
            self.logger.debug('파일 저장 경로 폴더 생성')
            os.makedirs(self.save_path)
        else:
            self.logger.debug('파일 저장 경로 존재')

            # 폴더 내 파일 삭제
            for filename in os.listdir(self.save_path):
                file_path = os.path.join(self.save_path, filename)
                try:
                    if os.path.isfile(file_path):  # 파일인지 확인
                        os.remove(file_path)
                        self.logger.debug(f'파일 삭제: {file_path}')
                except Exception as e:
                    self.logger.error(f'파일 삭제 중 오류 발생: {file_path}, {e}')
                    
        self.id, self.pw = self.get_id_pw(self.npl_file_path)
        self.logger.debug(f'id : {self.id}, pw : {self.pw}')

    def get_excel_path(self, file_path, sheet_name, cell):
        """엑셀 파일에서 지정한 시트와 셀의 값을 가져옴"""
        try:
            # 엑셀 파일을 불러오기
            workbook = load_workbook(file_path, data_only=True)
            sheet = workbook[sheet_name]
            
            # 셀의 값을 읽어옴
            path_value = sheet[cell].value
            
            return path_value
        except Exception as e:

            return None



    def get_id_pw(self, file_path):
        # 엑셀 파일 열기
        workbook = openpyxl.load_workbook(file_path)

        # source 시트 선택
        sheet = workbook['Source']
        
        # 'A'열을 순회하면서 '보고서명'을 찾고 해당 행의 'B'열 값을 가져옴
        for row in sheet.iter_rows(min_row=1, max_col=2):  # 'A'열과 'B'열만 확인
            if row[0].value == 'infocare_id':  # 'A'열 값이 '보고서명'이면
                id_str = row[1].value  # 'B'열 값 가져오기

        for row in sheet.iter_rows(min_row=1, max_col=2):  # 'A'열과 'B'열만 확인
            if row[0].value == 'infocare_pw':  # 'A'열 값이 '보고서명'이면
                pw_str = row[1].value  # 'B'열 값 가져오기     

        return id_str, pw_str

    def get_report_name(self, file_path):
        # 엑셀 파일 열기
        workbook = openpyxl.load_workbook(file_path)

        # source 시트 선택
        sheet = workbook['Source']
        
        # 'A'열을 순회하면서 '보고서명'을 찾고 해당 행의 'B'열 값을 가져옴
        for row in sheet.iter_rows(min_row=1, max_col=2):  # 'A'열과 'B'열만 확인
            if row[0].value == '보고서명':  # 'A'열 값이 '보고서명'이면
                b_value = row[1].value  # 'B'열 값 가져오기
                return b_value

        return None  # '보고서명'을 찾지 못했을 때 None 반환

    def get_path(self, file_path):
        # 엑셀 파일 열기
        workbook = openpyxl.load_workbook(file_path)

        # source 시트 선택
        sheet = workbook['Source']
        
        # 'A'열을 순회하면서 '보고서폴더경로'을 찾고 해당 행의 'B'열 값을 가져옴
        for row in sheet.iter_rows(min_row=1, max_col=2):  # 'A'열과 'B'열만 확인
            if row[0].value == '보고서폴더경로':  # 'A'열 값이 '보고서폴더경로'
                b_value = row[1].value  # 'B'열 값 가져오기

                return b_value

        return None  # '보고서폴더경로'을 찾지 못했을 때 None 반환

    def merge_excel(self, report_name):

        self.logger.debug('파일병합을 시도합니다.')

        # 엑셀 파일이 있는 디렉토리를 현재 디렉토리로 설정
        file_pattern = os.path.join(self.save_path, f'*인포케어_통합검색_{report_name}*.xlsx')
        files = glob.glob(file_pattern)

        # 파일이 없는 경우 처리
        if not files:
            self.logger.warning('파일이 없습니다.')
            print('파일이 없습니다.')
            return

        # 각 파일의 데이터를 읽어들이고 데이터프레임으로 통합
        dataframes = []
        for file in files:
            df = pd.read_excel(file)
            dataframes.append(df)

        # 모든 데이터프레임을 하나로 통합
        combined_df = pd.concat(dataframes, ignore_index=True)

        self.logger.debug(combined_df)

        # 통합된 데이터프레임을 새로운 엑셀 파일로 저장
        output_file = os.path.join(self.save_path, f'인포케어_통합검색_{report_name}.xlsx')
        

        # 병합 후 원본 파일 삭제
        for file in files:
            try:
                os.remove(file)
                self.logger.debug(f"Deleted: {file}")
            except OSError as e:
                self.logger.debug(f"Error deleting {file}: {e}")

        combined_df.to_excel(output_file, sheet_name='Output_인포통합', index=False)
        self.logger.critical('작업이 완료되었습니다.')

        final_path = os.path.join(self.save_path, f'Output_인포통합_{report_name}.xlsx')
        os.rename(output_file, final_path)
        self.logger.critical('산출물 작성을 완료하였습니다.')        



    def find_yongdo(self, yongdo):
        if yongdo == '근린주택':
            return '/html/body/section/div[1]/div[3]/form/div[1]/table/tbody[5]/tr[2]/td[2]/ul/li[1]/label/span'
        elif yongdo == '다가구':
            return '/html/body/section/div[1]/div[3]/form/div[1]/table/tbody[5]/tr[2]/td[2]/ul/li[2]/label/span'
        elif yongdo == '단독주택':
            return '/html/body/section/div[1]/div[3]/form/div[1]/table/tbody[5]/tr[2]/td[2]/ul/li[3]/label/span'
        elif yongdo == '전원주택':
            return '/html/body/section/div[1]/div[3]/form/div[1]/table/tbody[5]/tr[2]/td[2]/ul/li[4]/label/span'
        elif yongdo == '다세대':
            return '/html/body/section/div[1]/div[3]/form/div[1]/table/tbody[5]/tr[3]/td[2]/ul/li[1]/label/span'
        elif yongdo == '아파트':
            return '/html/body/section/div[1]/div[3]/form/div[1]/table/tbody[5]/tr[3]/td[2]/ul/li[2]/label/span'
        elif yongdo == '연립':
            return '/html/body/section/div[1]/div[3]/form/div[1]/table/tbody[5]/tr[3]/td[2]/ul/li[3]/label/span'
        elif yongdo == '오피스텔':
            return '/html/body/section/div[1]/div[3]/form/div[1]/table/tbody[5]/tr[3]/td[2]/ul/li[4]/label/span'
        elif yongdo == '오피스텔(주거)':
            return '/html/body/section/div[1]/div[3]/form/div[1]/table/tbody[5]/tr[3]/td[2]/ul/li[5]/label/span'
        elif yongdo == '주상복합(주거)':
            return '/html/body/section/div[1]/div[3]/form/div[1]/table/tbody[5]/tr[3]/td[2]/ul/li[6]/label/span'
        elif yongdo == '근린상가':
            return '/html/body/section/div[1]/div[3]/form/div[1]/table/tbody[5]/tr[4]/td[2]/ul/li[1]/label/span'
        elif yongdo == '빌딩':
            return '/html/body/section/div[1]/div[3]/form/div[1]/table/tbody[5]/tr[4]/td[2]/ul/li[2]/label/span'
        elif yongdo == '사무실':
            return '/html/body/section/div[1]/div[3]/form/div[1]/table/tbody[5]/tr[4]/td[2]/ul/li[3]/label/span'
        elif yongdo == '상가':
            return '/html/body/section/div[1]/div[3]/form/div[1]/table/tbody[5]/tr[4]/td[2]/ul/li[4]/label/span'
        elif yongdo == '시장':
            return '/html/body/section/div[1]/div[3]/form/div[1]/table/tbody[5]/tr[4]/td[2]/ul/li[5]/label/span'
        elif yongdo == '아파트상가':
            return '/html/body/section/div[1]/div[3]/form/div[1]/table/tbody[5]/tr[4]/td[2]/ul/li[6]/label/span'
        elif yongdo == '오피스텔(상가)':
            return '/html/body/section/div[1]/div[3]/form/div[1]/table/tbody[5]/tr[4]/td[2]/ul/li[7]/label/span'
        elif yongdo == '점포':
            return '/html/body/section/div[1]/div[3]/form/div[1]/table/tbody[5]/tr[4]/td[2]/ul/li[8]/label/span'
        elif yongdo == '주상복합(상가)':
            return '/html/body/section/div[1]/div[3]/form/div[1]/table/tbody[5]/tr[4]/td[2]/ul/li[9]/label/span'
        elif yongdo == '공장':
            return '/html/body/section/div[1]/div[3]/form/div[1]/table/tbody[5]/tr[5]/td[2]/ul/li[1]/label/span'
        elif yongdo == '공장용지':
            return '/html/body/section/div[1]/div[3]/form/div[1]/table/tbody[5]/tr[5]/td[2]/ul/li[2]/label/span'
        elif yongdo == '아파트형공장':
            return '/html/body/section/div[1]/div[3]/form/div[1]/table/tbody[5]/tr[5]/td[2]/ul/li[3]/label/span'
        elif yongdo == '노유자시설':
            return '/html/body/section/div[1]/div[3]/form/div[1]/table/tbody[5]/tr[6]/td[2]/ul/li[6]/label/span'
        elif yongdo == '숙박시설':
            return '/html/body/section/div[1]/div[3]/form/div[1]/table/tbody[5]/tr[6]/td[2]/ul/li[14]/label/span'
        elif yongdo == '과수원':
            return '/html/body/section/div[1]/div[3]/form/div[1]/table/tbody[5]/tr[7]/td[2]/ul/li[1]/label/span'
        elif yongdo == '답':
            return '/html/body/section/div[1]/div[3]/form/div[1]/table/tbody[5]/tr[7]/td[2]/ul/li[2]/label/span'
        elif yongdo == '대지':
            return '/html/body/section/div[1]/div[3]/form/div[1]/table/tbody[5]/tr[7]/td[2]/ul/li[3]/label/span'
        elif yongdo == '목장용지':
            return '/html/body/section/div[1]/div[3]/form/div[1]/table/tbody[5]/tr[7]/td[2]/ul/li[4]/label/span'
        elif yongdo == '임야':
            return '/html/body/section/div[1]/div[3]/form/div[1]/table/tbody[5]/tr[7]/td[2]/ul/li[5]/label/span'
        elif yongdo == '잡종지':
            return '/html/body/section/div[1]/div[3]/form/div[1]/table/tbody[5]/tr[7]/td[2]/ul/li[6]/label/span'
        elif yongdo == '전':
            return '/html/body/section/div[1]/div[3]/form/div[1]/table/tbody[5]/tr[7]/td[2]/ul/li[7]/label/span'
        else:
            return '전체'


        pass


    def main(self, report_name, df_input):

        self.logger.debug('옵션 설정')
        chrome_options = Options()
        chrome_options.add_experimental_option("detach", False)
        # chrome_options.add_argument("headless")
        driver = webdriver.Chrome(options=chrome_options)
        driver.implicitly_wait(5)

        self.logger.debug(f'검색할 데이터(전체) : {df_input}')
        for i, row in df_input.iterrows():
            status = True  
            
            # 각 변수에 행의 값을 할당
            index_number = row['등기부등본고유번호']
            index_class = row['등기부등본구분']
            index_address = row['등기부등본주소']
            sido = row['시/도']
            sigungu = row['군/구']
            dong = row['동/읍']
            start_year = row['시작년']
            start_month = row['시작월']
            start_date = row['시작일']
            end_year = row['종료년']
            end_month =  row['종료월']
            end_date = row['종료일']
            yongdo_large = row['용도(대분류)']
            yongdo = row['용도(소분류)']
            self.yongdo = yongdo

            if status:
                self.logger.debug('페이지 열기')
                try:
                    driver.get(url='https://www.infocare.co.kr/')
                    driver.execute_script("window.location.reload();")
                    driver.maximize_window()
                    self.logger.debug('페이지 열기 성공')
                except Exception as e:
                    status = False
                    self.logger.info(f'페이지 열기 실패. {e}')

                self.logger.debug('프레임 조정')
                self.logger.debug(f'status check : {status}.')
                if status:
                    self.logger.debug('프레임 조정')
                    try:
                        frames = driver.find_elements(By.TAG_NAME, "frame")

                        for index, frame in enumerate(frames):
                            name = frame.get_attribute("name")
                            frame_id = frame.get_attribute("id")
                            self.logger.debug(f"Frame {index}: Name = {name}, ID = {frame_id}")

                        driver.switch_to.frame(driver.find_element(By.NAME, 'info_main'))
                        self.logger.debug('프레임 전환 성공')
                    except Exception as e:
                        status = False
                        self.logger.info(f'프레임 전환 실패. {e}')


                self.logger.debug('로그인 시도')
                self.logger.debug(f'status check : {status}.')
                if status:
                    self.logger.debug('로그인 시도')
                    try:
                        tools.wait_and_click(driver=driver, index='/html/body/header/div/div[1]/div/ul/li[2]/a/span[1]')
                        tools.wait_and_write(driver=driver, index='/html/body/div[5]/div/div[2]/div[2]/div/div/div/form/div[1]/input', text=self.id)
                        tools.wait_and_write(driver=driver, index='/html/body/div[5]/div/div[2]/div[2]/div/div/div/form/div[2]/input[1]', text=self.pw)
                        tools.wait_and_click(driver=driver, index='/html/body/div[5]/div/div[2]/div[2]/div/div/button[1]')
                        try:
                            # 로그인 시도 후 '기존 사용자 접속 해제' 알림 처리
                            time.sleep(1)
                            alert = driver.switch_to.alert
                            alert.accept()
                        except:
                            pass
                        self.logger.debug('로그인 성공')
                    except Exception as e:
                        self.logger.info(f'로그인 실패. 기존에 로그인이 되어있는 경우 이후 코드가 정상적으로 작동됩니다. {e}')

                self.logger.debug(f'status check : {status}.')
                if status:
                    self.logger.debug(f'페이지 탐색')
                    try:
                        time.sleep(5)
                        tools.wait_and_click(driver=driver, index='/html/body/header/div/div[3]/div[2]/ul/li[2]')
                        tools.wait_and_click(driver=driver, index='/html/body/div[1]/div/div[2]/ul[2]/li[2]/ul/li[1]/a')

                        #주소/법원
                        tools.wait_and_select(driver=driver,
                                            index='/html/body/section/div[1]/div[3]/form/div[1]/table/tbody[1]/tr/td[2]/div[1]/div[1]/select[1]',
                                            selection=sido)
                        tools.wait_and_select(driver=driver,
                                            index='/html/body/section/div[1]/div[3]/form/div[1]/table/tbody[1]/tr/td[2]/div[1]/div[1]/select[2]',
                                            selection=sigungu)
                        tools.wait_and_select(driver=driver,
                                            index='/html/body/section/div[1]/div[3]/form/div[1]/table/tbody[1]/tr/td[2]/div[1]/div[1]/select[3]',
                                            selection=dong)
                        #매각일자
                        tools.wait_and_select(driver=driver,
                                            index='/html/body/section/div[1]/div[3]/form/div[1]/table/tbody[2]/tr/td/div/div[1]/select[1]',
                                            selection=start_year)
                        tools.wait_and_select(driver=driver,
                                            index='/html/body/section/div[1]/div[3]/form/div[1]/table/tbody[2]/tr/td/div/div[1]/select[2]',
                                            selection=start_month)
                        tools.wait_and_select(driver=driver,
                                            index='/html/body/section/div[1]/div[3]/form/div[1]/table/tbody[2]/tr/td/div/div[1]/select[3]',
                                            selection=start_date)

                        tools.wait_and_select(driver=driver,
                                            index='/html/body/section/div[1]/div[3]/form/div[1]/table/tbody[2]/tr/td/div/div[2]/select[1]',
                                            selection=end_year)
                        tools.wait_and_select(driver=driver,
                                            index='/html/body/section/div[1]/div[3]/form/div[1]/table/tbody[2]/tr/td/div/div[2]/select[2]',
                                            selection=end_month)
                        tools.wait_and_select(driver=driver,
                                            index='/html/body/section/div[1]/div[3]/form/div[1]/table/tbody[2]/tr/td/div/div[2]/select[3]',
                                            selection=end_date)
                        #결과
                        tools.wait_and_select(driver=driver,
                                            index='/html/body/section/div[1]/div[3]/form/div[1]/table/tbody[3]/tr/td[1]/select',
                                            selection='낙찰')

                        #용도
                        #전체(해제)
                        tools.wait_and_click(driver=driver,
                                             index='/html/body/section/div[1]/div[3]/form/div[1]/table/tbody[5]/tr[1]/td/label/span')
                        #용도별클릭
                        if self.find_yongdo(yongdo) == '전체':
                            tools.wait_and_click(driver=driver,
                                                index='/html/body/section/div[1]/div[3]/form/div[1]/table/tbody[5]/tr[1]/td/label/span')
                        elif yongdo == '단독주택' or yongdo == '전원주택':
                            tools.wait_and_click(driver=driver, index=self.find_yongdo('단독주택'))
                            tools.wait_and_click(driver=driver, index=self.find_yongdo('전원주택'))
                        elif yongdo == '아파트' or yongdo == '주상복합(주거)':
                            tools.wait_and_click(driver=driver, index=self.find_yongdo('아파트'))
                            tools.wait_and_click(driver=driver, index=self.find_yongdo('주상복합(주거)'))
                        elif yongdo == '오피스텔' or yongdo == '오피스텔(주거)':
                            tools.wait_and_click(driver=driver, index = self.find_yongdo('오피스텔'))
                            tools.wait_and_click(driver=driver, index = self.find_yongdo('오피스텔(주거)'))
                        elif yongdo in ['근린상가', '빌딩', '사무실', '상가', '시장', '아파트상가', '오피스텔(상가)', '점포', '주상복합(상가)']:
                            tools.wait_and_click(driver=driver, index= '/html/body/section/div[1]/div[3]/form/div[1]/table/tbody[5]/tr[4]/td[1]/label/span')
                        elif yongdo == '전' or yongdo == '답':
                            tools.wait_and_click(driver=driver, index=self.find_yongdo('전'))    
                            tools.wait_and_click(driver=driver, index=self.find_yongdo('답'))    
                        elif yongdo == '대지' or yongdo == '잡종지':
                            tools.wait_and_click(driver=driver, index=self.find_yongdo('대지'))    
                            tools.wait_and_click(driver=driver, index=self.find_yongdo('잡종지'))
                        elif yongdo == 'NA(전체조회)':
                            if yongdo_large == '주택':
                                tools.wait_and_click(driver=driver, index= '/html/body/section/div[1]/div[3]/form/div[1]/table/tbody[5]/tr[2]/td[1]/label/span')
                            elif yongdo_large == '집합건물':
                                tools.wait_and_click(driver=driver, index= '/html/body/section/div[1]/div[3]/form/div[1]/table/tbody[5]/tr[3]/td[1]/label/span')
                            elif yongdo_large == '상가':
                                tools.wait_and_click(driver=driver, index= '/html/body/section/div[1]/div[3]/form/div[1]/table/tbody[5]/tr[4]/td[1]/label/span')
                            elif yongdo_large == '공장':
                                tools.wait_and_click(driver=driver, index= '/html/body/section/div[1]/div[3]/form/div[1]/table/tbody[5]/tr[5]/td[1]/label/span')
                            elif yongdo_large == '특수부동산':
                                tools.wait_and_click(driver=driver, index= '/html/body/section/div[1]/div[3]/form/div[1]/table/tbody[5]/tr[6]/td[1]/label/span')
                            elif yongdo_large == '토지':
                                tools.wait_and_click(driver=driver, index= '/html/body/section/div[1]/div[3]/form/div[1]/table/tbody[5]/tr[7]/td[1]/label/span')
                            elif yongdo_large == '기타토지':
                                tools.wait_and_click(driver=driver, index= '/html/body/section/div[1]/div[3]/form/div[1]/table/tbody[5]/tr[8]/td[1]/label/span')
                            elif yongdo_large == '차량외 기타':
                                tools.wait_and_click(driver=driver, index= '/html/body/section/div[1]/div[3]/form/div[1]/table/tbody[5]/tr[9]/td[1]/label/span')
                        else:
                            try:
                                #위 특수경우가 아닌 경우 yongdo에 따라 자기자신을 클릭
                                tools.wait_and_click(driver=driver, index=self.find_yongdo(yongdo))
                            except:
                                #사전에 정의되지 않은 용도의 경우 '전체'를 검색하도록 예외처리
                                tools.wait_and_click(driver=driver,index='/html/body/section/div[1]/div[3]/form/div[1]/table/tbody[5]/tr[1]/td/label/span')


                        #특수검색
                        #전체
                        tools.wait_and_click(driver=driver,
                                            index='/html/body/section/div[1]/div[3]/form/div[1]/table/tbody[6]/tr[1]/td/ul/li[1]/label/span')
                        #선택항목제외
                        tools.wait_and_click(driver=driver,
                                            index='/html/body/section/div[1]/div[3]/form/div[1]/table/tbody[6]/tr[1]/td/ul/li[2]/label/span')
                        
                        #농취증필여부
                        tools.wait_and_click(driver=driver,
                                            index='/html/body/section/div[1]/div[3]/form/div[1]/table/tbody[6]/tr[2]/td/ul/li[20]/label/span')
                        #재경매
                        tools.wait_and_click(driver=driver,
                                            index='/html/body/section/div[1]/div[3]/form/div[1]/table/tbody[6]/tr[2]/td/ul/li[5]/label/span')
                        
                        #사건번호검색팝업 끄기
                        try:
                            tools.wait_and_click(driver=driver, index='/html/body/div[1]/ul/li[1]/div/img')
                        except:
                            pass

                        # 검색하기 버튼 클릭
                        time.sleep(1)
                        tools.wait_and_click(driver=driver, index='/html/body/section/div[1]/div[3]/form/div[2]/a[1]')
                        tools.wait_and_select(driver=driver,
                                            index='/html/body/section/div[1]/div[4]/div/div[1]/div[2]/select',
                                            selection='50개')
                        time.sleep(3)
                        self.logger.debug('페이지 탐색 성공')
                    except Exception as e:
                        status = False
                        self.logger.info(f'페이지 탐색 실패. {e}')

                # 엑셀 파일 저장 경로를 설정합니다.
                excel_file_path = os.path.join(self.save_path, f'{sigungu}_{dong}_인포케어_통합검색_{report_name}_{yongdo}.xlsx')

                self.logger.debug(f'status check : {status}.')
                if status:
                    self.logger.debug(f'엑셀파일 작성')
                    try:
                        page_source = driver.page_source

                        # BeautifulSoup으로 HTML 파싱
                        soup = BeautifulSoup(page_source, 'html.parser')

                        # 데이터 추출 로직
                        data = []

                        # 각 'tr' 요소를 순회합니다.
                        for tr in soup.find_all('tr'):
                            row_data = {}

                            # '사건번호' 추출
                            text_p = tr.find('p', class_='text')
                            if text_p:
                                text_parts = text_p.get_text(strip=True).split('\n')
                                row_data['사건번호'] = text_parts[0] if len(text_parts) > 0 else None

                            # '용도' 추출
                            td_elements = tr.find_all('td')
                            if len(td_elements) > 2:
                                row_data['용도'] = td_elements[2].text.strip()
                            else:
                                row_data['용도'] = None

                            # '주소' 추출
                            if len(td_elements) > 3:
                                divs = td_elements[3].find_all('div')
                                if len(divs) > 1:
                                    row_data['주소'] = divs[1].text.strip()
                                else:
                                    row_data['주소'] = divs[0].text.strip()
                            else:
                                row_data['주소'] = None

                            # '경매유형' 등 추가 정보 추출
                            spans = []
                            title_info = tr.get('title')
                            if title_info:
                                soup_title = BeautifulSoup(title_info, 'html.parser')
                                spans = soup_title.find_all('span')
                                row_data['경매유형'] = spans[1].text.strip() if len(spans) > 1 else None

                            if len(spans) >= 6:
                                row_data['감정가'] = spans[4].text.split(': ')[1].replace('원', '').strip()
                                bidding_info = spans[5].text.split(': ')[1].replace('원', '').strip()
                                pattern = r"([\d,]+)\(([\d\.]+)%\)"
                                match = re.search(pattern, bidding_info)
                                if match:
                                    # Extract bidding price and bidding rate from the match object
                                    bidding_price = match.group(1).replace(',', '').strip()
                                    bidding_rate = match.group(2).strip()

                                    # Store the results in row_data
                                    row_data['낙찰가'] = bidding_price
                                    row_data['낙찰율'] = bidding_rate

                            else:
                                row_data['감정가'] = None
                                row_data['낙찰가'] = None
                                row_data['낙찰율'] = None

                            if len(spans) >= 4:
                                row_data['최초매각일'] = spans[2].text.split(': ')[1].strip()
                                row_data['최종매각일'] = spans[3].text.split(': ')[1].strip()
                            else:
                                row_data['최초매각일'] = None
                                row_data['최종매각일'] = None

                            # 데이터 리스트에 추가
                            data.append(row_data)

                        # 데이터프레임 생성
                        df = pd.DataFrame(data)
                        df = df[df['용도'].notna() & (df['용도'] != '')]

                        df['경매유형'] = df['경매유형'].apply(lambda x: str(x)[-2:] if pd.notna(x) else x)

                        # 데이터프레임에 열 추가
                        df.insert(0, '읍/면/동', dong)
                        df.insert(0, '시/군/구', sigungu)
                        df.insert(0, '시/도', sido)
                        df.insert(0, '등기부등본주소', index_address)
                        df.insert(0, '등기부등본구분', index_class) 
                        df.insert(0, '등기부등본고유번호', index_number)

                        self.logger.debug(f'df : {df}')
                        df.to_excel(excel_file_path, index=False)
                        self.logger.debug('데이터프레임 저장 완료.')
                    except Exception as e:
                        status = False
                        self.logger.info(f'엑셀파일 작성 실패. {e}')
                        columns = ['등기부등본고유번호', '등기부등본구분', '등기부등본주소', '시/도', '시/군/구', '읍/면/동', '용도', '주소','감정가', '낙찰가', '낙찰율', '최초매각일', '최종매각일', '사건번호', '경매유형']
                        data_with_vars = [[index_number, index_class, index_address, sido, sigungu, dong, '조회 내역 없음'] + [None] * (len(columns) - 7)]
                        df = pd.DataFrame(data_with_vars, columns=columns)
                        df.to_excel(excel_file_path, index=False)
                        self.logger.debug('데이터프레임 저장 완료.')
                        
                else:
                    # 실패 시 기본 데이터프레임 생성
                    columns = ['등기부등본고유번호', '등기부등본구분', '등기부등본주소', '시/도', '시/군/구', '읍/면/동', '용도', '주소','감정가', '낙찰가', '낙찰율', '최초매각일', '최종매각일', '사건번호', '경매유형']
                    data_with_vars = [[index_number, index_class, index_address, sido, sigungu, dong, '조회 내역 없음'] + [None] * (len(columns) - 7)]
                    df = pd.DataFrame(data_with_vars, columns=columns)
                    df.to_excel(excel_file_path, index=False)
                    self.logger.debug('데이터프레임 저장 완료.')

        tools.wait_and_click(driver=driver, index='/html/body/header/div/div[1]/div/ul/li[2]/a/span[2]')
        driver.minimize_window()
        time.sleep(5)
        driver.quit()
    
    def run_app(self, filepath):
        #B6부터 시작하는 표를 dataframe으로 import
        df = pd.read_excel(filepath, sheet_name='Input_인포통합', engine='openpyxl', header=5)
        df = df.iloc[:, 1:]
        report_name = self.get_report_name(filepath)
        #각 행을 순환하며 main() 실행        
        self.main(report_name, df)
        self.merge_excel(report_name)
        self.logger.critical('모든 작업이 완료되었습니다.')

if __name__ == '__main__':
    # data = {
    #     'index_number' : ['111', '222', '333'],
    #     'index_address' : ['주소1', '주소2', '주소3'],
    #     'sido': ['뚱땡보', '서울', '서울'],
    #     'sigungu': ['강남구', '강남구', '강남구'],
    #     'dong': ['개포동', '논현동', '대치동'],
    #     'start_year': ['2022년', '2022년', '2022년'],
    #     'start_month': ['7월', '7월', '7월'],
    #     'start_date': ['1일', '1일', '1일'],
    #     'end_year': ['2023년', '2023년', '2023년'],
    #     'end_month': ['8월', '8월', '8월'],
    #     'end_date': ['31일', '31일', '31일']
    # }
    # df = pd.DataFrame(data)
    # run_app(df)

    filepath = r'Smart_NPL.xlsm'
    inforcare_integrated().run_app(filepath)    