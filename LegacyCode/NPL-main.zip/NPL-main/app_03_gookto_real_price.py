import os
import sys
import subprocess
import pandas as pd
import xml.etree.ElementTree as ET
import requests
import re
from datetime import datetime, timedelta
import logging

# Kakao API 호출 함수
def call_kakao_api(address_name, kakao_api_key):
    url = "https://dapi.kakao.com/v2/local/search/address.json"
    headers = {"Authorization": f"KakaoAK {kakao_api_key}"}
    params = {"query": address_name, "size": "30"}
    try:
        response_kakao = requests.get(url, headers=headers, params=params)
        response_kakao.raise_for_status()
        data = response_kakao.json()
        return data
    except requests.exceptions.RequestException as e:
        logging.error(f"API 호출에 실패했습니다: {e}")
        return {"error": "API 호출에 실패했습니다. 입력값을 확인해주세요"}

# Data API 호출 함수 (아파트)
def get_data_apt(gu_code, base_date, data_apikey, page_no=1, num_of_rows=10000):
    url = (
        f"https://apis.data.go.kr/1613000/RTMSDataSvcAptTrade/getRTMSDataSvcAptTrade"
        f"?LAWD_CD={gu_code}&DEAL_YMD={base_date}&serviceKey={data_apikey}"
        f"&pageNo={page_no}&numOfRows={num_of_rows}"
    )
    curl_command = (
        f'curl -k -A '
        f'"Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) '
        f'Chrome/58.0.3029.110 Safari/537.36" "{url}"'
    )
    logging.info(f"Request URL: {url}")

    try:
        result = subprocess.run(curl_command, shell=True, stdout=subprocess.PIPE, stderr=subprocess.PIPE)
        response = result.stdout.decode('utf-8', errors='ignore')
        return response
    except Exception as e:
        logging.error(f"Error fetching data for {base_date}: {e}")
        return None

# Data API 호출 함수 (오피스텔)
def get_data_office(gu_code, base_date, data_apikey, page_no=1, num_of_rows=10000):
    url = (
        f"https://apis.data.go.kr/1613000/RTMSDataSvcOffiTrade/getRTMSDataSvcOffiTrade"
        f"?serviceKey={data_apikey}&LAWD_CD={gu_code}&DEAL_YMD={base_date}"
        f"&pageNo={page_no}&numOfRows={num_of_rows}"
    )
    curl_command = (
        f'curl -k -A '
        f'"Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) '
        f'Chrome/58.0.3029.110 Safari/537.36" "{url}"'
    )
    logging.info(f"Request URL: {url}")

    try:
        result = subprocess.run(curl_command, shell=True, stdout=subprocess.PIPE, stderr=subprocess.PIPE)
        response = result.stdout.decode('utf-8', errors='ignore')
        return response
    except Exception as e:
        logging.error(f"Error fetching data for {base_date}: {e}")
        return None

# Data API 호출 함수 (연립/다세대)
def get_data_multi(gu_code, base_date, data_apikey, page_no=1, num_of_rows=10000):
    url = (
        f"https://apis.data.go.kr/1613000/RTMSDataSvcRHTrade/getRTMSDataSvcRHTrade"
        f"?serviceKey={data_apikey}&LAWD_CD={gu_code}&DEAL_YMD={base_date}"
        f"&pageNo={page_no}&numOfRows={num_of_rows}"
    )
    curl_command = (
        f'curl -k -A '
        f'"Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) '
        f'Chrome/58.0.3029.110 Safari/537.36" "{url}"'
    )
    logging.info(f"Request URL: {url}")

    try:
        result = subprocess.run(curl_command, shell=True, stdout=subprocess.PIPE, stderr=subprocess.PIPE)
        response = result.stdout.decode('utf-8', errors='ignore')
        return response
    except Exception as e:
        logging.error(f"Error fetching data for {base_date}: {e}")
        return None

# XML 응답 파싱 함수
def parse_response(response_content):
    try:
        root = ET.fromstring(response_content)

        # 'header' 요소가 존재하는지 확인
        header = root.find('header')
        if header is None:
            logging.warning("No header found in the response.")
            return pd.DataFrame()

        result_code = header.find('resultCode').text
        result_msg = header.find('resultMsg').text

        # 성공 코드를 리스트로 정의
        success_codes = ["00", "000", "0000"]

        if result_code not in success_codes:
            logging.error(f"API request failed: {result_msg} (Code: {result_code})")
            return pd.DataFrame()

        items = root.find('body').find('items')
        if items is None or len(items) == 0:
            logging.warning("No items found in the response.")
            return pd.DataFrame()

        item_list = []
        for item in items.findall('item'):
            data = {elem.tag: (elem.text if elem.text is not None else "") for elem in item}
            item_list.append(data)

        return pd.DataFrame(item_list) if item_list else pd.DataFrame()

    except ET.ParseError as e:
        logging.error(f"Error parsing XML: {e}")
        return pd.DataFrame()

# 파일명에 사용할 문자열을 안전하게 만드는 함수
def sanitize_filename(filename):
    return re.sub(r'[\\/*?:"<>|]', "_", filename)

# 엑셀으로 데이터 저장 함수
def export_to_excel(df, file_path):
    if df.empty:
        logging.warning("No data available to export.")
        return

    try:
        with pd.ExcelWriter(file_path, engine='xlsxwriter') as writer:
            df.to_excel(writer, index=False, sheet_name='Sheet1')
            workbook  = writer.book
            worksheet = writer.sheets['Sheet1']
            (max_row, max_col) = df.shape
            if max_row > 0 and max_col > 0:
                column_settings = [{'header': column} for column in df.columns]
                worksheet.add_table(0, 0, max_row, max_col - 1, {'columns': column_settings, 'name': 'Table1'})

        logging.info(f"Data has been saved as an Excel file: {file_path}")
    except Exception as e:
        logging.error(f"Error saving Excel file: {e}")

# 조회 기간 리스트 생성 함수
def generate_base_date_list(start_year, start_month, end_year, end_month):
    start_date = datetime.strptime(f"{start_year}-{start_month}", "%Y-%m")
    end_date = datetime.strptime(f"{end_year}-{end_month}", "%Y-%m")
    base_date_list = []
    current_date = start_date
    while current_date <= end_date:
        base_date_list.append(current_date.strftime("%Y%m"))
        # 다음 달의 첫 번째 날로 이동
        next_month = current_date.replace(day=28) + timedelta(days=4)
        current_date = next_month - timedelta(days=next_month.day - 1)
    return base_date_list

# Kakao API 정보 추가 함수
def append_kakao_info(input_df, kakao_api_key):
    gu_codes = []
    x_coords = []
    y_coords = []
    for index, row in input_df.iterrows():
        address_name = row['등기부등본주소']
        try:
            kakao_data = call_kakao_api(address_name, kakao_api_key)
            if 'documents' in kakao_data and len(kakao_data['documents']) > 0:
                address_info = kakao_data['documents'][0]['address']
                b_code = address_info['b_code'][:5] if 'b_code' in address_info else ''
                x = kakao_data['documents'][0]['x']
                y = kakao_data['documents'][0]['y']
            else:
                b_code = ''
                x = ''
                y = ''
        except Exception as e:
            logging.error(f"Error fetching Kakao API data for {address_name}: {e}")
            b_code = ''
            x = ''
            y = ''
        gu_codes.append(b_code)
        x_coords.append(x)
        y_coords.append(y)
    input_df['gu_code'] = gu_codes
    input_df['x'] = x_coords
    input_df['y'] = y_coords
    return input_df

# 실거래가 데이터 처리 함수
def process_real_estate_data(input_df, temp_folder, data_apikey):
    os.makedirs(temp_folder, exist_ok=True)
    for index, row in input_df.iterrows():
        gu_code = row['gu_code']
        address_name = row['등기부등본주소']
        real_estate_type = row['실거래가_구분']
        query_period = row['실거래가_조회기간(2)']
        start_date_str, end_date_str = query_period.split('~')
        start_year = start_date_str[:4]
        start_month = start_date_str[5:7]
        end_year = end_date_str[:4]
        end_month = end_date_str[5:7]
        unique_id = row['등기부등본고유번호']
        x = row['x']
        y = row['y']

        # 파일명 생성 및 폴더 경로 설정
        sanitized_real_estate_type = sanitize_filename(real_estate_type)
        sanitized_address_name = sanitize_filename(address_name)
        file_name = f"{sanitized_real_estate_type}_{sanitized_address_name}_{start_year}-{start_month}~{end_year}-{end_month}.xlsx"
        file_path = os.path.join(temp_folder, file_name)

        if os.path.exists(file_path):
            logging.info(f"File already exists: {file_path}")
            continue  # 다음 행으로 이동

        # 데이터 수집
        items_list = []
        base_date_list = generate_base_date_list(start_year, start_month, end_year, end_month)
        for base_date in base_date_list:
            if real_estate_type == '아파트':
                response_content = get_data_apt(gu_code, base_date, data_apikey)
            elif real_estate_type == '오피스텔':
                response_content = get_data_office(gu_code, base_date, data_apikey)
            elif real_estate_type == '연립/다세대':
                response_content = get_data_multi(gu_code, base_date, data_apikey)
            else:
                logging.warning(f"Unknown real estate type: {real_estate_type}")
                continue  # 이 유형은 스킵

            if response_content is not None:
                df_response = parse_response(response_content)
                if not df_response.empty:
                    items_list.append(df_response)

        if items_list:
            items_df = pd.concat(items_list, ignore_index=True, sort=False)
            # 필요한 컬럼 추가
            if 'houseType' not in items_df.columns:
                items_df['houseType'] = ''
            if 'aptDong' not in items_df.columns:
                items_df['aptDong'] = ''
            # 입력 데이터에서 컬럼 추가
            items_df['등기부등본고유번호'] = unique_id
            items_df['등기부등본구분'] = row.get('등기부등본구분', '')
            items_df['등기부등본주소'] = address_name
            items_df['실거래가_구분'] = real_estate_type
            items_df['실거래가_조회기간(2)'] = query_period
            items_df['x'] = x
            items_df['y'] = y
            items_df['도/시'] = row.get('도/시', '')
            items_df['군/구'] = row.get('군/구', '')
            # 엑셀로 저장
            export_to_excel(items_df, file_path)
        else:
            logging.warning(f"No data to process for {address_name} in period {query_period}")

    return temp_folder  # 중간 산출물이 저장된 폴더 경로를 반환

# 중간 산출물 병합 및 정리 함수
def merge_and_cleanup_excel_files(temp_folder):
    # 중간 산출물이 존재하는 폴더의 엑셀 파일 목록 가져오기
    # Exclude files that start with 'Output'
    excel_files = [
        os.path.join(temp_folder, f) 
        for f in os.listdir(temp_folder) 
        if f.endswith('.xlsx') and not f.startswith('Output')
    ]

    if not excel_files:
        logging.warning("No intermediate files to process.")
        return

    # 모든 엑셀 파일을 읽어서 데이터프레임으로 저장
    dataframes = []
    for file in excel_files:
        try:
            df = pd.read_excel(file)
            dataframes.append(df)
        except Exception as e:
            logging.error(f"Error reading {file}: {e}")

    # 데이터프레임 병합
    merged_df = pd.concat(dataframes, ignore_index=True, sort=False)

    columns_to_drop = [
        'cdealDay', 'cdealType', 'rgstDate', 
        'landLeaseholdGbn', 'estateAgentSggNm', 
        'sggNm', 'landAr', 'slerGbn'
    ]
    merged_df = merged_df.drop(columns=[col for col in columns_to_drop if col in merged_df.columns])

    # 2. 'aptNm', 'mhouseNm', 'offiNm'을 '건물이름'으로 병합
    building_columns = ['aptNm', 'mhouseNm', 'offiNm']
    existing_building_cols = [col for col in building_columns if col in merged_df.columns]
    
    if existing_building_cols:
        # Concatenate the building name columns with a space separator and remove any extra spaces
        merged_df['건물이름'] = merged_df[existing_building_cols].apply(
            lambda x: ' '.join(x.dropna().astype(str)), axis=1
        ).str.strip()
        
        # Drop the original building name columns
        merged_df = merged_df.drop(columns=existing_building_cols)
    else:
        logging.warning("No building name columns found to merge.")

    # 3. 컬럼 순서 변경
    desired_order = [
        '등기부등본고유번호', '등기부등본구분', '등기부등본주소', 
        'x', 'y', '실거래가_조회기간(2)', '실거래가_구분', 
        'houseType', '도/시', '군/구', 'umdNm', 'jibun', '건물이름', 'aptDong', 
        'dealAmount', 'dealYear', 'dealMonth', 'dealDay', 
        'excluUseAr', 'floor']

    # 거래금액 만원 -> 원 단위로 변경
    if 'dealAmount' in merged_df.columns:
        # 문자열로 변환 후 쉼표와 양쪽 공백 제거
        merged_df['dealAmount'] = merged_df['dealAmount'].astype(str).str.replace(',', '').str.strip()
        # 숫자로 변환 후 10000을 곱함
        merged_df['dealAmount'] = pd.to_numeric(merged_df['dealAmount'], errors='coerce') * 10000
    
    remaining_columns = [col for col in merged_df.columns if col not in desired_order]
    merged_df = merged_df[desired_order + remaining_columns]

    # 중간 산출물 삭제
    for file in excel_files:
        try:
            os.remove(file)
            logging.info(f"Deleted intermediate file: {file}")
        except Exception as e:
            logging.error(f"Error deleting {file}: {e}")

    report_folder_path = os.path.abspath(os.path.join(temp_folder, os.pardir, os.pardir))
    report_name = os.path.basename(report_folder_path.rstrip(os.sep))
    temp_output_file = os.path.join(temp_folder, f'Temp_Output_국토교통부_실거래가조회_{report_name}.xlsx')
    final_output_file = os.path.join(temp_folder, f'Output_국토교통부_실거래가조회_{report_name}.xlsx')

    # 병합된 엑셀 파일 저장 (임시 파일명으로)
    try:
        with pd.ExcelWriter(temp_output_file, engine='xlsxwriter') as writer:
            merged_df.to_excel(writer, sheet_name='Output_실거래가_국토', index=False)
        logging.info(f"Temporary merged data has been saved as an Excel file: {temp_output_file}")
    except Exception as e:
        logging.error(f"Error saving temporary merged Excel file: {e}")
        return

    # 파일 저장 완료 후 파일명 변경
    try:
        os.rename(temp_output_file, final_output_file)
        logging.info(f"File renamed to: {final_output_file}")
    except Exception as e:
        logging.error(f"Error renaming file {temp_output_file} to {final_output_file}: {e}")


# 엑셀 파일에서 소스 정보 로드
def load_api_key_and_paths_from_excel(excel_path):
    excel_full_path = os.path.abspath(excel_path)
    if not os.path.exists(excel_full_path):
        logging.error(f"Excel file not found: {excel_full_path}")
        raise FileNotFoundError(f"Excel file not found: {excel_full_path}")
    df = pd.read_excel(excel_full_path, sheet_name='Source', engine='openpyxl')
    report_folder_path = df.loc[df.iloc[:, 0] == '보고서폴더경로', df.columns[1]].values[0]
    kakao_api_key = df.loc[df.iloc[:, 0] == 'kakao_apikey', df.columns[1]].values[0]
    data_apikey = df.loc[df.iloc[:, 0] == 'data_apikey', df.columns[1]].values[0]
    return report_folder_path, kakao_api_key, data_apikey

# 엑셀 파일에서 입력 데이터 로드
def load_input_data_from_excel(excel_path):
    excel_full_path = os.path.abspath(excel_path)
    if not os.path.exists(excel_full_path):
        logging.error(f"Excel file not found: {excel_full_path}")
        raise FileNotFoundError(f"Excel file not found: {excel_full_path}")
    df = pd.read_excel(excel_full_path, sheet_name='Input_실거래가', header=5)
    df.columns = df.columns.str.strip()
    # '조회실행여부'가 비어있지 않은 행만 유지
    df = df[df['조회실행여부'].notna()]
    # '조회방법'이 '밸류맵'이 아닌 행만 유지
    df = df[df['조회방법'] != '밸류맵']
    # 필요 없는 컬럼 삭제
    df = df.drop(columns=['법정동', '동', '조회실행여부', '조회방법'], errors='ignore')
    return df

# 전체 프로세스를 실행하는 메인 함수
def run_gookto_real_price(excel_path="Smart_NPL.xlsm"):
    # 1. 엑셀 파일에서 소스 정보 로드
    report_folder_path, kakao_api_key, data_apikey = load_api_key_and_paths_from_excel(excel_path)

    # 2. 실거래가 조회 결과를 저장할 temp_folder 설정
    temp_folder = os.path.join(report_folder_path, 'Temp', '실거래가조회_국토교통부')
    os.makedirs(temp_folder, exist_ok=True)

    # 3. 로깅 설정
    timestamp = datetime.now().strftime('%y%m%d_%H%M%S')
    log_file_path = os.path.join(temp_folder, f'gookto_real_price_{timestamp}.log')

    # 로그 디렉터리 생성
    os.makedirs(os.path.dirname(log_file_path), exist_ok=True)

    # 로깅 설정
    logging.basicConfig(
        level=logging.INFO,
        format='%(asctime)s %(levelname)s:%(message)s',
        datefmt='%Y-%m-%d %H:%M:%S',
        handlers=[
            logging.FileHandler(log_file_path, encoding='utf-8'),
            logging.StreamHandler()
        ]
    )

    logging.info("Starting run_gookto_real_price")

    # 4. 엑셀 파일에서 입력 데이터 로드
    input_df = load_input_data_from_excel(excel_path)
    logging.info("입력 데이터를 불러왔습니다.")

    # 5. Kakao API 정보를 추가하여 데이터프레임 업데이트
    input_df = append_kakao_info(input_df, kakao_api_key)
    logging.info("Kakao API 정보를 데이터프레임에 추가했습니다.")

    # 6. 실거래가 데이터 처리 및 엑셀 저장
    temp_folder = process_real_estate_data(input_df, temp_folder, data_apikey)
    logging.info("실거래가 데이터를 처리하고 Excel 파일을 저장했습니다.")

    # 7. 중간 산출물 병합 및 정리
    merge_and_cleanup_excel_files(temp_folder)
    logging.info("중간 산출물을 병합하고 정리했습니다.")

    logging.info("run_gookto_real_price completed successfully.")

# main.py에서 import하여 실행할 수 있도록 함수만 남김
if __name__ == "__main__":
    excel_path = "Smart_NPL.xlsm"
    run_gookto_real_price(excel_path)
