from selenium import webdriver
from selenium.webdriver.chrome.options import Options
from selenium.webdriver.common.by import By
from logger import Logger
import tools as tools
import pandas as pd
import openpyxl
from openpyxl import load_workbook
from openpyxl.styles import Font, Border, PatternFill, Alignment
import glob
import os
import sys
import time

class court_auction():
    def __init__(self) -> None:

        # 실행 파일의 위치 설정
        if getattr(sys, 'frozen', False):
            # PyInstaller로 빌드된 실행 파일인 경우
            exe_dir = os.path.dirname(sys.executable)
        else:
            # 스크립트로 실행되는 경우
            exe_dir = os.path.dirname(os.path.abspath(__file__))

        # 엑셀 파일의 위치
        self.npl_file_path = os.path.join(exe_dir, 'Smart_NPL.xlsm')

        # report_name 선언
        self.report_name = self.get_report_name(self.npl_file_path)

        # 엑셀 파일에서 B3 셀의 경로를 가져옴
        source_path = self.get_excel_path(self.npl_file_path, 'Source', 'B4')

        # 폴더 경로 설정
        self.save_path = os.path.join(source_path, 'Temp', '법원경매')

        self.logger = Logger(save_path=self.save_path, function_name='법원경매').get_logger()

        self.logger.debug(f'파일 저장 폴더 : {self.save_path}')
        self.logger.debug(f'Smart_NPL file_path : {self.npl_file_path}')      
        self.logger.debug(f'report name : {self.report_name}')  


        #폴더가 없는 경우 폴더 생성
        if not os.path.exists(self.save_path):
            self.logger.debug('파일 저장 경로 폴더 생성')
            os.makedirs(self.save_path)
        else:
            self.logger.debug('파일 저장 경로 존재')

            # 폴더 내 파일 삭제
            for filename in os.listdir(self.save_path):
                file_path = os.path.join(self.save_path, filename)
                try:
                    if os.path.isfile(file_path):  # 파일인지 확인
                        os.remove(file_path)
                        self.logger.debug(f'파일 삭제: {file_path}')
                except Exception as e:
                    self.logger.error(f'파일 삭제 중 오류 발생: {file_path}, {e}')
                    
    def get_excel_path(self, file_path, sheet_name, cell):
        """엑셀 파일에서 지정한 시트와 셀의 값을 가져옴"""
        try:
            # 엑셀 파일을 불러오기
            workbook = load_workbook(file_path, data_only=True)
            sheet = workbook[sheet_name]
            
            # 셀의 값을 읽어옴
            path_value = sheet[cell].value
            
            return path_value
        except Exception as e:
            return None

    def append_tables_with_headers(self, file_path, table1, table2, table3):
        # 테이블 리스트를 생성
        tables = [table1, table2, table3]
        
        # 엑셀 파일 불러오기
        workbook = load_workbook(file_path)
        sheet = workbook.active

        # # 기존 데이터의 마지막 행 찾기
        # start_row = sheet.max_row + 1

        # 각 테이블에 대해 헤더를 포함한 데이터를 추가
        for table in tables:
            # 테이블 헤더를 추가
            headers = table.columns.tolist()
            sheet.append(headers)

            # 테이블 데이터 추가
            for row in table.itertuples(index=False, name=None):
                # 각 행을 추가
                sheet.append(row)

        # 엑셀 저장
        workbook.save(file_path)

    def parse_table(self, driver, table_xpath):
        try:
            # 테이블을 가져오기
            table_element = driver.find_elements(By.XPATH, table_xpath)
            rows = table_element.find_elements(By.TAG_NAME, "tr")
            
            # 헤더 추출 및 빈 칸 처리
            headers = []
            for th in rows[0].find_elements(By.TAG_NAME,"th"):
                header_text = th.text.strip()
                if not header_text:  # 빈 헤더 처리
                    header_text = f"Unnamed_{len(headers)}"
                headers.append(header_text)
            
            # 데이터 추출
            data = []
            for row in rows[1:]:
                row_data = [td.text for td in row.find_elements(By.TAG_NAME, "td")]
                data.append(row_data)
            
            # DataFrame 생성
            table = pd.DataFrame(data, columns=headers)
            return table

        except Exception as e:
            # 모든 열에 "조회 내역이 없습니다." 추가
            table = pd.DataFrame([["조회 내역이 없습니다."] * len(headers)], columns=headers)
            return table

    def get_report_name(self, file_path):
        # 엑셀 파일 열기
        workbook = openpyxl.load_workbook(file_path)

        # source 시트 선택
        sheet = workbook['Source']
        
        # 'A'열을 순회하면서 '보고서명'을 찾고 해당 행의 'B'열 값을 가져옴
        for row in sheet.iter_rows(min_row=1, max_col=2):  # 'A'열과 'B'열만 확인
            if row[0].value == '보고서명':  # 'A'열 값이 '보고서명'이면
                report_name = row[1].value  # 'B'열 값 가져오기
                return report_name

        return None  # '보고서명'을 찾지 못했을 때 None 반환

    def get_path(self, file_path):
        # 엑셀 파일 열기
        workbook = openpyxl.load_workbook(file_path)

        # source 시트 선택
        sheet = workbook['Source']
        
        # 'A'열을 순회하면서 '보고서명'을 찾고 해당 행의 'B'열 값을 가져옴
        for row in sheet.iter_rows(min_row=1, max_col=2):  # 'A'열과 'B'열만 확인
            if row[0].value == '보고서폴더경로':  # 'A'열 값이 '보고서명'이면
                b_value = row[1].value  # 'B'열 값 가져오기
                return b_value

        return None  # '보고서명'을 찾지 못했을 때 None 반환

    def excel_detail(self, temp_output_excel, output_excel):
        wb = openpyxl.load_workbook(temp_output_excel)
        ws = wb.active  # 첫 번째 시트 활성화
        
        # # D열이 '물건번호'인 경우 해당 셀과 아래 셀을 삭제하고 오른쪽의 데이터를 왼쪽으로 이동함
        # for row in ws.iter_rows(min_row=1, max_col=4):  # D열만 탐색
        #     if row[3].value == '물건번호':  # D열의 값이 '물건번호'인 셀 찾기
        #         header_row = row[0].row  # '물건번호' 셀이 있는 행 번호
                
        #         # '물건번호' 셀과 바로 아래 셀을 삭제
        #         ws.cell(row=header_row, column=4).value = None  # '물건번호' 셀 삭제
        #         ws.cell(row=header_row + 1, column=4).value = None  # 바로 아래 셀 삭제
                
        #         # 삭제 후 오른쪽 데이터를 왼쪽으로 당기기
        #         for col in range(5, ws.max_column + 1):  # 5번째 열부터 마지막 열까지
        #             for r in range(header_row, header_row + 2):  # '물건번호' 셀과 바로 아래 셀에 대해서
        #                 ws.cell(row=r, column=col-1).value = ws.cell(row=r, column=col).value  # 한 칸씩 왼쪽으로 이동
        #                 ws.cell(row=r, column=col).value = None  # 원래 위치의 데이터 삭제

        # # D열이 '감정평가액'인 경우 해당 셀과 아래 셀을 삭제하고 오른쪽의 데이터를 왼쪽으로 이동함
        # for row in ws.iter_rows(min_row=1, max_col=4):  # D열만 탐색
        #     if row[3].value == '감정평가액':  # D열의 값이 '감정평가액'인 셀 찾기
        #         header_row = row[0].row  # '감정평가액' 셀이 있는 행 번호
                
        #         # '감정평가액' 셀과 바로 아래 셀을 삭제
        #         ws.cell(row=header_row, column=4).value = None  # '감정평가액' 셀 삭제
        #         ws.cell(row=header_row + 1, column=4).value = None  # 바로 아래 셀 삭제
                
        #         # 삭제 후 오른쪽 데이터를 왼쪽으로 당기기
        #         for col in range(5, ws.max_column + 1):  # 5번째 열부터 마지막 열까지
        #             for r in range(header_row, header_row + 2):  # '감정평가액' 셀과 바로 아래 셀에 대해서
        #                 ws.cell(row=r, column=col-1).value = ws.cell(row=r, column=col).value  # 한 칸씩 왼쪽으로 이동
        #                 ws.cell(row=r, column=col).value = None  # 원래 위치의 데이터 삭제
        wb.save(output_excel)
        wb.close()


    def add_section_headers(self, auction_with_header, document_with_header, date_with_header):
        # 각 테이블에 헤더 추가
        auction_header = pd.DataFrame([['<당사자내역>'] + [''] * (len(auction_with_header.columns)-1)], columns=auction_with_header.columns)
        document_header = pd.DataFrame([['<문건/송달내역>'] + [''] * (len(document_with_header.columns)-1)], columns=document_with_header.columns)
        date_header = pd.DataFrame([['<기일내역>'] + [''] * (len(date_with_header.columns)-1)], columns=date_with_header.columns)
        auction_with_section = pd.concat([auction_header, auction_with_header], ignore_index=True)
        document_with_section = pd.concat([document_header, document_with_header], ignore_index=True)
        date_with_section = pd.concat([date_header, date_with_header], ignore_index=True)
        extracted_tables = pd.concat([auction_with_section, document_with_section, date_with_section], ignore_index=True)
        
        return extracted_tables

    def merge_excel(self, report_name):

        self.logger.debug('파일병합을 시도합니다.')

        # 엑셀 파일이 있는 디렉토리를 현재 디렉토리로 설정
        directory = self.save_path  # 현재 파이썬 파일과 동일 경로

        # 파일명 뒷부분이 '법원경매정보조회_{report_name}.xlsx'로 끝나는 모든 파일을 찾습니다.
        file_pattern = os.path.join(directory, f'*법원경매정보조회_{report_name}.xlsx')
        files = glob.glob(file_pattern)
        self.logger.debug(f'files : {files}')
        # 각 파일의 데이터를 읽어들이고 데이터프레임으로 통합합니다.
        dataframes = []
        header = ['등기부등본고유번호','등기부등본구분', '등기부등본주소','경매번호', '사건번호', '내용1', '내용2', '내용3', '내용4', '내용5']

        for file in files:
            df = pd.read_excel(file, header=None)  # 헤더가 없기 때문에 header=None
            df = df.reindex(columns=range(len(header)))
            df.columns = header  # 헤더 설정
            
            # 리스트에 추가
            dataframes.append(df)

        combined_df = pd.concat(dataframes, ignore_index=True)

        self.logger.debug(combined_df)

        for file in files:
            try:
                os.remove(file)
                print(f"Deleted: {file}")
            except OSError as e:
                print(f"Error deleting {file}: {e}")

        temp_output_excel = os.path.join(directory, f'temp_Output_법원경매_{report_name}.xlsx')
        output_excel = os.path.join(directory, f'Output_법원경매_{report_name}.xlsx')
        combined_df.to_excel(temp_output_excel, sheet_name='Output_법원경매', index=False)
        self.excel_detail(temp_output_excel, output_excel)


        try:
            os.remove(temp_output_excel)
            print(f"Deleted: {temp_output_excel}")
        except OSError as e:
            print(f"Error deleting {temp_output_excel}: {e}")

        self.logger.debug('파일 병합 작업이 완료되었습니다.')

    def export_error(self, index_number, index_class, index_address, court_name, year, court_number, report_name):
        columns = ['등기부등본고유번호', '등기부등본구분', '등기부등본주소', '경매번호', '사건번호', '내용1', '내용2', '내용3', '내용4', '내용5']
        data_with_vars = [[index_number, index_class, index_address, f'{court_name}_{year}-{court_number}', '조회 내역 없음'] + [None] * (len(columns) - 5)]
        df = pd.DataFrame(data_with_vars, columns=columns)

        # 파일명에 index_number 사용
        excel_path = os.path.join(self.save_path, f'{index_number}_법원경매정보조회_{report_name}.xlsx')
        df.to_excel(excel_path, header=None, index=False)



    def main(self, report_name, df_input):

        status = True
        failType = ""

        self.logger.debug(f'status check : {status}.')
        self.logger.debug('option setting')
        chrome_options = Options()
        chrome_options.add_experimental_option("detach", True)

        driver = webdriver.Chrome(options=chrome_options)
        driver.implicitly_wait(5)


        self.logger.debug(f'status check : {status}.')
        if status:
            self.logger.debug(f'검색할 데이터(전체) : {df_input}')
            for i, row in df_input.iterrows():
                status = True  
                # 각 변수에 행의 값을 할당
                index_number = row['등기부등본고유번호']
                index_class = row['등기부등본구분']
                index_address = row['등기부등본주소']
                court_name = row['법원정보']
                year = row['경매연도']
                court_number = row['경매번호']

                court_full_name = f'{court_name}_{year}타경{court_number}'
                self.logger.debug(f'검색할 사건번호 : {court_full_name}')
                
                self.logger.debug(f'report name : {report_name}, index class : {index_class}, index number : {index_number}')

                self.logger.info(f'검색 시작 : {i}/{str(len(df_input)-1)}')
                self.logger.debug(f'검색할 주소 : {index_address}')
                try:
                    # 사이트 오픈
                    self.logger.debug('open page')
                    driver.get(url='https://www.courtauction.go.kr/')
                    try:
                        driver.maximize_window()
                    except:
                        pass
                    # 'src' 속성을 기준으로 프레임 찾기
                    frames = driver.find_elements(By.TAG_NAME, 'iframe')
                    for frame in frames:
                        if 'desired_src_value' in frame.get_attribute('src'):
                            driver.switch_to.frame(frame)
                            break  
                    # # 프레임 조정
                    # self.logger.debug('프레임을 조정합니다.')
                    # driver.switch_to.frame(0)

                except Exception as e:
                    self.logger.info(f'프레임 조정에 실패 : {e}')
                    failType = "웹페이지 열기 실패"
                    status = False
                    self.export_error(index_number, index_class, index_address, court_name, year, court_number, report_name)

                self.logger.debug(f'status check : {status}.')
                if status:
                    try:
                        self.logger.debug('탐색을 시작합니다.')

                        #물건상세검색색 클릭
                        tools.wait_and_click(driver=driver, index='/html/body/div/div[4]/div/a[1]')

                        #경매사건검색 클릭
                        tools.wait_and_click(driver=driver, index='/html/body/div/div[2]/div/div/div[1]/ul/li[9]/a')

                        #법원
                        tools.wait_and_select(driver=driver, index='/html/body/div/div[2]/div/div/div[2]/div[2]/div[1]/table/tbody/tr/td[1]/select', selection=court_name)
                        
                        #연도
                        tools.wait_and_select(driver=driver, index='/html/body/div/div[2]/div/div/div[2]/div[2]/div[1]/table/tbody/tr/td[2]/select', selection=str(year))
                        
                        #사건번호
                        tools.wait_and_write(driver=driver, index='/html/body/div/div[2]/div/div/div[2]/div[2]/div[1]/table/tbody/tr/td[2]/input', text=str(court_number))
                        
                        #검색
                        tools.wait_and_click(driver=driver, index='/html/body/div/div[2]/div/div/div[2]/div[2]/div[2]/input')

                    except Exception as e:
                        status = False
                        failType = "페이지 탐색 실패"
                        self.logger.info(f'페이지 탐색에 실패 : {e}')
                        self.export_error(index_number, index_class, index_address, court_name, year, court_number, report_name)

                self.logger.debug(f'status check : {status}.')
                if status:
                    try:
                        self.logger.debug('텍스트 정보를 추출합니다.')

                        #감정평가액 : 물건내역>감정평가액
                        try:
                            appraised_value = tools.wait_and_read(driver=driver, index='/html/body/div[1]/div[2]/div/div/div[2]/div[3]/div/div[1]/div/div[8]/div[2]/table/tbody/tr[1]/td[3]/div[1]')
                        except:
                            appraised_value = '조회 내역 없음'
                        
                        #경매개시일 : 사건기본내역>개시결정일자
                        try:
                            start_date = tools.wait_and_read(driver=driver, index='/html/body/div[1]/div[2]/div/div/div[2]/div[3]/div/div[1]/div/div[2]/table/tbody/tr[3]/td[2]/span')
                        except:
                            start_date = '조회 내역 없음'

                        #배당요구종기일 : 배당요구종기내역>배당요구종기일
                        try:
                            end_date = tools.wait_and_read(driver=driver, index='/html/body/div[1]/div[2]/div/div/div[2]/div[3]/div/div[1]/div/div[5]/div[2]/div[1]/div/table/tbody/tr/td[3]/nobr')
                        except :
                            end_date = '조회 내역 없음'

                        self.logger.debug(f'appraised_value : {appraised_value}, start_date : {start_date}, end_date : {end_date}')
                    except Exception as e:
                        status = False
                        failType = '경매기본정보가 조회되지 않음'
                        self.logger.info(f'경매기본정보 정보 추출에 실패 : {e}')
                        self.export_error(index_number, index_class, index_address, court_name, year, court_number, report_name)

                if status:
                    try:
                        self.logger.debug('사건내역 표를 추출합니다.')
                        auction_table = tools.wait_and_get_table(driver=driver, index='/html/body/div[1]/div[2]/div/div/div[2]/div[3]/div/div[1]/div/div[11]/div[2]/div[1]/div/table')
                        auction_table = auction_table.dropna(how='all')
                        auction_table.columns = ["당사자구분_1", "당사자명_1", "당사자구분_2", "당사자명_2"]

                        self.logger.debug(auction_table)
                    except Exception as e:
                        auction_table = pd.DataFrame([["조회 내역 없음"] * 4], 
                                                columns=["당사자구분_1", "당사자명_1", "당사자구분_2", "당사자명_2"])
                        self.logger.debug(auction_table)  

                self.logger.debug(f'status check : {status}.')

                if status:
                    self.logger.debug('문건처리내역 표를 추출합니다.')
                    #문건/송달내역 클릭
                    time.sleep(3)
                    tools.wait_and_click(driver=driver, index='/html/body/div[1]/div[2]/div/div/div[2]/div[3]/ul/li[3]/div[1]/a')

                    #테이블 추출
                    try:
                        time.sleep(2)
                        document_table = tools.wait_and_get_table(driver=driver, index='/html/body/div[1]/div[2]/div/div/div[2]/div[3]/div/div[3]/div/div/div[1]/div[4]/div[1]/div/table')
                        document_table = document_table.dropna(how='all')
                        document_table.columns = ["접수일", "접수내역", "결과"]
                        self.logger.debug(document_table)
                    except:
                        document_table = pd.DataFrame([["조회 내역 없음"] * 3], 
                                                columns=["접수일", "접수내역", "결과"])
                        self.logger.debug(document_table)

                if status:
                    try:
                        self.logger.debug('기일내역 표를 추출합니다.')
                        #기일내역 클릭
                        time.sleep(3)
                        tools.wait_and_click(driver=driver, index='/html/body/div[1]/div[2]/div/div/div[2]/div[3]/ul/li[2]/div[1]/a')
                        
                        #테이블 파싱
                        try:
                            time.sleep(2)
                            date_table = tools.wait_and_get_table(driver=driver, index='/html/body/div[1]/div[2]/div/div/div[2]/div[3]/div/div[2]/div/div/div[1]/div[2]/div/div[1]/div/table')
                            date_table = date_table.dropna(how='all')
                            date_table.columns = ["물건번호", "감정평가액", "기일", "기일종류", "기일장소", "최저매각가격", "기일결과"]
                            self.logger.debug(date_table)
                        except :
                            # date_table이 없을 경우 "조회 내역이 없습니다." 메시지를 포함한 데이터프레임 생성
                            date_table = pd.DataFrame([["조회 내역 없음"] * 7], 
                                                    columns=["물건번호", "감정평가액", "기일", "기일종류", "기일장소", "최저매각가격", "기일결과"])
                            self.logger.debug(date_table)  

                        # 엑셀 파일 저장 및 사건번호와 등기부등본고유번호를 올바르게 사용
                        self.logger.debug('파일 작성을 시작합니다.')
                        excel_path = os.path.join(self.save_path, f'{index_number}_법원경매정보조회_{report_name}.xlsx')

                        auction_with_header = pd.DataFrame([auction_table.columns.tolist()] + auction_table.values.tolist())
                        date_with_header = pd.DataFrame([date_table.columns.tolist()] + date_table.values.tolist())
                        document_with_header = pd.DataFrame([document_table.columns.tolist()] + document_table.values.tolist())

                        extracted_tables = self.add_section_headers(auction_with_header, document_with_header, date_with_header)

                        extracted_tables.to_excel(excel_path, header=None, index=False)

                        workbook = load_workbook(excel_path)
                        sheet = workbook.active
                        for i in range(5):
                            sheet.insert_rows(1)

                        # 열 삽입 후 데이터 입력
                        sheet.insert_cols(1)  # A열에 삽입
                        sheet.insert_cols(2)  # B열에 삽입
                        sheet.insert_cols(3)  # C열에 삽입

                        # A, B, C 열에 index_number, index_class, index_address 값을 입력
                        for row in range(1, sheet.max_row + 1):
                            sheet[f'A{row}'] = index_number
                            sheet[f'B{row}'] = index_class
                            sheet[f'C{row}'] = index_address

                        # D열부터 기존 데이터 입력
                        case_number = f'{court_name}_{year}타경{court_number}'
                        sheet['D1'].value = case_number
                        sheet['D2'].value = '감정가'
                        sheet['E2'].value = appraised_value
                        sheet['D3'].value = '경매개시일'
                        sheet['E3'].value = start_date
                        sheet['D4'].value = '배당종기일'
                        sheet['E4'].value = end_date
                        sheet['D5'].value = '기일정보'

                        workbook.save(excel_path)

                    except Exception as e:
                        self.logger.info(f'엑셀파일 작성에 실패 : {e}')
                        failType = "기일내역이 조회되지 않음."
                        status = False
                        self.export_error(index_number, index_class, index_address, court_name, year, court_number, report_name)

                self.logger.critical('당 건에 대한 작업이 완료되었습니다.')

        driver.quit()



    def run_app(self, filepath):
        #B6부터 시작하는 표를 dataframe으로 import
        df = pd.read_excel(filepath, sheet_name='Input_법원경매', engine='openpyxl', header=5)
        df = df.iloc[:, 1:]
        report_name = self.get_report_name(filepath)
        #각 행을 순환하며 main() 실행
        self.main(report_name, df)
        
        #Temp 폴더 내의 *법원경매정보조회_{report_name}.xlsx 병합
        self.merge_excel(report_name)

        self.logger.critical('모든 작업이 완료되었습니다.')


if __name__ == '__main__':
    filepath = r'Smart_NPL.xlsm'
    court_auction().run_app(filepath)