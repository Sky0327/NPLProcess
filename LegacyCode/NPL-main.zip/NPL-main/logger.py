import logging
import colorlog
import os
import sys
from datetime import datetime
import time

class Logger():
    def __init__(self, save_path, function_name):

        # log 폴더 생성
        log_dir = save_path
        if not os.path.exists(log_dir):
            os.makedirs(log_dir)

        timestamp = datetime.now().strftime('%y%m%d_%H%M%S')
        log_name = f'{function_name}_{timestamp}'

        # 로그 파일 경로 설정 (현재 시간을 기반으로 파일명 생성)
        log_file = os.path.join(log_dir, f'{log_name}.txt')

        # 로그 포맷 정의
        log_format = (
            "%(log_color)s%(levelname)s:%(name)s:%(message)s"
        )

        # 컬러 로그 핸들러 생성 및 설정
        handler = colorlog.StreamHandler()
        handler.setFormatter(colorlog.ColoredFormatter(
            log_format,
            log_colors={
                'DEBUG': 'bold_white',
                'INFO': 'bold_blue',
                'WARNING': 'bold_yellow',
                'ERROR': 'bold_red',
                'CRITICAL': 'bold_red,bg_white',
            }
        ))

        # 파일 핸들러 추가 (로그 파일에 UTF-8로 저장)
        file_handler = logging.FileHandler(log_file, encoding='utf-8')
        file_handler.setLevel(logging.DEBUG)
        file_formatter = logging.Formatter('%(asctime)s - %(levelname)s - %(message)s')
        file_handler.setFormatter(file_formatter)

        # 로거 설정
        self.logger = colorlog.getLogger('logger')
        self.logger.addHandler(handler)
        self.logger.addHandler(file_handler)  # 파일 핸들러 추가
        self.logger.setLevel(logging.DEBUG)

    def get_logger(self):
        return self.logger

if __name__ == '__main__':
    logger = Logger().get_logger()
    logger.info('hello')
