import os
from pdfminer.high_level import extract_text
import pandas as pd
import re

#사용금지문자 : 【

def get_registry_basic_info_from_PDF(excel_path):

    print("hello2")
    # 버전 : 2024-10-11
    # 설명: 경로 내 PDF 등기부등본의 고유번호/종류/주소를 엑셀 파일로 반환하는 코드입니다. (하위 폴더 포함)

    # 엑셀 파일에서 "Source" 시트의 데이터 불러오기
    df_source = pd.read_excel(excel_path, sheet_name='Source')

    # 입력 변수 설정
    base_path = df_source.loc[df_source.iloc[:, 0] == '보고서폴더경로', df_source.columns[1]].values[0]
    report_name = df_source.loc[df_source.iloc[:, 0] == "보고서명", df_source.columns[1]].values[0]
    output_folder_path = os.path.join(base_path, 'Temp', '등기부등본 기본정보')
    output_file_name = f"등기부등본기본정보_{report_name}.xlsx"
    input_folder_path = df_source.loc[df_source.iloc[:, 0] == "등기부등본_input폴더경로", df_source.columns[1]].values[0]
    
    # 폴더 경로 검증 함수: 폴더가 존재하면 계속 진행하고, 없으면 생성 후 진행
    def verify_or_create_folder(path):
        if not os.path.exists(path):
            os.makedirs(path)
        return path

    # Excel에서 허용되지 않는 문자를 제거하는 함수
    def clean_text_for_excel(text):
        return ''.join(c for c in text if c.isprintable())

    # PDF 파일 처리 함수
    def process_pdfs(input_folder_path):
        results = []
        for root, dirs, files in os.walk(input_folder_path):
            for filename in files:
                if filename.endswith('.pdf'):
                    file_path = os.path.join(root, filename)
                    try:
                        text = extract_text(file_path)
                        text_cleaned = clean_text_for_excel(text)

                        # "고유번호" 추출
                        unique_number_match = re.search(r'고유번호\s(\d{4}-\d{4}-\d{6})', text_cleaned)
                        unique_number_line = unique_number_match.group(1) if unique_number_match else None

                        # "구분" 추출
                        category_match = re.search(r'\[(.*?)\]', text_cleaned)
                        category = category_match.group(1) if category_match else None

                        # "주소" 추출
                        address_match = re.search(r'\] (.*?)\【', text_cleaned)
                        address = address_match.group(1) if address_match else None

                        # 결과 리스트에 추가
                        results.append([file_path, filename, unique_number_line, category, address])
                    except Exception as e:
                        results.append([file_path, filename, None, None, None])
        return results

    # Excel 저장 함수
    def save_to_excel(df_filtered, df_full_pdf_list, report_folder_path):
        # 보고서 이름을 폴더 경로에서 가져옴
        report_name = os.path.basename(report_folder_path.rstrip('/\\'))

        # Temp 및 등기부등본 기본정보 폴더 생성
        temp_folder = os.path.join(report_folder_path, 'Temp', '등기부등본 기본정보')
        os.makedirs(temp_folder, exist_ok=True)

        # 임시 파일 경로 설정
        temp_output_file = os.path.join(temp_folder, f"Temp_Output_등기부등본기본정보_{report_name}.xlsx")
        # 최종 파일 경로 설정
        final_output_file = os.path.join(temp_folder, f"Output_등기부등본기본정보_{report_name}.xlsx")

        # 임시 파일에 저장
        with pd.ExcelWriter(temp_output_file, engine='openpyxl') as writer:
            df_filtered.to_excel(writer, index=False, sheet_name='Output_등본목록')  # 필터링된 데이터
            df_full_pdf_list.to_excel(writer, index=False, sheet_name='전체PDF목록')  # 전체 PDF 목록

        # 파일 이름 변경
        os.rename(temp_output_file, final_output_file)

    # 폴더 경로 검증
    verify_or_create_folder(base_path)  # base_path 검증 및 생성
    verify_or_create_folder(output_folder_path)  # output_folder_path 검증 및 생성

    # PDF 파일 처리 및 결과 저장
    results = process_pdfs(input_folder_path)

    # 시트1_등기부등본목록 : 고유번호가 식별된 PDF만 필터링
    columns = ['파일경로', '파일명', '등기부등본고유번호', '등기부등본구분', '등기부등본주소']
    df = pd.DataFrame(results, columns=columns)
    df_filtered = df.dropna(subset=['등기부등본고유번호'])  # '등기부등본고유번호' 열에서 빈칸인 행 삭제
    df_filtered = df_filtered[df_filtered['등기부등본고유번호'].str.match(r'^\d{4}-\d{4}-\d{6}$')]  # 고유번호 필터링

    # 시트2_전체PDF목록 : 불러온 전체 pdf 목록
    df_full_pdf_list = df[['파일경로', '파일명']]

    # 엑셀 파일 저장
    try:
        save_to_excel(df_filtered, df_full_pdf_list, base_path)
    except Exception as e:
        print(f"엑셀 파일 저장 중 오류 발생: {str(e)}")

    print("완료")

# 테스트용 코드
if __name__ == "__main__":
    # Smart_NPL.xlsm 파일 경로 (현재 디렉토리에 있다고 가정)
    current_dir = os.path.dirname(os.path.abspath(__file__))
    excel_path = os.path.join(current_dir, "Smart_NPL.xlsm")
    
    # 파일 존재 여부 확인
    if os.path.exists(excel_path):
        print(f"Smart_NPL.xlsm 파일을 찾았습니다: {excel_path}")
        get_registry_basic_info_from_PDF(excel_path)
    else:
        print(f"오류: {excel_path}를 찾을 수 없습니다.")
