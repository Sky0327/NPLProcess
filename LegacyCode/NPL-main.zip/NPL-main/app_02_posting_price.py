import os
from datetime import datetime
import requests
import pandas as pd
import re
import logging

def run_posting_price(excel_path):
    # 헬퍼 함수들 먼저 정의
    def load_source_path_from_excel(excel_path):
        df = pd.read_excel(excel_path, sheet_name='Source', engine='openpyxl')
        base_path = df.loc[df.iloc[:, 0] == '보고서폴더경로', df.columns[1]].values[0]
        return base_path

    def load_api_keys_from_excel(excel_path):
        df = pd.read_excel(excel_path, sheet_name='Source', engine='openpyxl')
        kakao_api_key = df.loc[df.iloc[:, 0] == 'kakao_apikey', df.columns[1]].values[0]
        twin_api_key = df.loc[df.iloc[:, 0] == 'twin_apikey', df.columns[1]].values[0]
        return kakao_api_key, twin_api_key

    def load_input_data_from_excel(excel_path):
        df = pd.read_excel(excel_path, sheet_name='Input_공시지가', header=5)
        df.columns = df.columns.str.strip()
        df['등기부등본주소_원본'] = df['등기부등본주소']  # 가공 전 원본 주소 저장
        # '외 (숫자) 필지', '외숫자필지', '외 (숫자)필지' 패턴을 모두 제거
        df['등기부등본주소'] = df['등기부등본주소'].apply(lambda x: re.sub(r'외\s?\d+\s?필지', '', x).strip())
        return df[['등기부등본고유번호', '등기부등본구분', '등기부등본주소', '등기부등본주소_원본']]

    def call_kakao_api(adress_name, kakao_api_key):
        url = "https://dapi.kakao.com/v2/local/search/address.json"
        headers = {"Authorization": f"KakaoAK {kakao_api_key}"}
        params = {"query": adress_name, "size": "30"}
        try:
            response_kakao = requests.get(url, headers=headers, params=params)
            response_kakao.raise_for_status()
            data = response_kakao.json()
            return data
        except requests.exceptions.RequestException as e:
            logger.error(f"API 호출에 실패했습니다: {e}")
            return {"error": "API 호출에 실패했습니다. 입력값을 확인해주세요"}

    def flatten_dict(data, parent_key='', sep='_'):
        items = []
        for k, v in data.items():
            new_key = f"{parent_key}{sep}{k}" if parent_key else k
            if isinstance(v, dict):
                items.extend(flatten_dict(v, new_key, sep=sep).items())
            else:
                items.append((new_key, v))
        return dict(items)

    def call_town_api(unique_id, dong_number, hosu_number, digital_twin_api_key):
        town_url = "http://api.vworld.kr/ned/data/getApartHousingPriceAttr"

        def make_request(dong_nm, ho_nm):
            town_params = {
                "key": digital_twin_api_key,
                "pnu": unique_id,
                "stdrYear": "2024",
                "dongNm": dong_nm,
                "hoNm": ho_nm,
                "format": "json",
                "numOfRows": "1",
                "pageNo": "1"
            }
            try:
                response_twin = requests.get(town_url, params=town_params)
                response_twin.raise_for_status()
                response_json = response_twin.json()
                return response_json
            except requests.exceptions.RequestException as e:
                logger.error(f"API 호출에 실패했습니다: {e}")
                return None

        # 순차적으로 요청을 보내며, 성공 시 바로 반환
        for dong, ho in [
            (dong_number, hosu_number),                   # 1. 첫 번째 시도
            (dong_number + "동", hosu_number),             # 2. 두 번째 시도 (dong_number에 '동' 추가)
            (dong_number, hosu_number + "호"),             # 3. 세 번째 시도 (hosu_number에 '호' 추가)
            (dong_number + "동", hosu_number + "호"),       # 4. 네 번째 시도 (dong_number에 '동', hosu_number에 '호' 모두 추가)
            ("", hosu_number),                            # 5. 다섯 번째 시도 (dong을 빈 문자열로, hosu_number만)
            ("", hosu_number + "호")                      # 6. 여섯 번째 시도 (dong을 빈 문자열로, hosu_number에 '호' 추가)
        ]:
            logger.info(f"공동주택 API 호출 PNU : {unique_id}, 동 : {dong}, 호 : {ho}")
            response = make_request(dong, ho)
            if response and "apartHousingPrices" in response and "field" in response["apartHousingPrices"]:
                return response  # 성공적인 response 반환

        # 모든 시도에서 field 태그가 없는 경우
        logger.error("Town API 호출에 실패했습니다. 모든 시도가 실패했습니다.")
        return None

    def call_individual_api(unique_id, digital_twin_api_key):
        logger.info(f"단독주택 API 호출 PNU : {unique_id}")
        individual_url = "https://api.vworld.kr/ned/data/getIndvdHousingPriceAttr"
        individual_params = {
            "key": digital_twin_api_key,
            "pnu": unique_id,
            "stdrYear": "2024",
            "format": "json",
            "numOfRows": "1",
            "pageNo": "1"
        }
        try:
            response_twin = requests.get(individual_url, params=individual_params)
            response_twin.raise_for_status()
            return response_twin.json()
        except requests.exceptions.RequestException as e:
            logger.error(f"API 호출에 실패했습니다: {e}")
            return None

    def call_land_api(unique_id, digital_twin_api_key):
        logger.info(f"토지 API 호출 PNU : {unique_id}")
        land_url_2024 = "https://api.vworld.kr/ned/data/getLandCharacteristics"
        land_params_2024 = {
            "key": digital_twin_api_key,
            "pnu": unique_id,
            "stdrYear": "2024",
            "format": "json",
            "numOfRows": "1",
            "pageNo": "1"
        }
        try:
            response_2024 = requests.get(land_url_2024, params=land_params_2024)
            response_2024.raise_for_status()
            data_2024 = response_2024.json()
        except requests.exceptions.RequestException as e:
            logger.error(f"2024년도 토지 API 호출에 실패했습니다: {e}")
            data_2024 = {"error": "API 호출에 실패했습니다. 입력값을 확인해주세요"}

        land_url_2023 = "https://api.vworld.kr/ned/data/getLandCharacteristics"
        land_params_2023 = {
            "key": digital_twin_api_key,
            "pnu": unique_id,
            "stdrYear": "2023",
            "format": "json",
            "numOfRows": "1",
            "pageNo": "1"
        }
        try:
            response_2023 = requests.get(land_url_2023, params=land_params_2023)
            response_2023.raise_for_status()
            data_2023 = response_2023.json()
        except requests.exceptions.RequestException as e:
            logger.error(f"2023년도 토지 API 호출에 실패했습니다: {e}")
            data_2023 = {"error": "API 호출에 실패했습니다. 입력값을 확인해주세요"}

        combined_data = {
            "2024": data_2024,
            "2023": data_2023
        }

        return combined_data

    def parse_kakao_data(kakao_data):
        if not kakao_data['documents']:
            raise ValueError("Kakao API 응답에 문서가 없습니다.")
        combined_data = []
        for doc in kakao_data['documents']:
            address_data = flatten_dict(doc['address'])
            road_address_data = flatten_dict(doc['road_address'], parent_key='r')
            combined_data.append({**address_data, **road_address_data})

        df = pd.DataFrame(combined_data)
        return df.stack().reset_index()[['level_1', 0]].rename(columns={'level_1': '구분', 0: '내용'})

    def parse_twin_data(twin_data, api_type):
        if api_type == "집합건물":
            if not twin_data.get('apartHousingPrices') or not twin_data['apartHousingPrices'].get('field'):
                logger.info("공동주택 가격 정보를 찾을 수 없습니다.")
                return None
            field_info = twin_data['apartHousingPrices']['field']
            flattened_data = [flatten_dict(item) for item in field_info]
        elif api_type == "건물":
            if not twin_data.get('indvdHousingPrices') or not twin_data['indvdHousingPrices'].get('field'):
                logger.info("개별주택 가격 정보를 찾을 수 없습니다.")
                return None
            field_info = twin_data['indvdHousingPrices']['field']
            flattened_data = [flatten_dict(item) for item in field_info]
        elif api_type == "토지":
            if not twin_data.get('2023') or not twin_data.get('2024'):
                logger.info("2023년 또는 2024년 토지 정보를 찾을 수 없습니다.")
                return None
            field_info_2024 = twin_data['2024'].get('landCharacteristicss', {}).get('field', [])
            field_info_2023 = twin_data['2023'].get('landCharacteristicss', {}).get('field', [])
            if not field_info_2024 and not field_info_2023:
                logger.info("토지 특성 정보가 없습니다.")
                return None
            flattened_data_2024 = [{f"2024_{k}": v for k, v in flatten_dict(item).items()} for item in field_info_2024]
            flattened_data_2023 = [{f"2023_{k}": v for k, v in flatten_dict(item).items()} for item in field_info_2023]
            flattened_data = flattened_data_2024 + flattened_data_2023
        else:
            logger.error(f"유효하지 않은 API 유형입니다: {api_type}")
            return None
        df = pd.DataFrame(flattened_data)
        return df.stack().reset_index()[['level_1', 0]].rename(columns={'level_1': '구분', 0: '내용'})

    def generate_unique_id(address_info):
        b_code = address_info['b_code']
        mountain_yn = '1' if address_info['mountain_yn'] == 'N' else '2'
        main_address_no = address_info['main_address_no'].zfill(4)
        sub_address_no = address_info['sub_address_no'].zfill(4)
        return b_code + mountain_yn + main_address_no + sub_address_no

    def extract_dong_and_hosu(address):
        dong_match = re.search(r'(\d+)[동]', address)
        hosu_match = re.search(r'(\d+)[호]', address)
        dong_number = dong_match.group(1) if dong_match else ''
        hosu_number = hosu_match.group(1) if hosu_match else ''
        return dong_number, hosu_number

    def fetch_property_data(adress_name, town_or_individual, kakao_api_key, digital_twin_api_key, adress_name_original):
        kakao_data = call_kakao_api(adress_name, kakao_api_key)
        if "error" in kakao_data:
            error_df = pd.DataFrame({
                '구분': ['2024_prposArea1Nm'],
                '내용': ["Kakao API 호출에 실패했습니다. 입력값을 확인해주세요"]
            })
            address_value = adress_name_original
            error_df.insert(0, '주소', address_value)
            twin_api_failure_message = None
            return error_df, twin_api_failure_message
        if not kakao_data.get('documents'):
            error_df = pd.DataFrame({
                '구분': ['2024_prposArea1Nm'],
                '내용': ["Kakao API 호출에 실패했습니다. 입력값을 확인해주세요"]
            })
            address_value = adress_name_original
            error_df.insert(0, '주소', address_value)
            twin_api_failure_message = None
            return error_df, twin_api_failure_message
        kakao_df = parse_kakao_data(kakao_data)
        address_info = kakao_data['documents'][0]['address']
        unique_id = generate_unique_id(address_info)
        dong_number, hosu_number = extract_dong_and_hosu(adress_name)
        twin_df_list = []
        twin_api_failure_message = None

        if town_or_individual == "집합건물":
            # 공동주택 API 호출
            town_data = call_town_api(unique_id, dong_number, hosu_number, digital_twin_api_key)
            if not town_data:
                # API 호출 자체에 실패한 경우
                twin_api_failure_message = "Twin API 호출에 실패했습니다. 주소를 확인해주세요."
                logger.error(twin_api_failure_message)
            elif not town_data.get('apartHousingPrices') or not town_data['apartHousingPrices'].get('field'):
                # API 호출에는 성공했으나 데이터가 없는 경우
                twin_api_failure_message = "Twin API 호출 성공. 데이터가 존재하지 않습니다."
                logger.info(twin_api_failure_message)
            else:
                try:
                    twin_df = parse_twin_data(town_data, "집합건물")
                    twin_df_list.append(twin_df)
                except ValueError as e:
                    # 데이터 파싱 중 에러 발생 시
                    twin_api_failure_message = "Twin API 호출 성공. 데이터가 존재하지 않습니다."
                    logger.error(f"공동주택 데이터 파싱 실패: {e}")

            # 토지 API 호출 (데이터 유무와 상관없이 호출)
            land_data = call_land_api(unique_id, digital_twin_api_key)
            if land_data.get('2024', {}).get('error') or land_data.get('2023', {}).get('error'):
                logger.error("토지 API 호출 실패")
            else:
                try:
                    land_df = parse_twin_data(land_data, "토지")
                    if land_df is not None:
                        twin_df_list.append(land_df)
                except ValueError as e:
                    logger.error(f"토지 데이터 파싱 실패: {e}")

        elif town_or_individual == "건물":
            # 개별주택 API 호출
            individual_data = call_individual_api(unique_id, digital_twin_api_key)
            if not individual_data:
                # API 호출 자체에 실패한 경우
                twin_api_failure_message = "Twin API 호출에 실패했습니다. 주소를 확인해주세요."
                logger.error(twin_api_failure_message)
            elif not individual_data.get('indvdHousingPrices') or not individual_data['indvdHousingPrices'].get('field'):
                # API 호출에는 성공했으나 데이터가 없는 경우
                twin_api_failure_message = "Twin API 호출 성공. 데이터가 존재하지 않습니다."
                logger.info(twin_api_failure_message)
            else:
                try:
                    twin_df = parse_twin_data(individual_data, "건물")
                    twin_df_list.append(twin_df)
                except ValueError as e:
                    # 데이터 파싱 중 에러 발생 시
                    twin_api_failure_message = "Twin API 호출 성공. 데이터가 존재하지 않습니다."
                    logger.error(f"개별주택 데이터 파싱 실패: {e}")

        elif town_or_individual == "토지":
            # 토지 API 호출
            land_data = call_land_api(unique_id, digital_twin_api_key)
            if land_data.get('2024', {}).get('error') or land_data.get('2023', {}).get('error'):
                twin_api_failure_message = "Twin API 호출에 실패했습니다. 주소를 확인해주세요."
                logger.error(twin_api_failure_message)
            else:
                try:
                    twin_df = parse_twin_data(land_data, "토지")
                    if twin_df is None:
                        twin_api_failure_message = "Twin API 호출 성공. 데이터가 존재하지 않습니다."
                        logger.info(twin_api_failure_message)
                    else:
                        twin_df_list.append(twin_df)
                except ValueError as e:
                    twin_api_failure_message = "Twin API 호출 성공. 데이터가 존재하지 않습니다."
                    logger.error(f"토지 데이터 파싱 실패: {e}")
        else:
            raise ValueError("유효하지 않은 등기부등본구분입니다.")

        # kakao_df와 twin_df_list를 결합
        if twin_df_list:
            twin_df = pd.concat(twin_df_list, ignore_index=True)
            kakao_twin_df = pd.concat([kakao_df, twin_df], ignore_index=True)
        else:
            kakao_twin_df = kakao_df

        kakao_twin_df.insert(0, '주소', adress_name_original)
        return kakao_twin_df, twin_api_failure_message

    def export_to_excel(df, unique_id, excel_path, adress_name, town_or_individual, kakao_data, twin_api_failure_message=None):
        base_path = load_source_path_from_excel(excel_path)
        save_dir = os.path.join(base_path, 'Temp', '공시지가')
        os.makedirs(save_dir, exist_ok=True)
        file_name = f"{unique_id}_공시지가.xlsx"
        file_path = os.path.join(save_dir, file_name)

        # Kakao API에서 주소 관련 데이터 가져오기 (값이 없으면 N/A 처리)
        if kakao_data.get('documents'):
            r_address_name = kakao_data['documents'][0].get('road_address', {}).get('address_name', 'N/A')
        else:
            r_address_name = 'N/A'

        # Data 시트에서 값을 가져오는 함수 정의
        def get_value_from_data(keyword, default='N/A'):
            result = df[df['구분'].str.strip().str.lower() == keyword.strip().lower()]
            if not result.empty:
                return result.iloc[0, 2]
            return default

        # Data 시트에서 값 추출
        prposArea1Nm_2024 = get_value_from_data('2024_prposArea1Nm')
        prposArea2Nm_2024 = get_value_from_data('2024_prposArea2Nm')
        pblntfPclnd_2024 = get_value_from_data('2024_pblntfPclnd')
        pblntfPclnd_2023 = get_value_from_data('2023_pblntfPclnd')
        # Twin API 실패 메시지에 따라 aphusNm 설정
        if twin_api_failure_message:
            aphusNm = twin_api_failure_message
        else:
            aphusNm = get_value_from_data('aphusNm')
        dongNm = get_value_from_data('dongNm')
        hoNm = get_value_from_data('hoNm')
        prvuseAr = get_value_from_data('prvuseAr')
        pblntfPc = get_value_from_data('pblntfPc')
        ladRegstrAr = get_value_from_data('ladRegstrAr')
        calcPlotAr = get_value_from_data('calcPlotAr')
        buldAllTotAr = get_value_from_data('buldAllTotAr')
        buldCalcTotAr = get_value_from_data('buldCalcTotAr')
        housePc = get_value_from_data('housePc')
        jibun = get_value_from_data('region_3depth_name')
        main_no = get_value_from_data('main_address_no')
        sub_no = get_value_from_data('sub_address_no')

        if pd.isna(sub_no) or sub_no == '':
            jibun_value = f"{jibun} {main_no}"
        else:
            jibun_value = f"{jibun} {main_no}-{sub_no}"

        # 'final' 시트에 삽입할 데이터프레임 생성
        final_df = pd.DataFrame({
            '등기부등본고유번호': [unique_id],
            '등기부등본구분': [town_or_individual],
            '등기부등본주소': [adress_name],
            'r_address_name': [r_address_name],
            '지번' : [jibun_value],
            '토지_용도지역명_1': [prposArea1Nm_2024],
            '토지_용도지역명_2': [prposArea2Nm_2024],
            '토지_공시지가_2024': [pblntfPclnd_2024],
            '토지_공시지가_2023': [pblntfPclnd_2023],
            '집합건물_단지명': [aphusNm],
            '집합건물_동': [dongNm],
            '집합건물_호': [hoNm],
            '집합건물_전용면적': [prvuseAr],
            '집합건물_공시지가_24': [pblntfPc],
            '건물_대지면적_전체': [ladRegstrAr],
            '건물_대지면적_산정': [calcPlotAr],
            '건물_건물연면적_전체': [buldAllTotAr],
            '건물_건물연면적_산정': [buldCalcTotAr],
            '건물_공시지가_24': [housePc]
        })

        with pd.ExcelWriter(file_path, engine='xlsxwriter') as writer:
            df.to_excel(writer, index=False, sheet_name='Data')  # Data 시트 저장
            final_df.to_excel(writer, index=False, sheet_name='final')  # final 시트 추가

        logger.info(f"File saved at: {file_path}")

    def merge_and_cleanup_final_sheets(output_dir):
        excel_files = [f for f in os.listdir(output_dir) if f.endswith(".xlsx") and not f.startswith("Output")]
        if not excel_files:
            logger.info("병합할 파일이 없습니다.")
            return

        folder_name = os.path.basename(output_dir)
        report_name = os.path.basename(os.path.dirname(os.path.dirname(output_dir)))
        temp_merged_file_name = f"Temp_Output_{folder_name}_{report_name}.xlsx"
        final_merged_file_name = f"Output_{folder_name}_{report_name}.xlsx"

        final_merged_data = []
        data_merged_data = []

        for file in excel_files:
            file_path = os.path.join(output_dir, file)
            if file == temp_merged_file_name:
                continue

            try:
                # 'final' 시트 병합
                final_df = pd.read_excel(file_path, sheet_name='final', engine='openpyxl')
                final_merged_data.append(final_df)

                # 'Data' 시트 병합
                data_df = pd.read_excel(file_path, sheet_name='Data', engine='openpyxl')
                data_merged_data.append(data_df)
            except ValueError as e:
                logger.error(f"Error reading sheet from {file}: {e}")
                continue

        # 파일 삭제
        for file in excel_files:
            file_path = os.path.join(output_dir, file)
            if file == temp_merged_file_name:
                continue
            try:
                os.remove(file_path)
            except OSError as e:
                logger.error(f"Error deleting file {file_path}: {e}")

        # 'final' 시트 병합
        if final_merged_data:
            final_merged_df = pd.concat(final_merged_data, ignore_index=True)
        else:
            final_merged_df = pd.DataFrame()  # 데이터가 없을 경우 빈 데이터프레임 생성

        # 'Data' 시트 병합
        if data_merged_data:
            data_merged_df = pd.concat(data_merged_data, ignore_index=True)
        else:
            data_merged_df = pd.DataFrame()  # 데이터가 없을 경우 빈 데이터프레임 생성

        # 병합된 파일을 Temp 이름으로 저장
        temp_merged_file_path = os.path.join(output_dir, temp_merged_file_name)
        with pd.ExcelWriter(temp_merged_file_path, engine='xlsxwriter') as writer:
            final_merged_df.to_excel(writer, sheet_name='Output_공시지가', index=False)
            data_merged_df.to_excel(writer, sheet_name='Output_공시지가(전체)', index=False)

        logger.info(f"Temporary merged file saved at: {temp_merged_file_path}")

        # 파일 저장 완료 후 파일명 변경
        final_merged_file_path = os.path.join(output_dir, final_merged_file_name)
        try:
            os.rename(temp_merged_file_path, final_merged_file_path)
            logger.info(f"File renamed to: {final_merged_file_path}")
        except OSError as e:
            logger.error(f"Error renaming file {temp_merged_file_path} to {final_merged_file_name}: {e}")

    def setup_logging(output_dir):
        # 로그 설정: 로그 파일을 output_dir에 저장
        timestamp = datetime.now().strftime('%y%m%d_%H%M%S')
        log_file_path = os.path.join(output_dir, f'posting_price_{timestamp}.log')

        # 로거 설정
        logger = logging.getLogger()
        logger.setLevel(logging.INFO)

        # 이전에 추가된 핸들러 제거
        if logger.hasHandlers():
            logger.handlers.clear()

        # 파일 핸들러 설정
        file_handler = logging.FileHandler(log_file_path)
        file_handler.setLevel(logging.INFO)
        file_formatter = logging.Formatter('%(asctime)s %(levelname)s:%(message)s', datefmt='%Y-%m-%d %H:%M:%S')
        file_handler.setFormatter(file_formatter)
        logger.addHandler(file_handler)

        # 콘솔 핸들러 설정 (터미널에 출력)
        console_handler = logging.StreamHandler()
        console_handler.setLevel(logging.INFO)
        console_formatter = logging.Formatter('%(asctime)s %(levelname)s:%(message)s', datefmt='%Y-%m-%d %H:%M:%S')
        console_handler.setFormatter(console_formatter)
        logger.addHandler(console_handler)

        return logger

    # load_source_path_from_excel을 호출하여 base_path 설정
    base_path = load_source_path_from_excel(excel_path)
    output_dir = os.path.join(base_path, 'Temp', '공시지가')
    os.makedirs(output_dir, exist_ok=True)

    logger = setup_logging(output_dir)

    # 실행 흐름
    kakao_api_key, digital_twin_api_key = load_api_keys_from_excel(excel_path)
    input_df = load_input_data_from_excel(excel_path)
    for _, row in input_df.iterrows():
        adress_name_processed = row['등기부등본주소']      # 가공된 주소 (API 호출용)
        adress_name_original = row['등기부등본주소_원본']  # 원본 주소 (저장용)
        town_or_individual = row['등기부등본구분']
        unique_id = row['등기부등본고유번호']
        kakao_data = call_kakao_api(adress_name_processed, kakao_api_key)
        kakao_twin_df, twin_api_failure_message = fetch_property_data(
            adress_name_processed, town_or_individual, kakao_api_key, digital_twin_api_key, adress_name_original)
        export_to_excel(kakao_twin_df, unique_id, excel_path, adress_name_original,
                        town_or_individual, kakao_data, twin_api_failure_message)
    merge_and_cleanup_final_sheets(output_dir)

if __name__ == "__main__":
    excel_path = 'Smart_NPL.xlsm'
    run_posting_price(excel_path)